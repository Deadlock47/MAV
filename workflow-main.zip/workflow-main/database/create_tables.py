"""Schema creation for Reddit scraper tables."""

from typing import Any

try:
    from .connection import get_connection
except ImportError:  # Supports `python database/create_tables.py` from the workspace root.
    from connection import get_connection


CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS reddit_posts (
    id BIGSERIAL PRIMARY KEY,
    reddit_post_id VARCHAR(50) UNIQUE NOT NULL,
    subreddit VARCHAR(100),
    title TEXT,
    selftext TEXT,
    post_url TEXT,
    permalink TEXT,
    score INTEGER DEFAULT 0,
    num_comments INTEGER DEFAULT 0,
    reddit_iframe_html TEXT,
    created_utc TIMESTAMP WITH TIME ZONE,
    upvoted_at TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS reddit_comments (
    id BIGSERIAL PRIMARY KEY,
    reddit_comment_id VARCHAR(50) UNIQUE NOT NULL,
    reddit_post_id VARCHAR(50) NOT NULL,
    parent_comment_id VARCHAR(50),
    subreddit VARCHAR(100),
    author VARCHAR(255),
    body TEXT,
    score INTEGER DEFAULT 0,
    created_utc TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE,
    CONSTRAINT reddit_comments_post_fk
        FOREIGN KEY (reddit_post_id)
        REFERENCES reddit_posts (reddit_post_id)
        ON DELETE CASCADE
);
"""


def create_tables(connection: Any | None = None) -> None:
    """Create the scraper tables. Close a connection created by this function."""
    owns_connection = connection is None
    connection = connection or get_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_TABLES_SQL)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        if owns_connection:
            connection.close()


if __name__ == "__main__":
    create_tables()
    print("Reddit database tables are ready.")
