"""Schema creation for Reddit + Instagram scraper tables."""

from typing import Any

try:
    from .connection import get_connection
except ImportError:  # Supports `python database/create_tables.py` from the workspace root.
    from connection import get_connection


REDDIT_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS reddit_posts (
    id BIGSERIAL PRIMARY KEY,
    reddit_post_id VARCHAR(50) UNIQUE NOT NULL,
    subreddit VARCHAR(100),
    title TEXT,
    selftext TEXT,
    post_url TEXT,
    permalink TEXT,
    score INTEGER DEFAULT 0,
    num_comments INTEGER DEFAULT 0,
    reddit_iframe_html TEXT,
    created_utc TIMESTAMP WITH TIME ZONE,
    upvoted_at TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS reddit_comments (
    id BIGSERIAL PRIMARY KEY,
    reddit_comment_id VARCHAR(50) UNIQUE NOT NULL,
    reddit_post_id VARCHAR(50) NOT NULL,
    parent_comment_id VARCHAR(50),
    subreddit VARCHAR(100),
    author VARCHAR(255),
    body TEXT,
    score INTEGER DEFAULT 0,
    created_utc TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE,
    CONSTRAINT reddit_comments_post_fk
        FOREIGN KEY (reddit_post_id)
        REFERENCES reddit_posts (reddit_post_id)
        ON DELETE CASCADE
);
"""

INSTA_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS insta_posts (
    id BIGSERIAL PRIMARY KEY,
    insta_post_id VARCHAR(100) UNIQUE NOT NULL,
    shortcode VARCHAR(50),
    post_type VARCHAR(20),
    caption TEXT,
    like_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    saved_at TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_insta_posts_shortcode ON insta_posts (shortcode);
CREATE INDEX IF NOT EXISTS idx_insta_posts_type ON insta_posts (post_type);

CREATE TABLE IF NOT EXISTS insta_media (
    id BIGSERIAL PRIMARY KEY,
    insta_post_id VARCHAR(100) NOT NULL,
    media_index INTEGER NOT NULL DEFAULT 0,
    media_type VARCHAR(20),
    media_url TEXT,
    UNIQUE (insta_post_id, media_index),
    CONSTRAINT insta_media_post_fk
        FOREIGN KEY (insta_post_id)
        REFERENCES insta_posts (insta_post_id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS insta_comments (
    id BIGSERIAL PRIMARY KEY,
    insta_comment_id VARCHAR(50) UNIQUE NOT NULL,
    insta_post_id VARCHAR(100) NOT NULL,
    parent_comment_id VARCHAR(50),
    author_user_id VARCHAR(50),
    author_username VARCHAR(255),
    body TEXT,
    like_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE,
    scraped_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    jav_codes TEXT[],
    is_processed BOOLEAN DEFAULT FALSE,
    CONSTRAINT insta_comments_post_fk
        FOREIGN KEY (insta_post_id)
        REFERENCES insta_posts (insta_post_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_insta_comments_post ON insta_comments (insta_post_id);
CREATE INDEX IF NOT EXISTS idx_insta_comments_parent ON insta_comments (parent_comment_id);

CREATE TABLE IF NOT EXISTS insta_ocr_results (
    id BIGSERIAL PRIMARY KEY,
    insta_post_id VARCHAR(100) UNIQUE NOT NULL,
    post_type VARCHAR(20),
    codes TEXT[],
    code_count INTEGER DEFAULT 0,
    image_path TEXT,
    video_path TEXT,
    frames_dir TEXT,
    frame_interval INTEGER,
    is_failure BOOLEAN DEFAULT FALSE,
    failure_reason TEXT,
    ocr_run_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT insta_ocr_post_fk
        FOREIGN KEY (insta_post_id)
        REFERENCES insta_posts (insta_post_id)
        ON DELETE CASCADE
);
"""

# Backward-compat alias so any external caller still works.
CREATE_TABLES_SQL = REDDIT_TABLES_SQL + INSTA_TABLES_SQL


def _run(connection: Any | None, sql: str) -> None:
    owns_connection = connection is None
    connection = connection or get_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute(sql)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        if owns_connection:
            connection.close()


def create_reddit_tables(connection: Any | None = None) -> None:
    """Create only the Reddit scraper tables."""
    _run(connection, REDDIT_TABLES_SQL)


def create_insta_tables(connection: Any | None = None) -> None:
    """Create only the Instagram scraper tables."""
    _run(connection, INSTA_TABLES_SQL)


def create_tables(connection: Any | None = None) -> None:
    """Create every scraper table (Reddit + Instagram). Idempotent."""
    _run(connection, REDDIT_TABLES_SQL + INSTA_TABLES_SQL)


if __name__ == "__main__":
    create_tables()
    print("Reddit and Instagram database tables are ready.")
