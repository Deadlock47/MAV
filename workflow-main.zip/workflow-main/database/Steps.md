# database — Execution Steps

PostgreSQL persistence layer used by the Reddit pipeline. Most files here are library modules (imported, not run); only `create_tables.py` is a script.

## Files

| File | Runnable? | Purpose |
|------|-----------|---------|
| `connection.py` | no (library) | Opens a `psycopg` connection using `POSTGRES_*` env vars; auto-loads `database/.env`. |
| `create_tables.py` | **yes** | Creates `reddit_posts` and `reddit_comments` tables if they don't exist. |
| `models.py` | no (library) | `RedditPost.from_mapping`, `RedditComment.from_mapping` dataclasses. |
| `repository.py` | no (library) | `RedditRepository.save_post_and_comments(...)` — upsert with per-comment savepoints. |
| `__init__.py` | no | Re-exports `get_connection`, `RedditRepository`, `DatabaseConfigurationError`. |
| `manual_load/posts_load.py` | placeholder | Empty. Intended for bulk-load scripts. |

## Order (from workspace root)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure credentials
Copy the template and edit values (git-ignored):
```bash
cp .env.example database/.env
```

Required keys:
```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=redinst
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
```

Any variable already set in the shell takes precedence.

### 3. Create the tables (one-time)
```bash
python database/create_tables.py
```
Expected output: `Reddit database tables are ready.`

### 4. Use from other code
`connection.py`, `models.py`, `repository.py` are **imported**, not run:
```python
from database import RedditRepository

repo = RedditRepository.from_environment()
try:
    repo.save_post_and_comments(post_dict, comment_dicts)
finally:
    repo.close()
```

## Related pipelines that write to these tables

- `python -m reddit_autom.reddit_comments` (stage s02 upserts posts + comments)
- `python -m reddit_autom.reddit_comments.console.load` (bulk-load browser-console dumps)
