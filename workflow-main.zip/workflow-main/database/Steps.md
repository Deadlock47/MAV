# database — Execution Steps

PostgreSQL persistence layer used by both the Reddit and Instagram pipelines. Most files here are library modules (imported, not run); only `create_tables.py` and the `manual_load/*.py` loaders are scripts.

## Files

| File | Runnable? | Purpose |
|------|-----------|---------|
| `connection.py` | no (library) | Opens a `psycopg` connection using `POSTGRES_*` env vars; auto-loads `database/.env`. |
| `create_tables.py` | **yes** | Creates every scraper table (Reddit + Instagram) if missing. Also exposes `create_reddit_tables()` / `create_insta_tables()` for callers that only want one side. |
| `models.py` | no (library) | Reddit dataclasses: `RedditPost.from_mapping`, `RedditComment.from_mapping`. |
| `repository.py` | no (library) | `RedditRepository.save_post_and_comments(...)` — upsert with per-comment savepoints. |
| `insta_models.py` | no (library) | Instagram dataclasses: `InstaPost`, `InstaMedia`, `InstaComment`, `InstaOcrResult` (all with `.from_mapping`). |
| `insta_repository.py` | no (library) | `InstaRepository` — upserts posts + media + comment trees + OCR results, plus `update_post_codes`. |
| `__init__.py` | no | Re-exports `get_connection`, `RedditRepository`, `InstaRepository`, `DatabaseConfigurationError`. |
| `manual_load/insta_load.py` | **yes** | Bulk-load `insta_autom/{posts,comments/comments,ocr_results_*}.json` into Postgres. |
| `manual_load/posts_load.py` | placeholder | Empty. Intended for Reddit bulk loads. |

## Tables

**Reddit**
- `reddit_posts` — one row per upvoted post (`reddit_post_id UNIQUE`).
- `reddit_comments` — flat comment tree with `parent_comment_id`; FK → `reddit_posts` on cascade.

**Instagram**
- `insta_posts` — one row per saved post (`insta_post_id UNIQUE`); indexed on `shortcode` and `post_type`.
- `insta_media` — one row per media entry in the post (carousel-safe via `UNIQUE(insta_post_id, media_index)`); FK cascade.
- `insta_comments` — flat tree with `parent_comment_id`; FK cascade; indexed on post + parent.
- `insta_ocr_results` — one row per post with `codes TEXT[]`, `image_path` / `video_path` / `frames_dir`, `is_failure`, `failure_reason`; FK cascade.

## Order (from workspace root)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure credentials
Copy the template and edit values (git-ignored):
```bash
cp .env.example database/.env
```

Required keys:
```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=redinst
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
```

Any variable already set in the shell takes precedence.

### 3. Create the tables (one-time)
```bash
python database/create_tables.py
```
Expected output: `Reddit and Instagram database tables are ready.`

Or bootstrap only one side from Python:
```python
from database.create_tables import create_reddit_tables, create_insta_tables
create_reddit_tables()
create_insta_tables()
```

### 4. Use from other code
`connection.py`, `models.py`, `repository.py`, `insta_models.py`, `insta_repository.py` are **imported**, not run:

```python
from database import RedditRepository, InstaRepository

# Reddit side
reddit = RedditRepository.from_environment()
try:
    reddit.save_post_and_comments(post_dict, comment_dicts)
finally:
    reddit.close()

# Instagram side
insta = InstaRepository.from_environment()
try:
    insta.save_post(post_dict)                    # upserts post + media rows
    insta.save_comments(post_id, comment_tree)    # walks replies with parent_comment_id
    insta.save_ocr_result(ocr_dict)               # or is_failure=True for failures
    insta.update_post_codes(post_id, ["JUR-656"]) # sets jav_codes on the post
finally:
    insta.close()
```

## Related pipelines that write to these tables

- `python -m reddit_autom.reddit_comments` — s02 upserts Reddit posts + comments.
- `python -m reddit_autom.reddit_comments.console.load` — bulk-load browser-console Reddit dumps.
- `python -m database.manual_load.insta_load` — bulk-load Instagram JSON artifacts (posts / comments / OCR / comment-derived codes).
