"""UPSERT operations for Instagram posts, media, comments and OCR results."""

import logging
from collections.abc import Iterable, Mapping
from typing import Any

from .connection import get_connection
from .create_tables import create_insta_tables
from .insta_models import InstaComment, InstaMedia, InstaOcrResult, InstaPost

LOGGER = logging.getLogger(__name__)

POST_UPSERT = """
INSERT INTO insta_posts (
    insta_post_id, shortcode, post_type, caption, like_count, comment_count,
    saved_at, jav_codes, is_processed
) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (insta_post_id) DO UPDATE SET
    shortcode = COALESCE(EXCLUDED.shortcode, insta_posts.shortcode),
    post_type = COALESCE(EXCLUDED.post_type, insta_posts.post_type),
    caption = COALESCE(EXCLUDED.caption, insta_posts.caption),
    like_count = COALESCE(EXCLUDED.like_count, insta_posts.like_count),
    comment_count = COALESCE(EXCLUDED.comment_count, insta_posts.comment_count),
    saved_at = COALESCE(EXCLUDED.saved_at, insta_posts.saved_at),
    scraped_at = CURRENT_TIMESTAMP,
    jav_codes = COALESCE(EXCLUDED.jav_codes, insta_posts.jav_codes),
    is_processed = COALESCE(EXCLUDED.is_processed, insta_posts.is_processed)
"""

MEDIA_UPSERT = """
INSERT INTO insta_media (
    insta_post_id, media_index, media_type, media_url
) VALUES (%s, %s, %s, %s)
ON CONFLICT (insta_post_id, media_index) DO UPDATE SET
    media_type = EXCLUDED.media_type,
    media_url = EXCLUDED.media_url
"""

COMMENT_UPSERT = """
INSERT INTO insta_comments (
    insta_comment_id, insta_post_id, parent_comment_id, author_user_id,
    author_username, body, like_count, created_at, jav_codes, is_processed
) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (insta_comment_id) DO UPDATE SET
    insta_post_id = EXCLUDED.insta_post_id,
    parent_comment_id = EXCLUDED.parent_comment_id,
    author_user_id = COALESCE(EXCLUDED.author_user_id, insta_comments.author_user_id),
    author_username = COALESCE(EXCLUDED.author_username, insta_comments.author_username),
    body = COALESCE(EXCLUDED.body, insta_comments.body),
    like_count = COALESCE(EXCLUDED.like_count, insta_comments.like_count),
    created_at = COALESCE(EXCLUDED.created_at, insta_comments.created_at),
    scraped_at = CURRENT_TIMESTAMP,
    jav_codes = COALESCE(EXCLUDED.jav_codes, insta_comments.jav_codes),
    is_processed = COALESCE(EXCLUDED.is_processed, insta_comments.is_processed)
"""

OCR_UPSERT = """
INSERT INTO insta_ocr_results (
    insta_post_id, post_type, codes, code_count, image_path, video_path,
    frames_dir, frame_interval, is_failure, failure_reason
) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (insta_post_id) DO UPDATE SET
    post_type = COALESCE(EXCLUDED.post_type, insta_ocr_results.post_type),
    codes = EXCLUDED.codes,
    code_count = EXCLUDED.code_count,
    image_path = COALESCE(EXCLUDED.image_path, insta_ocr_results.image_path),
    video_path = COALESCE(EXCLUDED.video_path, insta_ocr_results.video_path),
    frames_dir = COALESCE(EXCLUDED.frames_dir, insta_ocr_results.frames_dir),
    frame_interval = COALESCE(EXCLUDED.frame_interval, insta_ocr_results.frame_interval),
    is_failure = EXCLUDED.is_failure,
    failure_reason = EXCLUDED.failure_reason,
    ocr_run_at = CURRENT_TIMESTAMP
"""


def _post_values(post: InstaPost) -> tuple[Any, ...]:
    return tuple(post.__dict__.values())


def _media_values(media: InstaMedia) -> tuple[Any, ...]:
    return tuple(media.__dict__.values())


def _comment_values(comment: InstaComment) -> tuple[Any, ...]:
    return tuple(comment.__dict__.values())


def _ocr_values(ocr: InstaOcrResult) -> tuple[Any, ...]:
    return tuple(ocr.__dict__.values())


def _iter_flat_comments(
    comments: Iterable[Mapping[str, Any]],
    insta_post_id: str,
    parent_id: str | None = None,
):
    """Yield (InstaComment, replies) for each comment; replies are walked recursively."""
    for entry in comments or []:
        if not isinstance(entry, Mapping):
            continue
        try:
            model = InstaComment.from_mapping(entry, insta_post_id, parent_id)
        except ValueError as error:
            LOGGER.warning("Skipping malformed Instagram comment: %s", error)
            continue
        yield model
        replies = entry.get("replies")
        if isinstance(replies, list) and replies:
            yield from _iter_flat_comments(replies, insta_post_id, model.insta_comment_id)


class InstaRepository:
    """Persist Instagram data with safe upserts and per-item savepoints."""

    def __init__(self, connection: Any) -> None:
        self.connection = connection

    @classmethod
    def from_environment(cls) -> "InstaRepository":
        connection = get_connection()
        try:
            create_insta_tables(connection)
        except Exception:
            connection.close()
            raise
        return cls(connection)

    def close(self) -> None:
        self.connection.close()

    # -- posts + media -------------------------------------------------------

    def save_post(self, post_data: Mapping[str, Any]) -> None:
        """Upsert a post and (re)replace its media rows."""
        post = InstaPost.from_mapping(post_data)
        raw_media = post_data.get("media")
        media_items: list[InstaMedia] = []
        if isinstance(raw_media, list):
            for index, entry in enumerate(raw_media):
                if not isinstance(entry, Mapping):
                    continue
                media_items.append(
                    InstaMedia(
                        insta_post_id=post.insta_post_id,
                        media_index=index,
                        media_type=entry.get("type") or entry.get("media_type"),
                        media_url=entry.get("url"),
                    )
                )

        try:
            with self.connection.cursor() as cursor:
                cursor.execute(POST_UPSERT, _post_values(post))
                # Media membership can change (e.g. carousel edited); wipe then re-insert.
                cursor.execute(
                    "DELETE FROM insta_media WHERE insta_post_id = %s",
                    (post.insta_post_id,),
                )
                for media in media_items:
                    cursor.execute(MEDIA_UPSERT, _media_values(media))
            self.connection.commit()
        except Exception:
            self.connection.rollback()
            LOGGER.exception("Could not save Instagram post %s", post.insta_post_id)
            raise

    # -- comments ------------------------------------------------------------

    def save_comments(
        self,
        insta_post_id: str,
        comments: Iterable[Mapping[str, Any]],
    ) -> int:
        """Upsert a comment tree; each row runs inside its own SAVEPOINT."""
        saved = 0
        try:
            with self.connection.cursor() as cursor:
                for index, comment in enumerate(_iter_flat_comments(comments, str(insta_post_id))):
                    cursor.execute(f"SAVEPOINT insta_comment_{index}")
                    try:
                        cursor.execute(COMMENT_UPSERT, _comment_values(comment))
                        cursor.execute(f"RELEASE SAVEPOINT insta_comment_{index}")
                        saved += 1
                    except Exception as error:
                        cursor.execute(f"ROLLBACK TO SAVEPOINT insta_comment_{index}")
                        LOGGER.exception(
                            "Could not save Instagram comment %s: %s",
                            comment.insta_comment_id,
                            error,
                        )
            self.connection.commit()
            return saved
        except Exception:
            self.connection.rollback()
            LOGGER.exception("Could not save Instagram comments for post %s", insta_post_id)
            raise

    # -- OCR -----------------------------------------------------------------

    def save_ocr_result(
        self,
        result: Mapping[str, Any],
        *,
        is_failure: bool = False,
    ) -> None:
        ocr = InstaOcrResult.from_mapping(result, is_failure=is_failure)
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(OCR_UPSERT, _ocr_values(ocr))
            self.connection.commit()
        except Exception:
            self.connection.rollback()
            LOGGER.exception("Could not save OCR result for post %s", ocr.insta_post_id)
            raise

    def update_post_codes(self, insta_post_id: str, codes: Iterable[str] | None) -> None:
        """Overwrite jav_codes on a post (typically the union of OCR + comment codes)."""
        clean = sorted({str(c).strip().upper() for c in codes or [] if str(c).strip()})
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE insta_posts SET jav_codes = %s WHERE insta_post_id = %s",
                    (clean or None, str(insta_post_id)),
                )
            self.connection.commit()
        except Exception:
            self.connection.rollback()
            LOGGER.exception("Could not update jav_codes for post %s", insta_post_id)
            raise
