# manual_load — Execution Steps

Bulk-load scripts for the `database` package.

## Files

| File | Purpose |
|------|---------|
| `posts_load.py` | Placeholder for a Reddit bulk-load script (currently empty). |
| `insta_load.py` | Bulk-load `insta_autom/posts.json`, `comments/comments.json`, `ocr_results_*.json`, and `codes_from_comments.json` into Postgres via `InstaRepository`. |

## Instagram loader

Run from the workspace root **after** `python database/create_tables.py`:

```bash
# Default paths (workspace layout)
python -m database.manual_load.insta_load

# Explicit paths (all flags optional)
python -m database.manual_load.insta_load \
  --posts insta_autom/posts.json \
  --comments insta_autom/comments/comments.json \
  --ocr insta_autom/ocr_results_video_or_reel.json \
  --ocr insta_autom/ocr_results_carousel.json \
  --ocr insta_autom/ocr_results_image_post.json \
  --comment-codes insta_autom/comments/codes_from_comments.json

# Skip the final union-of-codes update to insta_posts.jav_codes
python -m database.manual_load.insta_load --skip-code-merge
```

What it does, in order:
1. Upserts every post into `insta_posts` and replaces its rows in `insta_media`.
2. Walks the comment tree in `comments.json` and upserts each into `insta_comments` (with `parent_comment_id` set for replies).
3. Upserts every OCR result + failure into `insta_ocr_results`.
4. Merges OCR codes ∪ comment-derived codes into `insta_posts.jav_codes` per post (skip with `--skip-code-merge`).

Requires `POSTGRES_*` in `database/.env`.

## Reddit loader

`posts_load.py` is currently a placeholder. Once implemented, it should read a JSON dump and call `RedditRepository.save_post_and_comments(...)`.

```bash
python database/manual_load/posts_load.py
```
