# manual_load — Execution Steps

Bulk-load scripts for the `database` package.

## Status

`posts_load.py` is currently **empty** (placeholder). No commands to run yet.

## When implemented

Run from the workspace root **after** `python database/create_tables.py`:

```bash
python database/manual_load/posts_load.py
```

The script is expected to read JSON dumps and use `database.RedditRepository.save_post_and_comments` to upsert them.
