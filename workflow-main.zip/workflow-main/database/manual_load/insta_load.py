"""Bulk-load Instagram JSON artifacts into Postgres via `InstaRepository`.

Usage (from workspace root):

    python -m database.manual_load.insta_load \
        --posts insta_autom/posts.json \
        --comments insta_autom/comments/comments.json \
        --ocr insta_autom/ocr_results_video_or_reel.json \
        --ocr insta_autom/ocr_results_carousel.json \
        --ocr insta_autom/ocr_results_image_post.json \
        --comment-codes insta_autom/comments/codes_from_comments.json

All flags are optional; each file that isn't provided is skipped. `POSTGRES_*`
must be set in `database/.env`.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

# When run as `python database/manual_load/insta_load.py`, make the workspace root importable.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from database import InstaRepository  # noqa: E402


LOGGER = logging.getLogger(__name__)


def _read_json(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        LOGGER.warning("Could not parse %s: %s", path, error)
        return default


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _load_posts(repo: InstaRepository, posts_path: Path) -> int:
    posts = _read_json(posts_path, [])
    if not isinstance(posts, list):
        LOGGER.warning("Expected a list in %s; skipping.", posts_path)
        return 0
    saved = 0
    for post in posts:
        if not isinstance(post, dict):
            continue
        try:
            repo.save_post(post)
            saved += 1
        except Exception:
            LOGGER.exception("Could not save post %s", post.get("post_id"))
    LOGGER.info("Saved %d posts from %s", saved, posts_path)
    return saved


def _load_comments(repo: InstaRepository, comments_path: Path) -> int:
    payload = _read_json(comments_path, [])
    if not isinstance(payload, list):
        LOGGER.warning("Expected a list in %s; skipping.", comments_path)
        return 0
    saved = 0
    for entry in payload:
        if not isinstance(entry, dict):
            continue
        pid = entry.get("post_id") or entry.get("insta_post_id")
        raw_comments = entry.get("comments") or []
        if not pid or not isinstance(raw_comments, list):
            continue
        try:
            saved += repo.save_comments(str(pid), raw_comments)
        except Exception:
            LOGGER.exception("Could not save comments for %s", pid)
    LOGGER.info("Saved %d comments from %s", saved, comments_path)
    return saved


def _load_ocr_file(repo: InstaRepository, ocr_path: Path) -> tuple[int, int]:
    payload = _read_json(ocr_path, {})
    if not isinstance(payload, dict):
        LOGGER.warning("Expected an object in %s; skipping.", ocr_path)
        return 0, 0
    post_type = payload.get("post_type")
    ok = fail = 0
    for result in payload.get("results", []) or []:
        if not isinstance(result, dict):
            continue
        result.setdefault("post_type", post_type)
        try:
            repo.save_ocr_result(result, is_failure=False)
            ok += 1
        except Exception:
            LOGGER.exception("Could not save OCR result for %s", result.get("post_id"))
    for failure in payload.get("failures", []) or []:
        if not isinstance(failure, dict):
            continue
        failure.setdefault("post_type", post_type)
        try:
            repo.save_ocr_result(failure, is_failure=True)
            fail += 1
        except Exception:
            LOGGER.exception("Could not save OCR failure for %s", failure.get("post_id"))
    LOGGER.info("Saved %d OCR results (%d failures) from %s", ok, fail, ocr_path)
    return ok, fail


def _load_comment_codes(
    repo: InstaRepository,
    comment_codes_path: Path,
    ocr_paths: list[Path],
) -> int:
    """Populate insta_posts.jav_codes with OCR codes ∪ comment codes per post."""
    per_post: dict[str, set[str]] = {}

    for ocr_path in ocr_paths:
        payload = _read_json(ocr_path, {})
        if not isinstance(payload, dict):
            continue
        for result in payload.get("results", []) or []:
            if not isinstance(result, dict):
                continue
            pid = result.get("post_id") or result.get("insta_post_id")
            codes = result.get("codes") or []
            if not pid or not isinstance(codes, list):
                continue
            bucket = per_post.setdefault(str(pid), set())
            bucket.update(str(c).strip().upper() for c in codes if str(c).strip())

    comment_codes = _read_json(comment_codes_path, [])
    if isinstance(comment_codes, list):
        for entry in comment_codes:
            if not isinstance(entry, dict):
                continue
            pid = entry.get("post_id") or entry.get("insta_post_id")
            codes = entry.get("code") or entry.get("codes") or []
            if not pid or not isinstance(codes, list):
                continue
            bucket = per_post.setdefault(str(pid), set())
            bucket.update(str(c).strip().upper() for c in codes if str(c).strip())

    updated = 0
    for pid, codes in per_post.items():
        try:
            repo.update_post_codes(pid, codes)
            if codes:
                updated += 1
        except Exception:
            LOGGER.exception("Could not update jav_codes for %s", pid)
    LOGGER.info("Updated jav_codes on %d posts", updated)
    return updated


def _build_parser() -> argparse.ArgumentParser:
    root = _repo_root()
    parser = argparse.ArgumentParser(
        prog="python -m database.manual_load.insta_load",
        description="Load Instagram JSON artifacts into Postgres.",
    )
    parser.add_argument("--posts", type=Path, default=root / "insta_autom" / "posts.json")
    parser.add_argument(
        "--comments",
        type=Path,
        default=root / "insta_autom" / "comments" / "comments.json",
    )
    parser.add_argument(
        "--ocr",
        type=Path,
        action="append",
        default=None,
        help="OCR results JSON (repeat for each media type).",
    )
    parser.add_argument(
        "--comment-codes",
        type=Path,
        default=root / "insta_autom" / "comments" / "codes_from_comments.json",
    )
    parser.add_argument(
        "--skip-code-merge",
        action="store_true",
        help="Do not populate insta_posts.jav_codes from OCR + comment codes.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _build_parser().parse_args(argv)

    root = _repo_root()
    ocr_paths = args.ocr or [
        root / "insta_autom" / "ocr_results_video_or_reel.json",
        root / "insta_autom" / "ocr_results_carousel.json",
        root / "insta_autom" / "ocr_results_image_post.json",
    ]

    repo = InstaRepository.from_environment()
    try:
        _load_posts(repo, args.posts)
        _load_comments(repo, args.comments)
        for ocr_path in ocr_paths:
            _load_ocr_file(repo, ocr_path)
        if not args.skip_code_merge:
            _load_comment_codes(repo, args.comment_codes, ocr_paths)
    finally:
        repo.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
