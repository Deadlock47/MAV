"""Small data models that adapt Instagram scrape dictionaries for persistence."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping

# Reuse the shared normalizers from the Reddit models module.
from .models import _codes, _timestamp


@dataclass(frozen=True)
class InstaPost:
    insta_post_id: str
    shortcode: str | None = None
    post_type: str | None = None
    caption: str | None = None
    like_count: int | None = None
    comment_count: int | None = None
    saved_at: datetime | None = None
    jav_codes: list[str] | None = None
    is_processed: bool | None = None

    @classmethod
    def from_mapping(cls, post: Mapping[str, Any]) -> "InstaPost":
        pid = (
            post.get("insta_post_id")
            or post.get("post_id")
            or post.get("id")
        )
        if not pid:
            raise ValueError("Instagram post is missing its ID.")
        caption = post.get("caption")
        if isinstance(caption, Mapping):
            caption = caption.get("text")
        return cls(
            insta_post_id=str(pid),
            shortcode=post.get("shortcode") or post.get("code"),
            post_type=post.get("post_type"),
            caption=caption if isinstance(caption, str) else None,
            like_count=post.get("like_count"),
            comment_count=post.get("comment_count"),
            saved_at=_timestamp(post.get("saved_at") or post.get("taken_at")),
            jav_codes=_codes(post.get("jav_codes")),
            is_processed=post.get("is_processed"),
        )


@dataclass(frozen=True)
class InstaMedia:
    insta_post_id: str
    media_index: int
    media_type: str | None
    media_url: str | None


@dataclass(frozen=True)
class InstaComment:
    insta_comment_id: str
    insta_post_id: str
    parent_comment_id: str | None = None
    author_user_id: str | None = None
    author_username: str | None = None
    body: str | None = None
    like_count: int | None = None
    created_at: datetime | None = None
    jav_codes: list[str] | None = None
    is_processed: bool | None = None

    @classmethod
    def from_mapping(
        cls,
        comment: Mapping[str, Any],
        insta_post_id: str,
        parent_comment_id: str | None = None,
    ) -> "InstaComment":
        cid = comment.get("insta_comment_id") or comment.get("id")
        if not cid:
            raise ValueError("Instagram comment is missing its ID.")
        user = comment.get("user") if isinstance(comment.get("user"), Mapping) else {}
        return cls(
            insta_comment_id=str(cid),
            insta_post_id=str(insta_post_id),
            parent_comment_id=str(parent_comment_id) if parent_comment_id else None,
            author_user_id=str(user.get("id")) if user.get("id") else None,
            author_username=user.get("username") if isinstance(user.get("username"), str) else None,
            body=comment.get("text") or comment.get("body"),
            like_count=comment.get("like_count"),
            created_at=_timestamp(comment.get("created_at")),
            jav_codes=_codes(comment.get("jav_codes")),
            is_processed=comment.get("is_processed"),
        )


@dataclass(frozen=True)
class InstaOcrResult:
    insta_post_id: str
    post_type: str | None = None
    codes: list[str] | None = None
    code_count: int | None = None
    image_path: str | None = None
    video_path: str | None = None
    frames_dir: str | None = None
    frame_interval: int | None = None
    is_failure: bool = False
    failure_reason: str | None = None

    @classmethod
    def from_mapping(
        cls,
        result: Mapping[str, Any],
        *,
        is_failure: bool = False,
    ) -> "InstaOcrResult":
        pid = result.get("insta_post_id") or result.get("post_id")
        if not pid:
            raise ValueError("Instagram OCR result is missing post_id.")
        raw_codes = result.get("codes") or result.get("code") or []
        codes = _codes(raw_codes) if isinstance(raw_codes, list) else None
        code_count = result.get("count")
        if not isinstance(code_count, int):
            code_count = len(codes or [])
        frame_interval = result.get("frame_interval")
        if not isinstance(frame_interval, int):
            frame_interval = None
        return cls(
            insta_post_id=str(pid),
            post_type=result.get("post_type"),
            codes=codes,
            code_count=code_count,
            image_path=result.get("image_path"),
            video_path=result.get("video_path"),
            frames_dir=result.get("frames_dir"),
            frame_interval=frame_interval,
            is_failure=is_failure,
            failure_reason=result.get("failure_reason") or result.get("error"),
        )
