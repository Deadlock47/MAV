"""Database connection configuration loaded from environment variables."""

import os
from pathlib import Path
from typing import Any


def _load_dotenv() -> None:
    """Load POSTGRES_* vars from the nearest .env walking up from this file."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    for directory in Path(__file__).resolve().parents:
        candidate = directory / ".env"
        if candidate.is_file():
            load_dotenv(candidate, override=False)
            return


_load_dotenv()


class DatabaseConfigurationError(RuntimeError):
    """Raised when the PostgreSQL connection has not been configured."""


def get_connection() -> Any:
    """Open a PostgreSQL connection using the POSTGRES_* environment variables."""
    missing = [
        name
        for name in ("POSTGRES_DB", "POSTGRES_USER", "POSTGRES_PASSWORD")
        if not os.getenv(name)
    ]
    if missing:
        raise DatabaseConfigurationError(
            "PostgreSQL is not configured. Set " + ", ".join(missing) + "."
        )

    try:
        import psycopg
    except ImportError as error:
        raise DatabaseConfigurationError(
            "The PostgreSQL driver is missing. Install dependencies with "
            "pip install -r requirements.txt."
        ) from error

    try:
        return psycopg.connect(
            host=os.getenv("POSTGRES_HOST", "localhost"),
            port=os.getenv("POSTGRES_PORT", "5432"),
            dbname=os.environ["POSTGRES_DB"],
            user=os.environ["POSTGRES_USER"],
            password=os.environ["POSTGRES_PASSWORD"],
            connect_timeout=10,
        )
    except psycopg.Error as error:
        raise DatabaseConfigurationError(
            "Could not connect to PostgreSQL. Check POSTGRES_HOST, POSTGRES_PORT, "
            "POSTGRES_DB, POSTGRES_USER, and POSTGRES_PASSWORD. "
            f"PostgreSQL reported: {error}"
        ) from error
