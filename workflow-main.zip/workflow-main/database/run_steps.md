# Database — File Guide & Run Steps

PostgreSQL persistence layer for the Reddit scraping workflow. Stores scraped **posts** and **comments** with idempotent upserts, JAV-code arrays, and per-comment savepoints.

---

## Python Files

### `__init__.py`
Public entry point for the `database` package. Re-exports the three symbols external code should use:
- `get_connection` — open a PostgreSQL connection.
- `RedditRepository` — high-level API to save posts and comments.
- `DatabaseConfigurationError` — raised when the DB is misconfigured.

### `connection.py`
Opens a `psycopg` connection using environment variables:
- Required: `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`.
- Optional: `POSTGRES_HOST` (default `localhost`), `POSTGRES_PORT` (default `5432`).

On import, walks up from this file to find a `.env` at the workspace root and loads it via `python-dotenv` (existing shell vars are not overridden). Raises `DatabaseConfigurationError` if any required var is missing, if the `psycopg` driver is not installed, or if PostgreSQL rejects the connection.

### `create_tables.py`
Creates the two scraper tables if they don't already exist:
- **`reddit_posts`** — post id, subreddit, title, selftext, urls, score, num_comments, iframe HTML, `created_utc`, `upvoted_at`, `scraped_at`, `jav_codes TEXT[]`, `is_processed`. Unique on `reddit_post_id`.
- **`reddit_comments`** — comment id, parent post id, parent comment id, subreddit, author, body, score, timestamps, `jav_codes`, `is_processed`. Foreign key to `reddit_posts(reddit_post_id)` with `ON DELETE CASCADE`.

Runnable as a script to bootstrap the schema. Uses a fallback import so it works both as a module and when executed directly.

### `models.py`
Frozen dataclasses that adapt raw Reddit API dicts into rows ready for insert:
- **`RedditPost.from_mapping(post)`** — pulls id/title/selftext/url/permalink/score/etc., extracts iframe HTML from `secure_media_embed` when present.
- **`RedditComment.from_mapping(comment, reddit_post_id)`** — pulls comment id/parent/author/body/score.

Helpers:
- `_bare_id` — strips Reddit type prefixes (`t1_`, `t3_`, etc.).
- `_timestamp` — normalizes epoch, ISO string, or `datetime` to a UTC-aware `datetime`.
- `_codes` — deduplicates and sorts the `jav_codes` list.

### `repository.py`
`RedditRepository` — the class scrapers actually call.
- `RedditRepository.from_environment()` — opens a connection and ensures tables exist.
- `save_post_and_comments(post_data, comments)` — upserts the post and each comment inside a single transaction. Every comment insert is wrapped in a `SAVEPOINT` so one bad comment rolls back only itself. Upserts use `ON CONFLICT ... DO UPDATE` with `COALESCE(EXCLUDED.x, existing.x)` so partial data never overwrites previously-saved values, and `scraped_at` is refreshed on every touch.
- `close()` — closes the underlying connection.

### `manual_load/posts_load.py`
Placeholder for a manual bulk-load script (currently empty).

---

## Execution Steps

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure PostgreSQL credentials via `.env`
Credentials live in `database/.env`. It is git-ignored. `database/connection.py` auto-loads it on import (walks upward from the module and picks the first `.env` it finds, so `database/.env` wins over any workspace-root `.env`).

Copy the template and edit values:
```bash
cp .env.example database/.env
```

Example contents:
```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=redinst
POSTGRES_USER=postgres
POSTGRES_PASSWORD=1234
```

Any variable already set in the shell takes precedence over the `.env` value.

### 3. Create the tables (one-time)
Run from the workspace root:
```bash
python database/create_tables.py
```
Expected output: `Reddit database tables are ready.`

### 4. Use the repository from scraper code
`connection.py`, `models.py`, and `repository.py` are library modules — do not run them directly. Import and use them:
```python
from database import RedditRepository

repo = RedditRepository.from_environment()
try:
    repo.save_post_and_comments(post_dict, comment_dicts)
finally:
    repo.close()
```

### 5. (Optional) Manual bulk load
Once `manual_load/posts_load.py` is implemented, run it after step 3:
```bash
python database/manual_load/posts_load.py
```
