"""Small data models that adapt Reddit API dictionaries for persistence."""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping


def _timestamp(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    if isinstance(value, str):
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    raise ValueError(f"Unsupported timestamp value: {value!r}")


def _codes(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, (list, tuple, set)):
        raise ValueError("jav_codes must be a list, tuple, or set.")
    return sorted({str(code) for code in value})


def _bare_id(value: Any) -> str | None:
    if not value:
        return None
    return str(value).split("_", 1)[-1]


@dataclass(frozen=True)
class RedditPost:
    reddit_post_id: str
    subreddit: str | None = None
    title: str | None = None
    selftext: str | None = None
    post_url: str | None = None
    permalink: str | None = None
    score: int | None = None
    num_comments: int | None = None
    reddit_iframe_html: str | None = None
    created_utc: datetime | None = None
    upvoted_at: datetime | None = None
    jav_codes: list[str] | None = None
    is_processed: bool | None = None

    @classmethod
    def from_mapping(cls, post: Mapping[str, Any]) -> "RedditPost":
        post_id = post.get("id") or post.get("post_id") or post.get("reddit_post_id")
        if not post_id:
            raise ValueError("Reddit post is missing its ID.")
        embed = post.get("secure_media_embed") or post.get("media_embed") or {}
        return cls(
            reddit_post_id=_bare_id(post_id) or "",
            subreddit=post.get("subreddit"),
            title=post.get("title"),
            selftext=post.get("selftext", post.get("body")),
            post_url=post.get("url") or post.get("post_url"),
            permalink=post.get("permalink"),
            score=post.get("score"),
            num_comments=post.get("num_comments"),
            reddit_iframe_html=post.get("reddit_iframe_html")
            or (embed.get("content") if isinstance(embed, Mapping) else None),
            created_utc=_timestamp(post.get("created_utc")),
            upvoted_at=_timestamp(post.get("created_utc")),
            jav_codes=_codes(post.get("jav_codes")),
            is_processed=post.get("is_processed"),
        )


@dataclass(frozen=True)
class RedditComment:
    reddit_comment_id: str
    reddit_post_id: str
    parent_comment_id: str | None = None
    subreddit: str | None = None
    author: str | None = None
    body: str | None = None
    score: int | None = None
    created_utc: datetime | None = None
    jav_codes: list[str] | None = None
    is_processed: bool | None = None

    @classmethod
    def from_mapping(cls, comment: Mapping[str, Any], reddit_post_id: str) -> "RedditComment":
        comment_id = comment.get("id") or comment.get("reddit_comment_id")
        if not comment_id:
            raise ValueError("Reddit comment is missing its ID.")
        parent_id = str(comment.get("parent_id") or "")
        return cls(
            reddit_comment_id=_bare_id(comment_id) or "",
            reddit_post_id=_bare_id(reddit_post_id) or "",
            parent_comment_id=_bare_id(parent_id) if parent_id.startswith("t1_") else None,
            subreddit=comment.get("subreddit"),
            author=comment.get("author"),
            body=comment.get("body"),
            score=comment.get("score"),
            created_utc=_timestamp(comment.get("created_utc")),
            jav_codes=_codes(comment.get("jav_codes")),
            is_processed=comment.get("is_processed"),
        )
