"""UPSERT operations for Reddit posts and comments."""

import logging
from collections.abc import Iterable, Mapping
from typing import Any

from .connection import get_connection
from .create_tables import create_reddit_tables
from .models import RedditComment, RedditPost

LOGGER = logging.getLogger(__name__)

POST_UPSERT = """
INSERT INTO reddit_posts (
    reddit_post_id, subreddit, title, selftext, post_url, permalink, score,
    num_comments, reddit_iframe_html, created_utc, upvoted_at, jav_codes, is_processed
) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (reddit_post_id) DO UPDATE SET
    subreddit = EXCLUDED.subreddit,
    title = EXCLUDED.title,
    selftext = EXCLUDED.selftext,
    post_url = EXCLUDED.post_url,
    permalink = EXCLUDED.permalink,
    score = COALESCE(EXCLUDED.score, reddit_posts.score),
    num_comments = COALESCE(EXCLUDED.num_comments, reddit_posts.num_comments),
    reddit_iframe_html = COALESCE(EXCLUDED.reddit_iframe_html, reddit_posts.reddit_iframe_html),
    created_utc = COALESCE(EXCLUDED.created_utc, reddit_posts.created_utc),
    upvoted_at = COALESCE(EXCLUDED.upvoted_at, reddit_posts.upvoted_at),
    scraped_at = CURRENT_TIMESTAMP,
    jav_codes = COALESCE(EXCLUDED.jav_codes, reddit_posts.jav_codes),
    is_processed = COALESCE(EXCLUDED.is_processed, reddit_posts.is_processed)
"""

COMMENT_UPSERT = """
INSERT INTO reddit_comments (
    reddit_comment_id, reddit_post_id, parent_comment_id, subreddit, author, body,
    score, created_utc, jav_codes, is_processed
) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (reddit_comment_id) DO UPDATE SET
    reddit_post_id = EXCLUDED.reddit_post_id,
    parent_comment_id = EXCLUDED.parent_comment_id,
    subreddit = EXCLUDED.subreddit,
    author = EXCLUDED.author,
    body = EXCLUDED.body,
    score = COALESCE(EXCLUDED.score, reddit_comments.score),
    created_utc = COALESCE(EXCLUDED.created_utc, reddit_comments.created_utc),
    scraped_at = CURRENT_TIMESTAMP,
    jav_codes = COALESCE(EXCLUDED.jav_codes, reddit_comments.jav_codes),
    is_processed = COALESCE(EXCLUDED.is_processed, reddit_comments.is_processed)
"""


def _post_values(post: RedditPost) -> tuple[Any, ...]:
    return tuple(post.__dict__.values())


def _comment_values(comment: RedditComment) -> tuple[Any, ...]:
    return tuple(comment.__dict__.values())


class RedditRepository:
    """Persist Reddit data with safe upserts and per-comment savepoints."""

    def __init__(self, connection: Any) -> None:
        self.connection = connection

    @classmethod
    def from_environment(cls) -> "RedditRepository":
        connection = get_connection()
        try:
            create_reddit_tables(connection)
        except Exception:
            connection.close()
            raise
        return cls(connection)

    def close(self) -> None:
        self.connection.close()

    def save_post_and_comments(
        self, post_data: Mapping[str, Any], comments: Iterable[Mapping[str, Any]]
    ) -> int:
        """Upsert a post and its comments; invalid comments are logged and skipped."""
        post = RedditPost.from_mapping(post_data)
        saved_comments = 0
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(POST_UPSERT, _post_values(post))
                for index, comment_data in enumerate(comments):
                    try:
                        comment = RedditComment.from_mapping(comment_data, post.reddit_post_id)
                    except Exception as error:
                        LOGGER.exception(
                            "Could not prepare Reddit comment for post %s: %s",
                            post.reddit_post_id,
                            error,
                        )
                        continue

                    cursor.execute(f"SAVEPOINT reddit_comment_{index}")
                    try:
                        cursor.execute(COMMENT_UPSERT, _comment_values(comment))
                        cursor.execute(f"RELEASE SAVEPOINT reddit_comment_{index}")
                        saved_comments += 1
                    except Exception as error:
                        cursor.execute(f"ROLLBACK TO SAVEPOINT reddit_comment_{index}")
                        LOGGER.exception("Could not save Reddit comment for post %s: %s", post.reddit_post_id, error)
            self.connection.commit()
            return saved_comments
        except Exception:
            self.connection.rollback()
            LOGGER.exception("Could not save Reddit post %s", post.reddit_post_id)
            raise
