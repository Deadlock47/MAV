import requests

BIN_ID = "69a2705bae596e708f514788"
headers = {
    "X-Master-Key": "$2a$10$nBKL.pkkw5.oXwEHSWyPBO6KgMJNRY4LJcLu8HVsO.ggbU2VvODtW",
    "Content-Type": "application/json"
}
write_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
read_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"



# Step 1: Get current data
response = requests.get(read_url + "/latest", headers=headers)
data = response.json()['record'] 
print(f"Current data in JSONBin: {data}")
# requests.put(write_url, headers=headers, json=data)