import praw
import re
from collections import defaultdict

# Initialize Reddit client with your credentials
reddit = praw.Reddit(
    client_id="ChiMDjfsJnpv5LdkH7RA8Q",
    client_secret="LxkaHxbzqVQx_XLNEsf4ig4bg_adoQ",
    user_agent="deadlock",
    username="rsaasrwebseries",
    password="asrasr123"
)
print("Scopes:", reddit.auth.scopes())
try:
    # url = reddit.auth.url(["identity", "history"], "random_state", "permanent")

    print("Open this URL in browser:")
    # print(url)

    # code = input("Paste the code here: ")

    # refresh_token = reddit.auth.authorize(code)

    # print("\nYOUR REFRESH TOKEN:")
    # print(refresh_token)
    print("Read only:", reddit.read_only)

    user = reddit.user.me()
    
    if user:
        print("SUCCESS:", user.name)
    else:
        print("Failed: user.me() returned None")
except Exception as e:
    print("Connection failed:", e)

def normalize_jav_code(code):
    """
    Normalize JAV codes to standard format (PREFIX-NUMBER)
    Examples: JUQ-158, juq340, DASS 320 -> DASS-320
    """
    # Remove spaces and convert to uppercase
    code = code.replace(" ", "").upper()
    
    # Extract prefix and number using regex
    match = re.match(r'([A-Z]+)(\d+)', code)
    if match:
        prefix = match.group(1)
        number = match.group(2)
        # Pad number with zeros to ensure consistency (e.g., 320 -> 320, 158 -> 158)
        return f"{prefix}-{number}"
    return None

def extract_jav_codes(text):
    """
    Extract all JAV codes from text
    Matches patterns like: JUQ-158, juq340, DASS 320, etc.
    """
    if not text:
        return set()
    
    # Pattern to match JAV codes: prefix (2-4 letters) followed by optional dash/space and numbers
    pattern = r'\b([A-Za-z]+)\s*[-\s]?(\d{2,4})\b'
    matches = re.findall(pattern, text)
    
    jav_codes = set()
    for prefix, number in matches:
        # Filter to only actual JAV codes (prefix length 2-4)
        if 2 <= len(prefix) <= 4:
            code = f"{prefix}{number}"
            normalized = normalize_jav_code(code)
            if normalized:
                jav_codes.add(normalized)
    
    return jav_codes

def process_upvoted_posts():
    """
    Fetch all upvoted posts, extract JAV codes from titles and comments,
    and save them to a file.
    """
    jav_codes_data = defaultdict(lambda: {
        'post_title': '',
        'comments': [],
        'codes': set()
    })
    
    print("Fetching upvoted posts...")
    
    # Fetch upvoted posts (up to 1000)
    upvoted_posts = list(reddit.user.me().upvoted(limit=None))
    
    for idx, post in enumerate(upvoted_posts, 1):
        try:
            print(f"Processing post {idx}/{len(upvoted_posts)}: {post.title[:50]}...")
            
            # Extract JAV codes from post title
            title_codes = extract_jav_codes(post.title)
            post_body_codes = extract_jav_codes(post.selftext) if hasattr(post, 'selftext') else set()
            
            all_codes = title_codes | post_body_codes
            
            # Fetch all comments for this post
            post.comments.replace_more(limit=None)
            comments_text = []
            
            for comment in post.comments.list():
                try:
                    comment_codes = extract_jav_codes(comment.body)
                    all_codes |= comment_codes
                    if comment_codes:
                        comments_text.append(f"  - {comment.body[:100]}")
                except Exception as e:
                    print(f"Error processing comment: {e}")
                    continue
            
            # Store data if JAV codes found
            if all_codes:
                jav_codes_data[post.id]['post_title'] = post.title
                jav_codes_data[post.id]['comments'] = comments_text
                jav_codes_data[post.id]['codes'] = all_codes
                print(f"  Found {len(all_codes)} JAV codes: {', '.join(sorted(all_codes))}")
        
        except Exception as e:
            print(f"Error processing post: {e}")
            continue
    
    # Save results to file
    save_to_file(jav_codes_data)
    
    return jav_codes_data

def save_to_file(jav_codes_data):
    """
    Save extracted JAV codes to a formatted file
    """
    output_file = "extracted_jav_codes_upvoted.txt"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("EXTRACTED JAV CODES FROM UPVOTED POSTS\n")
        f.write("=" * 80 + "\n\n")
        
        # Collect all unique codes
        all_unique_codes = set()
        
        for post_id, data in jav_codes_data.items():
            if data['codes']:
                f.write(f"Post: {data['post_title']}\n")
                f.write(f"Post ID: {post_id}\n")
                f.write("-" * 80 + "\n")
                
                f.write("JAV Codes found:\n")
                for code in sorted(data['codes']):
                    f.write(f"  • {code}\n")
                    all_unique_codes.add(code)
                
                if data['comments']:
                    f.write("\nRelevant Comments:\n")
                    for comment in data['comments'][:5]:  # Show first 5 comments
                        f.write(f"{comment}\n")
                
                f.write("\n" + "=" * 80 + "\n\n")
        
        # Summary section
        f.write("\n" + "=" * 80 + "\n")
        f.write("SUMMARY - ALL UNIQUE JAV CODES\n")
        f.write("=" * 80 + "\n\n")
        
        sorted_codes = sorted(all_unique_codes)
        for code in sorted_codes:
            f.write(f"{code}\n")
        
        f.write(f"\n\nTotal Unique JAV Codes Found: {len(sorted_codes)}\n")
    
    print(f"\nResults saved to '{output_file}'")

# Fetch your upvoted posts (up to 1000) and extract JAV codes
if __name__ == "__main__":
    process_upvoted_posts()
