# trailer_codes — Execution Steps

For each JAV code, find video/trailer links across multiple mirror sites and sync the results to JSONBin.

## Files

| File | Purpose |
|------|---------|
| `main.py` | Main loop: reads `codes.json` (or `CODES.txt`), scrapes trailer links, writes `trailer_links.json` + `not_found_codes.json`, pushes to JSONBin. |
| `fetch_video.py` | Fetches trailer HTML/URLs for a single code; helper used by `main.py`. |
| `checks.py` | Diffs current codes vs the ones already stored on JSONBin. |
| `jsn.py` | JSONBin read helper (dumps current bin content). |
| `not_present.py` | Lists codes in `codes.txt` that are missing from `trailer_links.json`. |
| `CODES.txt` / `all_javs.txt` | Master lists of codes. |
| `codes.json` / `codes_not_present*.txt` | Working inputs and diffs. |
| `trailer_links.json` | Output: `code -> [trailer URLs]`. |
| `not_found_codes.json` | Output: codes with no trailer found. |
| `reddit_comments.json`, `video_search_results.json` | Intermediate caches. |

## Prerequisites

- Codes to search live in `codes.json` (list of strings). Refresh from `reddit_comments/` output first:
  ```bash
  python -m reddit_autom.reddit_comments --to s05
  cp reddit_autom/reddit_comments/data/derived/all_codes.json reddit_autom/trailer_codes/codes.json
  ```
  (Or edit `codes.json` manually.)
- JSONBin creds are currently **hardcoded** at the top of `main.py`, `fetch_video.py`, and `backup.py`. Move to env vars if you rotate them.

## Order (from workspace root)

### 1. Fetch trailer links
```bash
python reddit_autom/trailer_codes/main.py
```
Writes `trailer_links.json` and `not_found_codes.json`; pushes both to JSONBin.

### 2. Inspect what's missing
```bash
python reddit_autom/trailer_codes/not_present.py    # codes in codes.txt but not in trailer_links.json
python reddit_autom/trailer_codes/checks.py         # sanity diff vs JSONBin
python reddit_autom/trailer_codes/jsn.py            # dump JSONBin content
```

### 3. Backfill single codes (ad-hoc)
```bash
python reddit_autom/trailer_codes/fetch_video.py    # edit the code list at top before running
```

## Notes

- Every script writes into its own folder — always run from the workspace root so relative paths line up.
- Delete or archive `codes_not_present copy.txt` when you're done; it's an editor duplicate.
