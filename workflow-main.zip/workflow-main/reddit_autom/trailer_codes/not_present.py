
import json


json1 = open('trailer_links.json', 'r')
data = json.load(json1)

json2 = open('codes.txt', 'r')
codes = json2.read().split(',')

not_found_codes = [code for code in codes if code not in data]
print(f"Codes without trailers: {not_found_codes}")