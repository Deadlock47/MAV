import requests
import json
import time
from typing import List, Dict


BIN_ID = "69a2705bae596e708f514788"
headers = {
    "X-Master-Key": "$2a$10$nBKL.pkkw5.oXwEHSWyPBO6KgMJNRY4LJcLu8HVsO.ggbU2VvODtW",
    "Content-Type": "application/json"
}
write_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
read_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"

writer = open('trailer_links.json', 'r')
collate_data = json.load(writer)
writer.close()
print("Trailer links loaded from trailer_links.json")

print(f"Current data in JSONBin: {collate_data}")
requests.put(write_url, headers=headers, json=collate_data)

print(f"Trailer links saved to JSONBin: {len(collate_data)}")
print("====================================")
# print(f"Codes not found: {not_found_list}")
# print("====================================")


# API endpoint for JAV code lookup
# API_BASE_URL = "https://r18.dev/videos/vod/movies/detail/-/id=${data.content_id}/"  # Example API - adjust to your actual API endpoint
# TIMEOUT = 10

# def read_jav_codes_from_file(filename: str) -> List[str]:
#     """
#     Read comma-separated JAV codes from a file and convert to array
#     Example file content: DASS-320, JUQ-158, DORE-123, ABP-456
#     """
#     try:
#         with open(filename, 'r', encoding='utf-8') as f:
#             content = f.read().strip()
        
#         # Split by comma and clean up whitespace
#         codes = [code.strip().upper() for code in content.split(',') if code.strip()]
        
#         print(f"Successfully read {len(codes)} JAV codes from '{filename}'")
#         print(f"Codes: {codes[:10]}{'...' if len(codes) > 10 else ''}")
        
#         return codes
    
#     except FileNotFoundError:
#         print(f"Error: File '{filename}' not found")
#         return []
#     except Exception as e:
#         print(f"Error reading file: {e}")
#         return []

# def check_code_via_api(code: str) -> Dict:
#     """
#     Check if a JAV code exists via API
#     Returns result with status and any found data
#     """
#     result = {
#         'code': code,
#         'exists': False,
#         'status_code': None,
#         'data': None,
#         'error': None
#     }
#     lower_code = 'ure-075'
#     try:
#         # Try different search endpoints/patterns
#         search_urls = [
#             f"https://r18.dev/videos/vod/movies/detail/-/dvd_id=ure075/json"
#         ]
        
#         for url in search_urls:
#             try:
#                 print(f"Checking code '{code}' at URL: {url}")
#                 response = requests.get(url, timeout=TIMEOUT)
#                 print(response.status_code)
#                 result['status_code'] = response.status_code
                
#                 if response.status_code == 200:
#                     result['exists'] = True
#                     # Try to parse JSON response
#                     try:
#                         result['data'] = response.json()
#                     except:
#                         # If not JSON, store text response
#                         result['data'] = response.text[:200]  # Store first 200 chars
#                     break
                
#             except requests.exceptions.RequestException as req_error:
#                 result['error'] = str(req_error)
#                 continue
    
#     except Exception as e:
#         result['error'] = str(e)
    
#     return result

# def check_all_codes(codes: List[str], api_endpoint: str = None) -> Dict:
#     """
#     Check all JAV codes against API and return results
#     """
#     results = {
#         'total': len(codes),
#         'found': 0,
#         'not_found': 0,
#         'errors': 0,
#         'details': []
#     }
    
#     print("\n" + "=" * 80)
#     print("CHECKING JAV CODES VIA API")
#     print("=" * 80 + "\n")
    
#     for idx, code in enumerate(codes, 1):
#         print(f"[{idx}/{len(codes)}] Checking: {code}...", end=" ")
        
#         result = check_code_via_api(code)
        
#         if result['error']:
#             print(f"ERROR: {result['error']}")
#             results['errors'] += 1
#         elif result['exists']:
#             print(f"✓ FOUND (Status: {result['status_code']})")
#             results['found'] += 1
#         else:
#             print(f"✗ NOT FOUND (Status: {result['status_code']})")
#             results['not_found'] += 1
        
#         results['details'].append(result)
        
#         # Add delay between requests to avoid rate limiting
#         time.sleep(0.5)
    
#     return results

# def save_results_to_file(results: Dict, output_file: str = "jav_api_check_results.txt"):
#     """
#     Save API check results to a formatted file
#     """
#     with open(output_file, 'w', encoding='utf-8') as f:
#         f.write("=" * 80 + "\n")
#         f.write("JAV CODE API VERIFICATION RESULTS\n")
#         f.write("=" * 80 + "\n\n")
        
#         # Summary
#         f.write("SUMMARY\n")
#         f.write("-" * 80 + "\n")
#         f.write(f"Total Codes Checked: {results['total']}\n")
#         f.write(f"Found (Exist in DB): {results['found']}\n")
#         f.write(f"Not Found: {results['not_found']}\n")
#         f.write(f"Errors: {results['errors']}\n")
#         f.write(f"Success Rate: {(results['found'] / results['total'] * 100):.2f}%\n\n")
        
#         # Detailed results
#         f.write("=" * 80 + "\n")
#         f.write("DETAILED RESULTS\n")
#         f.write("=" * 80 + "\n\n")
        
#         # Found codes
#         found_codes = [d for d in results['details'] if d['exists']]
#         if found_codes:
#             f.write("FOUND CODES:\n")
#             f.write("-" * 80 + "\n")
#             for detail in found_codes:
#                 f.write(f"✓ {detail['code']}\n")
#                 f.write(f"  Status: {detail['status_code']}\n")
#                 if detail['data']:
#                     f.write(f"  Data: {str(detail['data'])[:200]}\n")
#                 f.write("\n")
        
#         # Not found codes
#         not_found_codes = [d for d in results['details'] if not d['exists'] and not d['error']]
#         if not_found_codes:
#             f.write("\nNOT FOUND CODES:\n")
#             f.write("-" * 80 + "\n")
#             for detail in not_found_codes:
#                 f.write(f"✗ {detail['code']} (Status: {detail['status_code']})\n")
        
#         # Error codes
#         error_codes = [d for d in results['details'] if d['error']]
#         if error_codes:
#             f.write("\nERROR CODES:\n")
#             f.write("-" * 80 + "\n")
#             for detail in error_codes:
#                 f.write(f"⚠ {detail['code']}\n")
#                 f.write(f"  Error: {detail['error']}\n\n")
        
#         # Summary list
#         f.write("\n" + "=" * 80 + "\n")
#         f.write("SUMMARY LIST\n")
#         f.write("=" * 80 + "\n\n")
        
#         f.write("FOUND:\n")
#         for detail in found_codes:
#             f.write(f"{detail['code']}\n")
        
#         f.write("\nNOT FOUND:\n")
#         for detail in not_found_codes:
#             f.write(f"{detail['code']}\n")
    
#     print(f"\nResults saved to '{output_file}'")

# def main():
#     """
#     Main function to orchestrate the JAV code checking process
#     """
#     # Read codes from file
#     jav_codes = read_jav_codes_from_file("all_javs.txt")
    
#     if not jav_codes:
#         print("No JAV codes found to check")
#         return
    
#     # Check all codes via API
#     results = check_all_codes(jav_codes)
    
#     # Save results to file
#     save_results_to_file(results)
    
#     # Print summary
#     print("\n" + "=" * 80)
#     print("SUMMARY")
#     print("=" * 80)
#     print(f"Total Codes: {results['total']}")
#     print(f"Found: {results['found']}")
#     print(f"Not Found: {results['not_found']}")
#     print(f"Errors: {results['errors']}")
#     print(f"Success Rate: {(results['found'] / results['total'] * 100):.2f}%")

# if __name__ == "__main__":
#     main()
