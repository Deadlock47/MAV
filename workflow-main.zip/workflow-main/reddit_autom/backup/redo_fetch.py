import json
import time
from urllib import response
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import requests

import undetected_chromedriver as uc
# Setup chrome options
# chrome_options = Options()

# Enable performance logging (required)
# chrome_options.set_capability("goog:loggingPrefs", {"performance": "ALL"})
BIN_ID = "69a2705bae596e708f514788"
headers = {
    "X-Master-Key": "$2a$10$nBKL.pkkw5.oXwEHSWyPBO6KgMJNRY4LJcLu8HVsO.ggbU2VvODtW",
    "Content-Type": "application/json"
}
write_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
read_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"

CODES_BIN_ID = '69a270df43b1c97be9a57a18'
codes_read_url = f"https://api.jsonbin.io/v3/b/{CODES_BIN_ID}"

def update_codes_file():
    data = requests.get(codes_read_url, headers=headers)
    codes = data.json()['record']['codes']
    print(f"Codes to fetch trailers for: {len(codes)}")
    #####
    write_codes = open('codes.json', 'w')
    json.dump(codes, write_codes, indent=4)
    write_codes.close()

def update_trailer_links_file():
    response = requests.get(read_url + "/latest", headers=headers)
    data = response.json()['record']
    writer = open('trailer_links.json', 'w')
    json.dump(data, writer, indent=4)
    writer.close()


update_codes_file()
update_trailer_links_file()


# Step 1: Get current data

# Optional (visible browser helps debugging)
# chrome_options.add_argument("--headless")
# print(data)
# Start driver

options = webdriver.ChromeOptions()

# enable performance logs
options.set_capability("goog:loggingPrefs", {"performance": "ALL"})
# options.add_argument(
#     r"--user-data-dir=C:\Users\YourUser\AppData\Local\Google\Chrome\User Data"
# )
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/145.0 Safari/537.36"
)
options.add_argument("--start-maximized")
# options.binary_location = r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

not_found_list = []
# # json1 = open('CODES.txt', 'r')
# json1 = json1.read().split(',')
json1 = open('codes.json','r')
json1 = json.load(json1)
codes = [code.strip() for code in json1]
print(f"Codes to fetch trailers for: {len(codes)}")
# not_found_list = []
# # codes = ['MIDE-365','MIMK-197']
# # codes = ['MIDE-365','MIMK-197','IPX-169','ROE-170']
####################




json1 = open('trailer_links.json', 'r')
data = json.load(json1)

collate_data = data if isinstance(data, dict) else {}

codes_not_done = [ key for key in collate_data.keys() if  len(collate_data[key]) == 0 ]

print("Codes with No Trailer : ",len(codes_not_done))

def fetch_code_trailer(code):
    if code in collate_data and len(collate_data[code]) > 0:
        print(f"Trailer links for code {code} already fetched, skipping...")
        return
    try:
        # url_code = code.split('-')[0].lower() + '00' +code.split('-')[1]
        url = "https://javtrailers.com/search/"+code  # replace with actual page URL
        driver.get(url)

        items = driver.find_elements("xpath", '//div[contains(@class,"col-4 col-md-3 col-lg-2")]//a')
        items[0].click()
        driver.execute_script("window.scrollBy(0,500)")
        time.sleep(2)
        driver.execute_script("window.scrollBy(0,-500)")
        print("wait for video to load")
        time.sleep(7)
        play_button = driver.find_element("xpath", '//button[contains(@class,"vjs-big-play-button")]')
        play_button.click()
        time.sleep(7)
        timeout = 30
        start = time.time()

        driver.execute_script("window.scrollBy(0,500)")
        time.sleep(2)
        driver.execute_script("window.scrollBy(0,-500)")
        video_urls = set()
        print("Monitoring network logs for video URLs...")
        while time.time() - start < timeout:
            logs = driver.get_log("performance")
            print(f"Fetched {len(logs)} logs, checking for video URLs...")
            for i in range(len(logs)):
                log = logs[i]
                message = json.loads(log["message"])["message"]

                if message["method"] == "Network.responseReceived":
                    url = message["params"]["response"]["url"]

                    if any(ext in url for ext in [".mp4", ".m3u8"]):
                        video_urls.add(url)

            if video_urls:
                break

            time.sleep(1)
        
        collate_data[code] = list(video_urls)
        print(video_urls)

    except Exception as e:
        not_found_list.append(code)
        print(f"Error fetching trailer for code {code}: {e}")


for code in codes_not_done:
    print("="*50)
    print(f"Fetching trailer for code: {code} || {type(code)}")
    fetch_code_trailer(code)
    time.sleep(5)  # wait before fetching the next trailer
    print("="*50)

    
writer = open('trailer_links.json', 'w')
json.dump(collate_data, writer, indent=4)
writer.close()
print("Trailer links saved to trailer_links.json")

print(f"Current data in JSONBin: {collate_data}")
requests.put(write_url, headers=headers, json=collate_data)

print(f"Trailer links saved to JSONBin: {collate_data}")
print("====================================")
print(f"Codes not found: {not_found_list}")
print("====================================")