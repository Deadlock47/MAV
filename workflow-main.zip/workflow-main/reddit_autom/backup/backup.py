import json
import time
import requests

BIN_ID = "69a2705bae596e708f514788"
headers = {
    "X-Master-Key": "$2a$10$nBKL.pkkw5.oXwEHSWyPBO6KgMJNRY4LJcLu8HVsO.ggbU2VvODtW",
    "Content-Type": "application/json"
}
write_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
read_url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"

CODES_BIN_ID = '69a270df43b1c97be9a57a18'
codes_read_url = f"https://api.jsonbin.io/v3/b/{CODES_BIN_ID}"

data = requests.get(codes_read_url, headers=headers)
codes = data.json()['record']['codes']
print(f"Codes to fetch trailers for: {len(codes)}")
    #####
open('codes_backup.json', 'w').write(json.dumps(data.json()['record']['codes'], indent=4))

response = requests.get(read_url, headers=headers)
data = response.json()['record']
print(data , len(data))
print("Fetching trailer links...")
writer = open('trailer_links_backup.json', 'w')
json.dump(data, writer, indent=4)
writer.close()
print("Backup completed successfully.")