# backup — Execution Steps

One-shot snapshot of the trailer-codes state on JSONBin into local `*_backup.json` files.

## Files

| File | Purpose |
|------|---------|
| `backup.py` | Pulls current codes + trailer links from JSONBin and writes them to `codes_backup.json` and `trailer_links_backup.json`. |
| `redo_fetch.py` | Refetches missing codes (uses Selenium / undetected-chromedriver). Ad-hoc — edit the code list at the top before running. |
| `codes.json` / `codes_backup.json` | Cached / backup copies of the codes list. |
| `trailer_links.json` / `trailer_links_backup.json` | Cached / backup copies of the trailer links map. |

## Order

### 1. Take a backup
```bash
python reddit_autom/backup/backup.py
```
Overwrites `codes_backup.json` and `trailer_links_backup.json` in this folder.

### 2. Refetch on demand (optional)
```bash
python reddit_autom/backup/redo_fetch.py
```
Requires Chrome + `undetected-chromedriver` installed.

## Notes

- Runs are **independent** of `reddit_autom/trailer_codes/*` — this folder just mirrors JSONBin.
- JSONBin creds are hardcoded at the top of the scripts.
