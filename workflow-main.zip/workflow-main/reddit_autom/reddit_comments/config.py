"""Central paths + environment configuration for the reddit_comments pipeline."""

from __future__ import annotations

import os
import sys
from pathlib import Path


PACKAGE_DIR = Path(__file__).resolve().parent
REDDIT_AUTOM_DIR = PACKAGE_DIR.parent
WORKSPACE_DIR = REDDIT_AUTOM_DIR.parent

if str(WORKSPACE_DIR) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_DIR))


def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    candidates = [
        WORKSPACE_DIR / "database" / ".env",
        WORKSPACE_DIR / ".env",
        PACKAGE_DIR / ".env",
    ]
    for env_path in candidates:
        if env_path.is_file():
            load_dotenv(env_path, override=False)


_load_dotenv()


DATA_DIR = PACKAGE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
DERIVED_DIR = DATA_DIR / "derived"
CHECKS_DIR = DATA_DIR / "checks"

CONSOLE_DIR = PACKAGE_DIR / "console"
TRAILER_CODES_DIR = REDDIT_AUTOM_DIR / "trailer_codes"

UPVOTED_POSTS_FILE = RAW_DIR / "all_upvoted_posts.json"
COMMENTS_FILE = RAW_DIR / "comments.json"
LEGACY_COMMENTS_FILE = RAW_DIR / "comments.legacy.json"

UPVOTES_CODES_FILE = DERIVED_DIR / "extract_codes_upvotes.json"
COMMENTS_CODES_FILE = DERIVED_DIR / "extract_codes_comments.json"
ALL_CODES_FILE = DERIVED_DIR / "all_codes.json"

FOUND_CODES_TXT = CHECKS_DIR / "found_codes.txt"
FOUND_CODES_JSON = CHECKS_DIR / "found_codes.json"
NOT_FOUND_CODES_TXT = CHECKS_DIR / "not_found_codes.txt"
NOT_FOUND_CODES_JSON = CHECKS_DIR / "not_found_codes.json"
FINAL_CODES_TXT = CHECKS_DIR / "final_codes_add_to_app.txt"
SOURCE_CODES_TXT = TRAILER_CODES_DIR / "CODES.txt"

CONSOLE_POSTS_FILE = CONSOLE_DIR / "console_posts.json"
CONSOLE_COMMENTS_FILE = CONSOLE_DIR / "console_comments.json"
CONSOLE_UPVOTES_FILE = CONSOLE_DIR / "console_upvotes.json"

REDDIT_USERNAME = os.getenv("REDDIT_USERNAME", "")
REDDIT_ACCESS_TOKEN = os.getenv("REDDIT_ACCESS_TOKEN", "")
REDDIT_USER_AGENT = os.getenv("REDDIT_USER_AGENT", "reddit-autom/1.0")

# post_id sentinel that stops the upvotes scraper on step 1 (matches previous script).
UPVOTES_STOP_AT_POST_ID = os.getenv("REDDIT_STOP_AT_POST_ID", "1w1hbkt")

# r18.dev rate limit for step 6.
R18_RATE_LIMIT_DELAY_SECONDS = float(os.getenv("R18_RATE_LIMIT_DELAY", "1.8"))


def ensure_data_dirs() -> None:
    for directory in (RAW_DIR, DERIVED_DIR, CHECKS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def require_reddit_token() -> str:
    if not REDDIT_ACCESS_TOKEN:
        raise SystemExit(
            "REDDIT_ACCESS_TOKEN is not set. Add it to database/.env "
            "(and REDDIT_USERNAME) before running this stage."
        )
    return REDDIT_ACCESS_TOKEN
