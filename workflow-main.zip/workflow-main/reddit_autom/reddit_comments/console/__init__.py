"""Alternate ingest for posts/comments dumped from the browser console."""
