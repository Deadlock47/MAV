# console — Execution Steps

Alternate entry to the pipeline when Reddit OAuth isn't practical: paste JSON produced by a browser-console script into these files, then load into Postgres.

## Files

| File | Purpose |
|------|---------|
| `console_posts.json` | Object keyed by `post_id`; each value is a **list** containing the post dict. |
| `console_comments.json` | Object keyed by `post_id`; each value is the list of comment dicts. |
| `console_upvotes.json` | Optional upvote metadata dump (not used by `load.py`). |
| `load.py` | Reads the two files above and upserts them via `database.RedditRepository`. |
| `notes.md` | Additional context. |

## Order (from workspace root)

### 1. Ensure schema is present
```bash
python database/create_tables.py
```

### 2. Populate the two JSON files
Manually paste the browser-console output into:
- `reddit_autom/reddit_comments/console/console_posts.json`
- `reddit_autom/reddit_comments/console/console_comments.json`

### 3. Load into Postgres
```bash
python -m reddit_autom.reddit_comments.console.load
```

Requires `POSTGRES_*` vars in `database/.env`.

## Skipping the scrapers

After the load, the derived-code stages of the main pipeline still work — jump straight to s03:

```bash
python -m reddit_autom.reddit_comments --from s03
```
