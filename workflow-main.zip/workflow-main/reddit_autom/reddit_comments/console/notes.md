# Console ingest

Alternate path when Reddit's OAuth flow isn't practical: paste the JSON output
from a browser-console script into these files, then run the loader.

## Files

- `console_posts.json` — object keyed by post id, each value is a **list** containing the post dict.
- `console_comments.json` — object keyed by post id, each value is the list of comment dicts.
- `console_upvotes.json` — optional dump of upvote metadata (not used by `load.py`).

## Load into Postgres

Requires `POSTGRES_*` env vars in `database/.env`.

```bash
python -m reddit_autom.reddit_comments.console.load
```
