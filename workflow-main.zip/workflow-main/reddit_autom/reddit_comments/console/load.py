"""Load browser-console dumps (console/console_posts.json + console_comments.json) into Postgres."""

from __future__ import annotations

import logging

from database import RedditRepository

from ..common import read_json
from ..config import CONSOLE_COMMENTS_FILE, CONSOLE_POSTS_FILE


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
LOGGER = logging.getLogger(__name__)


def load_data_to_postgres() -> None:
    LOGGER.info("Reading posts file: %s", CONSOLE_POSTS_FILE)
    posts_data = read_json(CONSOLE_POSTS_FILE, default=None)
    if not isinstance(posts_data, dict):
        raise SystemExit(f"{CONSOLE_POSTS_FILE} must contain a JSON object.")

    LOGGER.info("Reading comments file: %s", CONSOLE_COMMENTS_FILE)
    comments_data = read_json(CONSOLE_COMMENTS_FILE, default=None)
    if not isinstance(comments_data, dict):
        raise SystemExit(f"{CONSOLE_COMMENTS_FILE} must contain a JSON object.")

    LOGGER.info("Posts found: %s", len(posts_data))
    LOGGER.info("Comment groups found: %s", len(comments_data))

    repository = RedditRepository.from_environment()
    successful = failed = comments_saved = 0

    try:
        for post_id, post_wrap in posts_data.items():
            if not isinstance(post_wrap, list) or not post_wrap or not isinstance(post_wrap[0], dict):
                LOGGER.warning("Skipping invalid post item for %s", post_id)
                continue

            comments_details = comments_data.get(post_id, [])
            if not isinstance(comments_details, list):
                comments_details = []
            for comment in comments_details:
                if isinstance(comment, dict):
                    comment["reddit_post_id"] = post_id

            LOGGER.info("Post %s has %s comments", post_id, len(comments_details))
            try:
                saved = repository.save_post_and_comments(
                    post_data=post_wrap[0], comments=comments_details
                )
                successful += 1
                comments_saved += saved
                LOGGER.info("Saved post %s with %s comments", post_id, saved)
            except Exception as error:
                failed += 1
                LOGGER.exception("Failed to save post %s: %s", post_id, error)

        LOGGER.info("=" * 60)
        LOGGER.info("DATABASE LOAD COMPLETED")
        LOGGER.info("Successful posts: %s", successful)
        LOGGER.info("Failed posts: %s", failed)
        LOGGER.info("Total comments saved: %s", comments_saved)
        LOGGER.info("=" * 60)
    finally:
        repository.close()
        LOGGER.info("Database connection closed")


def main() -> None:
    load_data_to_postgres()


if __name__ == "__main__":
    main()
