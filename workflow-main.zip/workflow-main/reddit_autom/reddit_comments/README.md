# reddit_comments pipeline

Scrapes upvoted Reddit posts + their comment threads, extracts JAV codes from
titles and comment bodies, checks each code against r18.dev, and diffs the
results against the app's existing `CODES.txt`.

## Layout

```
reddit_comments/
├── __main__.py               # one-command runner
├── config.py                 # env vars + data paths
├── common.py                 # extract_jav_codes(), read_json(), write_json()
├── README.md                 # this file
│
├── pipeline/                 # numbered stages (run in order)
│   ├── s01_scrape_upvotes.py
│   ├── s02_scrape_comments.py
│   ├── s03_extract_codes_upvotes.py
│   ├── s04_extract_codes_comments.py
│   ├── s05_collect_codes.py
│   ├── s06_check_codes.py
│   └── s07_final_codes_txt.py
│
├── console/                  # optional: load browser-console JSON dumps into Postgres
│   ├── load.py
│   ├── notes.md
│   ├── console_posts.json
│   ├── console_comments.json
│   └── console_upvotes.json
│
├── data/                     # regenerable artifacts (safe to wipe)
│   ├── raw/                  # s01/s02 outputs
│   │   ├── all_upvoted_posts.json
│   │   ├── comments.json
│   │   └── comments.legacy.json
│   ├── derived/              # s03/s04/s05 outputs
│   │   ├── extract_codes_upvotes.json
│   │   ├── extract_codes_comments.json
│   │   └── all_codes.json
│   └── checks/               # s06/s07 outputs
│       ├── found_codes.txt
│       ├── not_found_codes.txt
│       ├── found_codes.json
│       ├── not_found_codes.json
│       └── final_codes_add_to_app.txt
│
└── legacy/                   # off the happy path, safe to delete
    ├── comments_scrape_trl.py
    └── test.py
```

## Configure

Add these to `database/.env` (loaded automatically by `config.py`):

```env
REDDIT_USERNAME=your_reddit_username
REDDIT_ACCESS_TOKEN=your_oauth_bearer_token
REDDIT_USER_AGENT=reddit-autom/1.0
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=redinst
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
```

Optional overrides:
- `REDDIT_STOP_AT_POST_ID` — `s01` stops paging when this id is seen (default `1w1hbkt`).
- `R18_RATE_LIMIT_DELAY` — seconds between r18.dev requests in `s06` (default `1.8`).

## Run

From the **workspace root** (`workflow-main/`):

```bash
python -m reddit_autom.reddit_comments             # run s01..s07 in order
python -m reddit_autom.reddit_comments --list      # print steps
python -m reddit_autom.reddit_comments --from s03  # skip scrapers, start at extraction
python -m reddit_autom.reddit_comments --only s05  # run one stage
python -m reddit_autom.reddit_comments --to s05    # stop after all_codes.json
python -m reddit_autom.reddit_comments --keep-going  # continue on stage errors
```

Load browser-console dumps instead of scraping:

```bash
python -m reddit_autom.reddit_comments.console.load
```

## Stage I/O

| Step | Inputs                                              | Outputs                                      |
|------|-----------------------------------------------------|----------------------------------------------|
| s01  | Reddit API (`REDDIT_ACCESS_TOKEN`)                  | `data/raw/all_upvoted_posts.json`            |
| s02  | `data/raw/all_upvoted_posts.json`, Reddit API       | `data/raw/comments.json`, Postgres upsert    |
| s03  | `data/raw/all_upvoted_posts.json`                   | `data/derived/extract_codes_upvotes.json`    |
| s04  | `data/raw/comments.json`                            | `data/derived/extract_codes_comments.json`   |
| s05  | `data/derived/extract_codes_{upvotes,comments}.json`| `data/derived/all_codes.json`                |
| s06  | `data/derived/all_codes.json`, r18.dev              | `data/checks/{found,not_found}_codes.txt`    |
| s07  | `data/checks/found_codes.txt`, `../trailer_codes/CODES.txt` | `data/checks/final_codes_add_to_app.txt` |
