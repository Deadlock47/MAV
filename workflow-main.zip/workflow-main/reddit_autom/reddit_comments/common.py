"""Shared helpers: JAV-code regex and JSON I/O."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


JAV_CODE_PATTERN = re.compile(r"\b([A-Za-z]{2,5})[\s\-]?(\d{2,5})\b")


def extract_jav_codes(text: str) -> set[str]:
    """Return the set of normalised JAV codes (LETTERS-NUMBERS) found in text."""
    if not text:
        return set()
    return {
        f"{letters.upper()}-{numbers}"
        for letters, numbers in JAV_CODE_PATTERN.findall(text)
    }


def read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as file:
        return json.load(file)


def write_json(path: Path, data: Any, *, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=indent, ensure_ascii=False)


def utc_to_readable(ts: float | int | None) -> str | None:
    if not ts:
        return None
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
