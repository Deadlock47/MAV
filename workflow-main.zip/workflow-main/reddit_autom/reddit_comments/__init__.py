"""Reddit upvotes/comments scrape + code-extraction pipeline."""
