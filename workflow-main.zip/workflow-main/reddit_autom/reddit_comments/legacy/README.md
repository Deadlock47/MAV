# Legacy scripts

Files here are kept for reference but are **not** part of the pipeline.
Safe to delete once you're confident nothing depends on them.

- `comments_scrape_trl.py` — early "trial" comment scraper; superseded by `pipeline/s02_scrape_comments.py`.
- `test.py` — dev scratch that overwrites `comments.json` for a single hard-coded post. A JWT was originally committed in this file (now blanked); rotate the Reddit token if you haven't already.
