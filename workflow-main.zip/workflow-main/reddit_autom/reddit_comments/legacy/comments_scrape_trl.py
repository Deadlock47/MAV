import requests
import json


USERNAME = ""  # REDACTED - see legacy/README.md
ACCESS_TOKEN = ""  # REDACTED - see legacy/README.md

url = f"https://oauth.reddit.com/comments/18wjpwc"

headers = {
    "User-Agent": "MyApp/1.0 by " + USERNAME,
    "Authorization": f"Bearer {ACCESS_TOKEN}"
}

response = requests.get(url, headers=headers)
print(response)
print(f"Response status code: {response.status_code}")
data = response.json()
print(json.dumps(data, indent=2))
def extract_comments(comments):

    result = []

    for c in comments:

        if c["kind"] != "t1":
            continue

        comment = c["data"]

        item = {
            "author": comment["author"],
            "body": comment["body"],
            "score": comment["score"],
            "replies": []
        }

        if comment["replies"]:
            replies = comment["replies"]["data"]["children"]
            item["replies"] = extract_comments(replies)

        result.append(item)

    return result

try:

    comments = extract_comments(data[1]["data"]["children"])
    with open("comments.json", "r", encoding="utf-8") as f:
        existing_comments = json.load(f)
        if not isinstance(existing_comments, list):
            existing_comments = [existing_comments]
    with open("comments.json", "w", encoding="utf-8") as f:
        json.dump(comments, f, indent=2, ensure_ascii=False)
        
except Exception as e:
    print(f"Error extracting comments: {e}")

    # with open('reddit_comments.json', 'w') as f:
    #     json.dump(comments, f, indent=2)
    # print(json.dumps(comments, indent=2))
# try : 
#     with open("all_upvoted_posts.json", "r", encoding="utf-8") as f:
#         upvoted_posts = json.load(f)
        
#     print(f"Total upvoted posts: {len(upvoted_posts)}")
#     for idx in range(len(upvoted_posts)):
#         print(f"Scraping comments for post {idx}/{len(upvoted_posts)}: {upvoted_posts[idx]['title'][:50]}...")
#         scrape_comments(upvoted_posts[idx]['post_id'])

# except Exception as e:
#     print(f"Error loading upvoted posts: {e}")