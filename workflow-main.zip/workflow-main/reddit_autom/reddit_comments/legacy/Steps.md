# legacy — Execution Steps

Off the happy path. Kept for reference; **not part of the current pipeline**.

## Files

| File | Purpose |
|------|---------|
| `comments_scrape_trl.py` | Older comment-scraping attempt. Superseded by `pipeline/s02_scrape_comments.py`. |
| `test.py` | Ad-hoc test. |
| `upvoted.json` | Sample upvoted-posts JSON. |
| `console_load_notes.txt.bak` | Old notes for the console-load flow. |
| `README.md` | Historical notes. |

## Order

None — **do not** run these as part of the pipeline. If you need a scripted run for debugging:

```bash
python reddit_autom/reddit_comments/legacy/comments_scrape_trl.py
python reddit_autom/reddit_comments/legacy/test.py
```

Prefer `python -m reddit_autom.reddit_comments` for real work.
