import json
import logging
from pathlib import Path
import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

SCRIPT_DIR = Path(__file__).resolve().parent
WORKSPACE_DIR = SCRIPT_DIR.parents[1]
if str(WORKSPACE_DIR) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_DIR))

from database import RedditRepository

# Change this import according to your project structure
# from database import RedditRepository


# ============================================================
# CONFIG
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

POSTS_FILE = (
    BASE_DIR
    / "console"
    / "console_posts.json"
)

COMMENTS_FILE = (
    BASE_DIR
    / "console"
    / "console_comments.json"
)


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

LOGGER = logging.getLogger(__name__)


# ============================================================
# READ JSON FILE
# ============================================================

def read_json_file(file_path: Path):

    if not file_path.exists():
        raise FileNotFoundError(
            f"File not found: {file_path}"
        )

    with open(
        file_path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError("JSON must contain a dictionary")

    return data


# ============================================================
# CREATE COMMENTS LOOKUP
# ============================================================





LOGGER.info(
    "Reading posts file: %s",
    POSTS_FILE
)

posts_data = read_json_file(
    POSTS_FILE
)

# --------------------------------------------------------
# Read comments file
# --------------------------------------------------------

LOGGER.info(
    "Reading comments file: %s",
    COMMENTS_FILE
)

comments_data = read_json_file(
    COMMENTS_FILE
)

print(len(comments_data["1w1hbkt"]))

new_comments = {}


for comment in comments_data["1w1hbkt"]:
    temp_comment = comment
    comment["reddit_post_id"] = "1w1hbkt"

print(comments_data["1w1hbkt"])