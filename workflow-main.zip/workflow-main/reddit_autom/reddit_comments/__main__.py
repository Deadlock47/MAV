"""One-command pipeline runner. `python -m reddit_autom.reddit_comments`."""

from __future__ import annotations

import argparse
import importlib
import sys
from typing import Callable


STEPS: list[tuple[str, str, str]] = [
    ("s01", "Scrape upvoted posts (Reddit API)", "s01_scrape_upvotes"),
    ("s02", "Scrape comments + upsert into Postgres", "s02_scrape_comments"),
    ("s03", "Extract JAV codes from upvoted-post titles", "s03_extract_codes_upvotes"),
    ("s04", "Extract JAV codes from comment bodies", "s04_extract_codes_comments"),
    ("s05", "Merge upvotes + comments codes -> all_codes.json", "s05_collect_codes"),
    ("s06", "Check codes against r18.dev", "s06_check_codes"),
    ("s07", "Diff found codes vs app CODES.txt", "s07_final_codes_txt"),
]


def _resolve(module_name: str) -> Callable[[], None]:
    module = importlib.import_module(f"reddit_autom.reddit_comments.pipeline.{module_name}")
    main = getattr(module, "main", None)
    if not callable(main):
        raise RuntimeError(f"Stage {module_name} has no callable main().")
    return main


def _select(from_step: str | None, to_step: str | None, only: str | None) -> list[tuple[str, str, str]]:
    ids = [step[0] for step in STEPS]
    if only is not None:
        if only not in ids:
            raise SystemExit(f"Unknown step {only!r}. Known: {', '.join(ids)}")
        return [step for step in STEPS if step[0] == only]

    start = 0
    end = len(STEPS)
    if from_step is not None:
        if from_step not in ids:
            raise SystemExit(f"Unknown --from step {from_step!r}. Known: {', '.join(ids)}")
        start = ids.index(from_step)
    if to_step is not None:
        if to_step not in ids:
            raise SystemExit(f"Unknown --to step {to_step!r}. Known: {', '.join(ids)}")
        end = ids.index(to_step) + 1
    if start >= end:
        raise SystemExit("Empty step range.")
    return STEPS[start:end]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m reddit_autom.reddit_comments",
        description="Run the reddit_comments pipeline end-to-end (or a subset).",
    )
    parser.add_argument("--list", action="store_true", help="List steps and exit")
    parser.add_argument("--from", dest="from_step", metavar="sNN", help="Start at this step id")
    parser.add_argument("--to", dest="to_step", metavar="sNN", help="Stop after this step id")
    parser.add_argument("--only", metavar="sNN", help="Run only this step id")
    parser.add_argument("--keep-going", action="store_true", help="Continue on stage errors")
    args = parser.parse_args(argv)

    if args.list:
        print("Available steps:")
        for step_id, title, module_name in STEPS:
            print(f"  {step_id}  {title}   (pipeline/{module_name}.py)")
        return 0

    selected = _select(args.from_step, args.to_step, args.only)
    print("Running:", ", ".join(step[0] for step in selected))
    for step_id, title, module_name in selected:
        print("\n" + "=" * 60)
        print(f"[{step_id}] {title}")
        print("=" * 60)
        try:
            _resolve(module_name)()
        except SystemExit as exit_error:
            if args.keep_going:
                print(f"[{step_id}] exited: {exit_error}. Continuing (--keep-going).")
                continue
            raise
        except Exception as error:
            if args.keep_going:
                print(f"[{step_id}] failed: {error}. Continuing (--keep-going).")
                continue
            raise
    return 0


if __name__ == "__main__":
    sys.exit(main())
