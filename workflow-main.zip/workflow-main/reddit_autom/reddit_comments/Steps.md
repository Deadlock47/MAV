# reddit_comments — Execution Steps

Scrapes upvoted Reddit posts + their comment threads, extracts JAV codes from titles and comment bodies, verifies each code on r18.dev, and diffs the results against `../trailer_codes/CODES.txt`.

## Prerequisites

Add to `database/.env` (loaded automatically by `config.py`):

```env
REDDIT_USERNAME=your_reddit_username
REDDIT_ACCESS_TOKEN=your_oauth_bearer_token
REDDIT_USER_AGENT=reddit-autom/1.0
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=redinst
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
```

Optional overrides:
- `REDDIT_STOP_AT_POST_ID` — s01 stops paging when this id is seen (default `1w1hbkt`).
- `R18_RATE_LIMIT_DELAY` — seconds between r18.dev requests in s06 (default `1.8`).

## One-command run (from workspace root)

```bash
python -m reddit_autom.reddit_comments             # run s01..s07 in order
python -m reddit_autom.reddit_comments --list      # print steps
python -m reddit_autom.reddit_comments --from s03  # skip scrapers, start at extraction
python -m reddit_autom.reddit_comments --only s05  # run one stage
python -m reddit_autom.reddit_comments --to s05    # stop after all_codes.json
python -m reddit_autom.reddit_comments --keep-going  # continue on stage errors
```

## Stage order

| Step | What it does | Script |
|------|--------------|--------|
| s01 | Scrape upvoted posts via Reddit API | `pipeline/s01_scrape_upvotes.py` |
| s02 | Scrape comments per post + upsert into Postgres | `pipeline/s02_scrape_comments.py` |
| s03 | Extract JAV codes from post titles | `pipeline/s03_extract_codes_upvotes.py` |
| s04 | Extract JAV codes from comment bodies | `pipeline/s04_extract_codes_comments.py` |
| s05 | Merge upvotes + comments codes into `all_codes.json` | `pipeline/s05_collect_codes.py` |
| s06 | Check every code against r18.dev | `pipeline/s06_check_codes.py` |
| s07 | Diff found codes vs `../trailer_codes/CODES.txt` | `pipeline/s07_final_codes_txt.py` |

See [pipeline/Steps.md](pipeline/Steps.md) for per-script commands.

## Alternate: load from browser-console dumps

Skip s01/s02 by pasting console JSON into `console/` and running:

```bash
python -m reddit_autom.reddit_comments.console.load
```

See [console/Steps.md](console/Steps.md).

## Stage I/O

| Step | Inputs                                              | Outputs                                      |
|------|-----------------------------------------------------|----------------------------------------------|
| s01  | Reddit API (`REDDIT_ACCESS_TOKEN`)                  | `data/raw/all_upvoted_posts.json`            |
| s02  | `data/raw/all_upvoted_posts.json`, Reddit API       | `data/raw/comments.json`, Postgres upsert    |
| s03  | `data/raw/all_upvoted_posts.json`                   | `data/derived/extract_codes_upvotes.json`    |
| s04  | `data/raw/comments.json`                            | `data/derived/extract_codes_comments.json`   |
| s05  | `data/derived/extract_codes_{upvotes,comments}.json`| `data/derived/all_codes.json`                |
| s06  | `data/derived/all_codes.json`, r18.dev              | `data/checks/{found,not_found}_codes.txt`    |
| s07  | `data/checks/found_codes.txt`, `../trailer_codes/CODES.txt` | `data/checks/final_codes_add_to_app.txt` |
