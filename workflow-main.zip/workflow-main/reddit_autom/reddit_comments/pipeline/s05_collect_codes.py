"""Stage 5: merge upvotes + comments code maps -> derived/all_codes.json."""

from __future__ import annotations

from ..common import read_json, write_json
from ..config import (
    ALL_CODES_FILE,
    COMMENTS_CODES_FILE,
    UPVOTES_CODES_FILE,
    ensure_data_dirs,
)


def main() -> None:
    ensure_data_dirs()
    comments_data = read_json(COMMENTS_CODES_FILE, default={}) or {}
    upvotes_data = read_json(UPVOTES_CODES_FILE, default={}) or {}
    print(f"Loaded {len(comments_data)} comment-code entries")
    print(f"Loaded {len(upvotes_data)} upvote-code entries")

    combined: dict[str, dict[str, list[str]]] = {}
    for post_id in set(comments_data) | set(upvotes_data):
        combined[post_id] = {
            "comments_codes": list(comments_data.get(post_id, [])),
            "upvotes_codes": list(upvotes_data.get(post_id, [])),
        }

    write_json(ALL_CODES_FILE, combined, indent=4)
    print(f"Wrote {ALL_CODES_FILE} ({len(combined)} posts)")


if __name__ == "__main__":
    main()
