"""Stage 1: scrape upvoted posts from the Reddit API and write raw/all_upvoted_posts.json."""

from __future__ import annotations

import time
from typing import Any

import requests

from ..common import utc_to_readable, write_json
from ..config import (
    REDDIT_USERNAME,
    REDDIT_USER_AGENT,
    UPVOTED_POSTS_FILE,
    UPVOTES_STOP_AT_POST_ID,
    ensure_data_dirs,
    require_reddit_token,
)


def _extract_oembed_html(post: dict[str, Any]) -> str:
    scm = post.get("secure_media") or {}
    oembed = scm.get("oembed") if isinstance(scm, dict) else None
    return oembed.get("html", "") if isinstance(oembed, dict) else ""


def _iter_upvoted_pages(token: str, username: str) -> list[dict[str, Any]]:
    headers = {
        "User-Agent": REDDIT_USER_AGENT,
        "Authorization": f"Bearer {token}",
    }
    base_url = f"https://oauth.reddit.com/user/{username}/upvoted.json"

    all_posts: list[dict[str, Any]] = []
    after: str | None = None
    page = 0

    while True:
        page += 1
        params: dict[str, Any] = {"limit": 100}
        if after:
            params["after"] = after

        print(f"\nFetching page {page}")
        response = requests.get(base_url, headers=headers, params=params, timeout=30)
        print("Status:", response.status_code)
        response.raise_for_status()

        data = response.json().get("data", {})
        children = data.get("children", []) or []
        print(f"Posts received this page: {len(children)}")
        if not children:
            print("No more posts.")
            break

        stop = False
        for item in children:
            post = item.get("data", {}) or {}
            post_id = post.get("id")
            if post_id == UPVOTES_STOP_AT_POST_ID:
                print(f"\nExisting post {post_id} reached — stopping.")
                stop = True
                break

            all_posts.append(
                {
                    "post_id": post_id,
                    "title": post.get("title"),
                    "subreddit": post.get("subreddit"),
                    "created_utc": post.get("created_utc"),
                    "created_time": utc_to_readable(post.get("created_utc")),
                    "score": post.get("score"),
                    "num_comments": post.get("num_comments"),
                    "body": post.get("selftext"),
                    "post_url": "https://www.reddit.com" + post.get("permalink", ""),
                    "redgif_url": post.get("url_overridden_by_dest"),
                    "reddit_iframe_html": _extract_oembed_html(post),
                }
            )
            print(f"Added new post: {post_id}")

        if stop:
            break
        after = data.get("after")
        print(f"Next cursor: {after}")
        print(f"Total posts collected: {len(all_posts)}")
        if not after:
            print("Reached end of listing.")
            break
        time.sleep(1)

    return all_posts


def main() -> None:
    ensure_data_dirs()
    token = require_reddit_token()
    if not REDDIT_USERNAME:
        raise SystemExit("REDDIT_USERNAME is not set. Add it to database/.env.")

    posts = _iter_upvoted_pages(token, REDDIT_USERNAME)
    write_json(UPVOTED_POSTS_FILE, posts)
    print(f"\nDone. Total posts: {len(posts)} -> {UPVOTED_POSTS_FILE}")


if __name__ == "__main__":
    main()
