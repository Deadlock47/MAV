# pipeline — Execution Steps

Numbered stages of the `reddit_comments` pipeline. Normally run together via the parent runner; each is also runnable in isolation.

## Preferred: run them all in order

```bash
python -m reddit_autom.reddit_comments             # s01 → s07
```

## Run one stage at a time (from workspace root)

```bash
python -m reddit_autom.reddit_comments.pipeline.s01_scrape_upvotes
python -m reddit_autom.reddit_comments.pipeline.s02_scrape_comments
python -m reddit_autom.reddit_comments.pipeline.s03_extract_codes_upvotes
python -m reddit_autom.reddit_comments.pipeline.s04_extract_codes_comments
python -m reddit_autom.reddit_comments.pipeline.s05_collect_codes
python -m reddit_autom.reddit_comments.pipeline.s06_check_codes
python -m reddit_autom.reddit_comments.pipeline.s07_final_codes_txt
```

## What each step does

| Step | Reads | Writes |
|------|-------|--------|
| s01  | Reddit API (needs `REDDIT_ACCESS_TOKEN`) | `data/raw/all_upvoted_posts.json` |
| s02  | s01 output + Reddit API | `data/raw/comments.json` + Postgres upsert |
| s03  | s01 output | `data/derived/extract_codes_upvotes.json` |
| s04  | s02 output | `data/derived/extract_codes_comments.json` |
| s05  | s03 + s04 outputs | `data/derived/all_codes.json` |
| s06  | s05 output + r18.dev API | `data/checks/{found,not_found}_codes.{txt,json}` |
| s07  | s06 output + `../../trailer_codes/CODES.txt` | `data/checks/final_codes_add_to_app.txt` |

## Rules

- **Order matters** for s01→s02→s03→s04→s05→s06→s07 (each stage depends on the previous outputs).
- s03 needs s01 output; s04 needs s02 output. These two can be run in either order once s01/s02 are done.
- s06 hits r18.dev; respect `R18_RATE_LIMIT_DELAY` (default 1.8s).
