"""Stage 2: scrape comments for each upvoted post and persist to Postgres."""

from __future__ import annotations

import json
from typing import Any

import requests

from database import RedditRepository

from ..common import read_json, write_json
from ..config import (
    COMMENTS_FILE,
    LEGACY_COMMENTS_FILE,
    REDDIT_USER_AGENT,
    UPVOTED_POSTS_FILE,
    ensure_data_dirs,
    require_reddit_token,
)


def _response_error(response: requests.Response) -> RuntimeError:
    try:
        detail = json.dumps(response.json())[:500]
    except ValueError:
        detail = response.text[:500]
    return RuntimeError(f"Reddit returned HTTP {response.status_code}: {detail}")


def _get_post_and_children(post_id: str, token: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    response = requests.get(
        f"https://oauth.reddit.com/comments/{post_id}.json",
        headers={
            "User-Agent": REDDIT_USER_AGENT,
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
        params={"limit": 100, "depth": 10, "raw_json": 1},
        timeout=30,
    )
    if not response.ok:
        raise _response_error(response)

    try:
        payload = response.json()
    except ValueError as error:
        raise RuntimeError("Reddit returned a non-JSON response.") from error

    if not isinstance(payload, list) or len(payload) < 2:
        raise RuntimeError(f"Unexpected Reddit comments payload: {json.dumps(payload)[:500]}")

    post_listing, comment_listing = payload[:2]
    post_children = post_listing.get("data", {}).get("children") if isinstance(post_listing, dict) else None
    if not isinstance(post_children, list) or not post_children:
        raise RuntimeError("Reddit response does not contain the requested post.")
    post = post_children[0].get("data") if isinstance(post_children[0], dict) else None
    if not isinstance(post, dict):
        raise RuntimeError("Reddit response contains an invalid post.")

    children = comment_listing.get("data", {}).get("children") if isinstance(comment_listing, dict) else None
    if not isinstance(children, list):
        raise RuntimeError("Reddit response does not contain a comments listing.")
    return post, children


def _extract_comments(children: list[Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for child in children:
        if not isinstance(child, dict) or child.get("kind") != "t1":
            continue
        comment = child.get("data")
        if not isinstance(comment, dict):
            continue
        replies = comment.get("replies")
        reply_children = replies.get("data", {}).get("children", []) if isinstance(replies, dict) else []
        result.append(
            {
                "id": comment.get("id"),
                "parent_id": comment.get("parent_id"),
                "subreddit": comment.get("subreddit"),
                "author": comment.get("author"),
                "body": comment.get("body", ""),
                "score": comment.get("score", 0),
                "created_utc": comment.get("created_utc"),
                "replies": _extract_comments(reply_children),
            }
        )
    return result


def _load_comments_by_post() -> dict[str, list[dict[str, Any]]]:
    if not COMMENTS_FILE.exists():
        return {}
    saved = read_json(COMMENTS_FILE, default={})
    if isinstance(saved, dict):
        return saved
    if isinstance(saved, list):
        if LEGACY_COMMENTS_FILE.exists():
            raise RuntimeError(
                "comments.json uses the old list format and comments.legacy.json already exists. "
                "Rename or remove one of the files before continuing."
            )
        COMMENTS_FILE.replace(LEGACY_COMMENTS_FILE)
        print(f"Moved the old list-format file to {LEGACY_COMMENTS_FILE.name}.")
        return {}
    raise RuntimeError("comments.json must contain a JSON object keyed by post ID.")


def _flatten_comments(comments: list[dict[str, Any]]):
    for comment in comments:
        yield comment
        yield from _flatten_comments(comment.get("replies", []))


def _scrape_one(post: dict[str, Any], token: str, repository: RedditRepository | None) -> None:
    post_id = post["post_id"]
    reddit_post, children = _get_post_and_children(post_id, token)
    comments = _extract_comments(children)

    saved = _load_comments_by_post()
    saved[post_id] = comments
    write_json(COMMENTS_FILE, saved)

    print(f"Saved {len(comments)} top-level comments for post {post_id}.")
    if repository is None:
        return
    try:
        post_data = {**post, **reddit_post}
        saved_count = repository.save_post_and_comments(post_data, _flatten_comments(comments))
        print(f"Saved post {post_id} and {saved_count} comments to PostgreSQL.")
    except Exception as error:
        print(f"Could not save {post_id} to PostgreSQL: {error}")


def main() -> None:
    ensure_data_dirs()
    token = require_reddit_token()

    try:
        upvoted_posts = read_json(UPVOTED_POSTS_FILE, default=None)
    except (OSError, json.JSONDecodeError) as error:
        print(f"Error loading upvoted posts: {error}")
        return
    if not isinstance(upvoted_posts, list):
        print("Error loading upvoted posts: expected a JSON list.")
        return

    print(f"Scraping comments for {len(upvoted_posts)} upvoted posts")

    try:
        repository: RedditRepository | None = RedditRepository.from_environment()
        print("PostgreSQL persistence is enabled.")
    except Exception as error:
        repository = None
        print(f"PostgreSQL persistence is disabled: {error}")

    try:
        for index, post in enumerate(upvoted_posts):
            post_id = post.get("post_id") if isinstance(post, dict) else None
            if not post_id:
                print(f"Skipping item {index}: missing post_id.")
                continue
            title = post.get("title", "Untitled")
            print(f"Scraping post {index + 1}/{len(upvoted_posts)}: {title[:50]}...")
            try:
                _scrape_one(post, token, repository)
            except (requests.RequestException, RuntimeError, OSError, json.JSONDecodeError) as error:
                print(f"Could not scrape {post_id}: {error}")
    finally:
        if repository is not None:
            repository.close()


if __name__ == "__main__":
    main()
