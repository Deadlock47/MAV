"""Stage 7: diff found_codes vs app-side CODES.txt -> checks/final_codes_add_to_app.txt."""

from __future__ import annotations

from ..config import (
    FINAL_CODES_TXT,
    FOUND_CODES_TXT,
    SOURCE_CODES_TXT,
    ensure_data_dirs,
)


def _format_code(code: str) -> str:
    """`abc123` -> `ABC-123` (insert dash before first digit, uppercase)."""
    code = code.strip().upper()
    for i, char in enumerate(code):
        if char.isdigit():
            return code[:i] + "-" + code[i:]
    return code


def _read_csv(path) -> set[str]:
    if not path.exists():
        return set()
    return {c.strip() for c in path.read_text(encoding="utf-8").split(",") if c.strip()}


def main() -> None:
    ensure_data_dirs()
    if not SOURCE_CODES_TXT.exists():
        raise SystemExit(f"Source app codes file not found: {SOURCE_CODES_TXT}")
    if not FOUND_CODES_TXT.exists():
        raise SystemExit(f"Found codes file not found: {FOUND_CODES_TXT}. Run stage s06 first.")

    app_codes = _read_csv(SOURCE_CODES_TXT)
    new_codes = {_format_code(code) for code in _read_csv(FOUND_CODES_TXT)}

    to_add = new_codes.difference(app_codes).union(new_codes)
    FINAL_CODES_TXT.parent.mkdir(parents=True, exist_ok=True)
    FINAL_CODES_TXT.write_text(",".join(sorted(to_add)), encoding="utf-8")
    print(f"Wrote {FINAL_CODES_TXT} ({len(to_add)} codes)")


if __name__ == "__main__":
    main()
