"""Stage 4: extract JAV codes from comment bodies -> derived/extract_codes_comments.json."""

from __future__ import annotations

from typing import Any

from ..common import extract_jav_codes, read_json, write_json
from ..config import COMMENTS_CODES_FILE, COMMENTS_FILE, ensure_data_dirs


def _codes_from_thread(comments: list[dict[str, Any]]) -> set[str]:
    found: set[str] = set()
    for comment in comments:
        if not isinstance(comment, dict):
            continue
        found |= extract_jav_codes(comment.get("body", ""))
        replies = comment.get("replies") or []
        if replies:
            found |= _codes_from_thread(replies)
    return found


def main() -> None:
    ensure_data_dirs()
    comments_by_post = read_json(COMMENTS_FILE, default={})
    if not isinstance(comments_by_post, dict):
        raise SystemExit(f"Expected a JSON object at {COMMENTS_FILE}.")
    print(f"Loaded comments data for {len(comments_by_post)} posts")

    codes_by_post: dict[str, list[str]] = read_json(COMMENTS_CODES_FILE, default={}) or {}

    total = len(comments_by_post)
    for index, (post_id, comments) in enumerate(comments_by_post.items(), start=1):
        if not isinstance(comments, list):
            continue
        found = _codes_from_thread(comments)
        merged = set(codes_by_post.get(post_id, [])) | found
        codes_by_post[post_id] = sorted(merged)
        print(f"[{index}/{total}] post {post_id}: +{len(found)} codes (total {len(codes_by_post[post_id])})")

    write_json(COMMENTS_CODES_FILE, codes_by_post)
    print(f"Wrote {COMMENTS_CODES_FILE}")


if __name__ == "__main__":
    main()
