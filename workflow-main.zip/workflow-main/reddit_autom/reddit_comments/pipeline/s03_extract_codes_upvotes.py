"""Stage 3: extract JAV codes from upvoted-post titles -> derived/extract_codes_upvotes.json."""

from __future__ import annotations

from ..common import extract_jav_codes, read_json, write_json
from ..config import UPVOTED_POSTS_FILE, UPVOTES_CODES_FILE, ensure_data_dirs


def main() -> None:
    ensure_data_dirs()
    posts = read_json(UPVOTED_POSTS_FILE, default=[])
    if not isinstance(posts, list):
        raise SystemExit(f"Expected a JSON list at {UPVOTED_POSTS_FILE}.")
    print(f"Loaded data for {len(posts)} upvoted posts")

    codes_by_post: dict[str, list[str]] = read_json(UPVOTES_CODES_FILE, default={}) or {}

    for item in posts:
        if not isinstance(item, dict):
            continue
        post_id = item.get("post_id")
        title = item.get("title") or ""
        if not post_id:
            continue
        found = extract_jav_codes(title)
        merged = set(codes_by_post.get(post_id, [])) | found
        codes_by_post[post_id] = sorted(merged)
        print(f"post {post_id}: +{len(found)} codes (total {len(codes_by_post[post_id])})")

    write_json(UPVOTES_CODES_FILE, codes_by_post, indent=4)
    print(f"Wrote {UPVOTES_CODES_FILE}")


if __name__ == "__main__":
    main()
