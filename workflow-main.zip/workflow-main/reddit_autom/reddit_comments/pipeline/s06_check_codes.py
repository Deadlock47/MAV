"""Stage 6: check each code against r18.dev -> checks/found_codes.txt + not_found_codes.txt."""

from __future__ import annotations

import time

import requests

from ..common import read_json
from ..config import (
    ALL_CODES_FILE,
    FOUND_CODES_TXT,
    NOT_FOUND_CODES_TXT,
    R18_RATE_LIMIT_DELAY_SECONDS,
    ensure_data_dirs,
)


HEADERS = {"User-Agent": "reddit-autom/1.0"}


def _r18_id(code: str) -> str | None:
    """`ABC-123` -> `abc123` (r18.dev's dvd_id format)."""
    if "-" not in code:
        return None
    letters, numbers = code.split("-", 1)
    return f"{letters.lower()}{numbers}"


def _check_code(r18_id: str) -> bool:
    response = requests.get(
        f"https://r18.dev/videos/vod/movies/detail/-/dvd_id={r18_id}/json",
        headers=HEADERS,
        timeout=30,
    )
    print(response.status_code)
    return response.status_code == 200


def _read_csv(path) -> set[str]:
    if not path.exists():
        return set()
    return {c.strip() for c in path.read_text(encoding="utf-8").split(",") if c.strip()}


def _append_csv(path, new_codes: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = _read_csv(path)
    with path.open("a", encoding="utf-8") as file:
        for code in new_codes:
            if code not in existing:
                file.write(code + ",")
                existing.add(code)


def main() -> None:
    ensure_data_dirs()
    codes_data = read_json(ALL_CODES_FILE, default={})
    if not isinstance(codes_data, dict):
        raise SystemExit(f"Expected a JSON object at {ALL_CODES_FILE}.")

    found_cache = _read_csv(FOUND_CODES_TXT)
    not_found_cache = _read_csv(NOT_FOUND_CODES_TXT)
    session_found: list[str] = []
    session_not_found: list[str] = []
    total = passed = failed = 0

    for post_id, entry in codes_data.items():
        if not isinstance(entry, dict):
            continue
        all_codes = list(entry.get("comments_codes", [])) + list(entry.get("upvotes_codes", []))
        print(post_id)
        for code in all_codes:
            r18_id = _r18_id(code)
            if not r18_id:
                continue
            if r18_id in found_cache or r18_id in not_found_cache:
                print(f"Code {r18_id} already checked, skipping...")
                continue
            if _check_code(r18_id):
                session_found.append(r18_id)
                found_cache.add(r18_id)
                passed += 1
                print(f"Code found: {r18_id}")
            else:
                session_not_found.append(r18_id)
                not_found_cache.add(r18_id)
                failed += 1
                print(f"Code not found: {r18_id}")
            total += 1
            time.sleep(R18_RATE_LIMIT_DELAY_SECONDS)

    print("=" * 25)
    print(f"Passed: {passed}, Failed: {failed}, Total: {total}")
    print("-" * 25)

    _append_csv(FOUND_CODES_TXT, session_found)
    _append_csv(NOT_FOUND_CODES_TXT, session_not_found)
    print(f"Wrote {FOUND_CODES_TXT}")
    print(f"Wrote {NOT_FOUND_CODES_TXT}")


if __name__ == "__main__":
    main()
