import requests

url = 'https://g245.turbosplayer.com/file/9aa13e6b-9209-4a81-8a22-1ff71e22b604/master.m3u8'
headers = {
        "User-Agent": "MyApp/1.0 by sdsd" 
    
}

## https://javenglish.net/
## https://javflix.cc/juq-563-english-subtitle/
## emturbovid.com StreamTV >> 'https://g245.turbosplayer.com/file/9aa13e6b-9209-4a81-8a22-1ff71e22b604/master.m3u8'

data = requests.get(url)

print(data.text)