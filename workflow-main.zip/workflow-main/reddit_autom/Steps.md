# reddit_autom — Execution Steps

Top-level index for the Reddit workflow. Actual pipelines live in sub-folders — this file just lists the order.

## Sub-pipelines

| Order | Folder | Purpose |
|-------|--------|---------|
| 1 | [reddit_comments/](reddit_comments/Steps.md) | Scrape upvotes + comments, extract JAV codes, verify on r18.dev |
| 2 | [trailer_codes/](trailer_codes/Steps.md) | Fetch trailer URLs for each code and sync to JSONBin |
| 3 | [ui/](ui/Steps.md) | Tkinter UI to review results and reprocess individual posts |
| — | [backup/](backup/Steps.md) | One-shot mirror of `trailer_codes/*.json` into `*_backup.json` via JSONBin |

## End-to-end (from workspace root)

```bash
# 1. base infra (see database/Steps.md)
pip install -r requirements.txt
cp .env.example database/.env
python database/create_tables.py

# 2. scrape + extract codes
python -m reddit_autom.reddit_comments

# 3. fetch trailer URLs
python reddit_autom/trailer_codes/main.py

# 4. review in UI
python -m reddit_autom.ui.review_ui
```

## Standalone script

- `my_prac.py` — PRAW smoke test with hardcoded creds. Not part of the pipeline; don't wire into anything.
  ```bash
  python reddit_autom/my_prac.py
  ```
