# reddit_autom/ui — Execution Steps

Tkinter UI to review Reddit posts, their extracted JAV codes, and the associated trailer links. Supports search / sort / filter / reprocess and lazy tab rendering for large datasets.

## Files

| File | Purpose |
|------|---------|
| `review_ui.py` | The UI. Loads inputs from `reddit_comments/` and `trailer_codes/`; runnable as a module. |
| `__init__.py` | Empty package marker. |

## Prerequisites

Generate the inputs the UI needs by running the reddit pipeline first:
```bash
python -m reddit_autom.reddit_comments --to s05    # produces upvotes/comments/all_codes JSON
python reddit_autom/trailer_codes/main.py          # produces trailer_links.json + not_found_codes.json
```

## Order (from workspace root)

### 1. Launch the UI
```bash
python -m reddit_autom.ui.review_ui
```

### 2. Print counts without opening the window
```bash
python -m reddit_autom.ui.review_ui --summary
```

### 3. Custom paths (all optional)
```bash
python -m reddit_autom.ui.review_ui \
  --posts-json reddit_autom/reddit_comments/data/raw/all_upvoted_posts.json \
  --codes-json reddit_autom/reddit_comments/data/derived/all_codes.json \
  --upvotes-codes-json reddit_autom/reddit_comments/data/derived/extract_codes_upvotes.json \
  --comments-codes-json reddit_autom/reddit_comments/data/derived/extract_codes_comments.json \
  --comments-json reddit_autom/reddit_comments/data/raw/comments.json \
  --trailer-links-json reddit_autom/trailer_codes/trailer_links.json \
  --not-found-json reddit_autom/trailer_codes/not_found_codes.json \
  --state reddit_autom/reddit_review_state.json
```

## UI notes

- Tabs: **Needs review** / **Matched** / **Empty**. The `Empty` tab is hidden by default; toggle "Show empty" in the toolbar.
- Only the visible tab renders its cards. Each tab shows the first 100 cards; use **Show 100 more** / **Show all** at the bottom for the rest.
- Search debounces at 200 ms.
- "↻ Reprocess" on a card re-extracts codes for that single post and rewrites the JSON files.
