"""UI helpers for reviewing Reddit upvote + comment codes."""
