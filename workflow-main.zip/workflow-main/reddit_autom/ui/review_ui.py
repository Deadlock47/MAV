"""Tkinter UI to review Reddit upvote + comment codes, with per-post reprocess."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import threading
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal


# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------


_JAV_CODE_PATTERN = re.compile(r"\b([A-Za-z]{2,5})[\s\-]?(\d{2,5})\b")

ReviewBucket = Literal["needs_review", "matched", "empty"]

BUCKET_TABS: list[tuple[ReviewBucket, str]] = [
    ("needs_review", "Needs review"),
    ("matched", "Matched"),
    ("empty", "Empty"),
]

PALETTE = {
    "bg": "#fafafa",
    "card_bg": "#ffffff",
    "reviewed_bg": "#e7f5ea",
    "reviewed_border": "#2e7d32",
    "needs_border": "#ef6c00",
    "matched_border": "#2e7d32",
    "empty_border": "#9e9e9e",
    "subtle": "#5f6368",
    "diff_ok": "#137333",
    "diff_warn": "#b06000",
    "reviewed_badge_bg": "#c8e6c9",
    "reviewed_badge_fg": "#1b5e20",
}

SORT_OPTIONS: list[tuple[str, str]] = [
    ("Subreddit → post id", "subreddit"),
    ("Post id", "post_id"),
    ("Score (high → low)", "score"),
    ("Title", "title"),
]

# Cards rendered per page before requiring a "Show more" click.
PAGE_SIZE = 40

_IFRAME_SRC_RE = re.compile(r"""src=["']([^"']+)""", re.IGNORECASE)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# data model
# ---------------------------------------------------------------------------


@dataclass
class ReviewItem:
    key: str
    bucket: ReviewBucket
    post_id: str
    subreddit: str | None
    title: str
    permalink: str | None
    redgif_url: str | None
    score: int | None
    created_time: str | None
    upvotes_codes: list[str]
    comments_codes: list[str]
    comments_preview: list[str]
    trailer_links: dict[str, list[str]] = field(default_factory=dict)
    codes_not_found: list[str] = field(default_factory=list)
    # Precomputed to keep hot render/search paths cheap.
    search_haystack: str = ""
    diff_summary: str = ""
    diff_is_ok: bool = False
    all_codes: list[str] = field(default_factory=list)
    video_iframe_src: str | None = None


# ---------------------------------------------------------------------------
# io helpers
# ---------------------------------------------------------------------------


def _read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any, *, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=indent, ensure_ascii=False), encoding="utf-8")


def _safe_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _safe_str_list(value: Any) -> list[str]:
    return [item for item in _safe_list(value) if isinstance(item, str)]


# ---------------------------------------------------------------------------
# bucket + item construction
# ---------------------------------------------------------------------------


def _bucket_for(upvotes: list[str], comments: list[str]) -> ReviewBucket:
    if not upvotes and not comments:
        return "empty"
    if upvotes and set(upvotes) == set(comments):
        return "matched"
    return "needs_review"


def _load_codes_map(
    combined_path: Path,
    upvotes_path: Path,
    comments_path: Path,
) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    upvotes_by: dict[str, list[str]] = {}
    comments_by: dict[str, list[str]] = {}

    combined = _read_json(combined_path)
    if isinstance(combined, dict):
        for pid, val in combined.items():
            if isinstance(val, dict):
                upvotes_by[str(pid)] = _safe_str_list(val.get("upvotes_codes"))
                comments_by[str(pid)] = _safe_str_list(val.get("comments_codes"))

    upvotes_raw = _read_json(upvotes_path)
    if isinstance(upvotes_raw, dict):
        for pid, val in upvotes_raw.items():
            upvotes_by[str(pid)] = _safe_str_list(val)

    comments_raw = _read_json(comments_path)
    if isinstance(comments_raw, dict):
        for pid, val in comments_raw.items():
            comments_by[str(pid)] = _safe_str_list(val)

    return upvotes_by, comments_by


def _load_comments_bodies(path: Path, limit: int = 3) -> dict[str, list[str]]:
    raw = _read_json(path)
    if not isinstance(raw, dict):
        return {}
    out: dict[str, list[str]] = {}
    for pid, comments in raw.items():
        if not isinstance(comments, list):
            continue
        bodies: list[str] = []
        for entry in comments:
            if not isinstance(entry, dict):
                continue
            body = entry.get("body")
            if isinstance(body, str) and body.strip():
                bodies.append(body.strip())
            if len(bodies) >= limit:
                break
        if bodies:
            out[str(pid)] = bodies
    return out


def _load_trailer_links(path: Path) -> dict[str, list[str]]:
    raw = _read_json(path)
    if not isinstance(raw, dict):
        return {}
    out: dict[str, list[str]] = {}
    for code, links in raw.items():
        if isinstance(code, str) and isinstance(links, list):
            out[code] = [link for link in links if isinstance(link, str)]
    return out


def _load_not_found(path: Path) -> set[str]:
    raw = _read_json(path)
    if not isinstance(raw, list):
        return set()
    return {code for code in raw if isinstance(code, str)}


def _permalink_for(post: dict[str, Any]) -> str | None:
    url = post.get("post_url")
    if isinstance(url, str) and url:
        return url
    permalink = post.get("permalink")
    if isinstance(permalink, str) and permalink:
        return f"https://www.reddit.com{permalink}" if permalink.startswith("/") else permalink
    pid = post.get("post_id") or post.get("id")
    if pid:
        return f"https://www.reddit.com/comments/{pid}"
    return None


def _extract_iframe_src(html: str | None) -> str | None:
    if not isinstance(html, str) or not html:
        return None
    match = _IFRAME_SRC_RE.search(html)
    if match is None:
        return None
    src = match.group(1).strip()
    if src.startswith("//"):
        src = "https:" + src
    if src.startswith("http://"):
        # Reddit oembed sometimes serves http; upgrade for embed safety.
        src = "https://" + src[len("http://"):]
    return src or None


def _finalize_item(
    item: ReviewItem,
    trailer_links: dict[str, list[str]],
    not_found_codes: set[str],
) -> None:
    """(Re)compute derived fields on an item after upvotes/comments change."""
    upvotes = item.upvotes_codes
    comments = item.comments_codes
    all_codes = list(dict.fromkeys(upvotes + comments))
    item.all_codes = all_codes
    item.trailer_links = {code: trailer_links[code] for code in all_codes if code in trailer_links}
    item.codes_not_found = [code for code in all_codes if code in not_found_codes]
    item.bucket = _bucket_for(upvotes, comments)

    diff_summary = ""
    diff_is_ok = False
    if upvotes or comments:
        up_set = set(upvotes)
        cm_set = set(comments)
        up_only = [c for c in upvotes if c not in cm_set]
        cm_only = [c for c in comments if c not in up_set]
        if up_only or cm_only:
            bits: list[str] = []
            if up_only:
                bits.append(f"Upvotes only: {', '.join(up_only)}")
            if cm_only:
                bits.append(f"Comments only: {', '.join(cm_only)}")
            diff_summary = "  ·  ".join(bits)
        else:
            diff_summary = "Match: upvotes and comments codes are the same."
            diff_is_ok = True
    item.diff_summary = diff_summary
    item.diff_is_ok = diff_is_ok

    item.search_haystack = " ".join(
        [
            (item.title or "").lower(),
            (item.subreddit or "").lower(),
            (item.post_id or "").lower(),
            " ".join(upvotes).lower(),
            " ".join(comments).lower(),
        ]
    )


def _build_items(
    posts: list[dict[str, Any]],
    *,
    upvotes_by: dict[str, list[str]],
    comments_by: dict[str, list[str]],
    comments_bodies: dict[str, list[str]],
    trailer_links: dict[str, list[str]],
    not_found_codes: set[str],
) -> list[ReviewItem]:
    items: list[ReviewItem] = []
    seen: set[str] = set()

    def _add(pid: str, post: dict[str, Any] | None) -> None:
        if not pid or pid in seen:
            return
        seen.add(pid)
        upvotes = list(upvotes_by.get(pid, []))
        comments = list(comments_by.get(pid, []))
        bucket = _bucket_for(upvotes, comments)
        all_codes = list(dict.fromkeys(upvotes + comments))
        item_trailers = {code: trailer_links[code] for code in all_codes if code in trailer_links}
        item_not_found = [code for code in all_codes if code in not_found_codes]

        post = post or {}
        subreddit = post.get("subreddit") if isinstance(post.get("subreddit"), str) else None
        title = str(post.get("title") or "")
        score = post.get("score") if isinstance(post.get("score"), int) else None
        created_time = post.get("created_time") if isinstance(post.get("created_time"), str) else None
        redgif_url = post.get("redgif_url") if isinstance(post.get("redgif_url"), str) else None

        items.append(
            ReviewItem(
                key=f"reddit:{pid}",
                bucket=bucket,
                post_id=pid,
                subreddit=subreddit,
                title=title,
                permalink=_permalink_for(post) if post else f"https://www.reddit.com/comments/{pid}",
                redgif_url=redgif_url,
                score=score,
                created_time=created_time,
                upvotes_codes=upvotes,
                comments_codes=comments,
                comments_preview=list(comments_bodies.get(pid, [])),
                trailer_links=item_trailers,
                codes_not_found=item_not_found,
            )
        )

    for post in posts:
        if not isinstance(post, dict):
            continue
        pid = str(post.get("post_id") or post.get("id") or "").strip()
        _add(pid, post)

    for pid in set(upvotes_by) | set(comments_by):
        _add(str(pid).strip(), None)

    return items


# ---------------------------------------------------------------------------
# review state
# ---------------------------------------------------------------------------


def _load_review_state(path: Path) -> set[str]:
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return set()
    keys = data.get("reviewed_keys")
    if not isinstance(keys, list):
        return set()
    return {key.strip() for key in keys if isinstance(key, str) and key.strip()}


def _save_review_state(path: Path, keys: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "reviewed_keys": sorted(keys),
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# reprocess: recompute codes for a single post_id and persist to 3 files
# ---------------------------------------------------------------------------


def _extract_jav_codes(text: str) -> set[str]:
    if not text:
        return set()
    return {
        f"{letters.upper()}-{numbers}"
        for letters, numbers in _JAV_CODE_PATTERN.findall(text)
    }


def _codes_from_comment_thread(comments: list[Any]) -> set[str]:
    found: set[str] = set()
    for entry in comments:
        if not isinstance(entry, dict):
            continue
        found |= _extract_jav_codes(entry.get("body", ""))
        replies = entry.get("replies") or []
        if replies:
            found |= _codes_from_comment_thread(replies)
    return found


def _reprocess_reddit_post(
    item: ReviewItem,
    *,
    posts_raw_path: Path,
    comments_raw_path: Path,
    upvotes_codes_path: Path,
    comments_codes_path: Path,
    all_codes_path: Path,
) -> tuple[list[str], list[str]]:
    posts = _read_json(posts_raw_path, default=[])
    title: str | None = None
    if isinstance(posts, list):
        for post in posts:
            if not isinstance(post, dict):
                continue
            pid = str(post.get("post_id") or post.get("id") or "")
            if pid == item.post_id:
                title = str(post.get("title") or "")
                break

    if title is None:
        if not item.title:
            raise RuntimeError(
                f"Cannot reprocess {item.post_id}: post is missing from "
                f"{posts_raw_path.name} and the review item has no cached title. "
                "Re-run stage s01 to refresh raw posts, or open the post on Reddit and update the JSON."
            )
        title = item.title

    upvotes_codes = sorted(_extract_jav_codes(title))

    comments_map = _read_json(comments_raw_path, default={})
    thread: list[Any] = []
    if isinstance(comments_map, dict):
        raw_thread = comments_map.get(item.post_id, [])
        if isinstance(raw_thread, list):
            thread = raw_thread
    comments_codes = sorted(_codes_from_comment_thread(thread))

    upvotes_map = _read_json(upvotes_codes_path, default={}) or {}
    if not isinstance(upvotes_map, dict):
        upvotes_map = {}
    upvotes_map[item.post_id] = upvotes_codes
    _write_json(upvotes_codes_path, upvotes_map, indent=4)

    comments_codes_map = _read_json(comments_codes_path, default={}) or {}
    if not isinstance(comments_codes_map, dict):
        comments_codes_map = {}
    comments_codes_map[item.post_id] = comments_codes
    _write_json(comments_codes_path, comments_codes_map)

    all_codes_map = _read_json(all_codes_path, default={}) or {}
    if not isinstance(all_codes_map, dict):
        all_codes_map = {}
    all_codes_map[item.post_id] = {
        "upvotes_codes": upvotes_codes,
        "comments_codes": comments_codes,
    }
    _write_json(all_codes_path, all_codes_map, indent=4)

    return upvotes_codes, comments_codes


# ---------------------------------------------------------------------------
# path opener (macOS / Linux / Windows)
# ---------------------------------------------------------------------------


def _open_path(path: Path) -> None:
    if sys.platform == "darwin":
        subprocess.run(["open", str(path)], check=False)
    elif sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    else:
        subprocess.run(["xdg-open", str(path)], check=False)


# ---------------------------------------------------------------------------
# scrollable frame (unchanged core, mouse wheel cross-platform)
# ---------------------------------------------------------------------------


class ScrollableFrame:
    def __init__(self, parent, *, bg: str) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.container = ttk.Frame(parent)
        self.canvas = tk.Canvas(self.container, highlightthickness=0, bg=bg)
        self.v_scroll = ttk.Scrollbar(self.container, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)

        self.inner_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.v_scroll.set)

        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

        for widget in (self.canvas, self.inner):
            widget.bind("<MouseWheel>", self._on_mousewheel)
            widget.bind("<Button-4>", self._on_mousewheel_linux)
            widget.bind("<Button-5>", self._on_mousewheel_linux)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.v_scroll.pack(side="right", fill="y")

    def _on_inner_configure(self, _event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self.inner_id, width=event.width)

    def _on_mousewheel(self, event):
        delta = event.delta
        if not delta:
            return
        step = -1 if delta > 0 else 1
        if abs(delta) >= 120:
            step = int(-1 * (delta / 120))
        self.canvas.yview_scroll(step, "units")

    def _on_mousewheel_linux(self, event):
        self.canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

    def pack(self, **kwargs):
        return self.container.pack(**kwargs)

    def clear(self) -> None:
        for child in list(self.inner.winfo_children()):
            child.destroy()


# ---------------------------------------------------------------------------
# review UI
# ---------------------------------------------------------------------------


class ReviewUI:
    def __init__(
        self,
        *,
        items: list[ReviewItem],
        state_path: Path,
        posts_raw_path: Path,
        comments_raw_path: Path,
        upvotes_codes_path: Path,
        comments_codes_path: Path,
        all_codes_path: Path,
        title: str = "Reddit codes review",
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry("1200x840")
        self.root.configure(bg=PALETTE["bg"])

        self.state_path = state_path
        self.posts_raw_path = posts_raw_path
        self.comments_raw_path = comments_raw_path
        self.upvotes_codes_path = upvotes_codes_path
        self.comments_codes_path = comments_codes_path
        self.all_codes_path = all_codes_path

        self.reviewed = _load_review_state(self.state_path)
        self.items: list[ReviewItem] = items

        self._apply_theme()

        self.search_var = tk.StringVar()
        self.show_reviewed_var = tk.BooleanVar(value=True)
        self.show_empty_var = tk.BooleanVar(value=False)
        self.sort_var = tk.StringVar(value=SORT_OPTIONS[0][0])
        self.status_var = tk.StringVar()
        self.busy_var = tk.StringVar()

        # Render only the visible tab; others build on first click.
        self._current_bucket: ReviewBucket = BUCKET_TABS[0][0]
        self._dirty_buckets: set[ReviewBucket] = {b for b, _ in BUCKET_TABS}
        self._pending_refresh_id: str | None = None
        # Pagination state per tab + card widget registry for in-place updates.
        self._card_widgets: dict[str, Any] = {}
        self._page_pending: dict[ReviewBucket, list[ReviewItem]] = {
            b: [] for b, _ in BUCKET_TABS
        }
        self._page_footer: dict[ReviewBucket, Any] = {
            b: None for b, _ in BUCKET_TABS
        }

        self._build_toolbar()
        self._build_notebook()
        self._refresh_all()

    # -- lifecycle -----------------------------------------------------------

    def run(self) -> None:
        self.root.mainloop()

    def _apply_theme(self) -> None:
        from tkinter import ttk

        style = ttk.Style()
        for theme in ("clam", "alt", "default"):
            try:
                style.theme_use(theme)
                break
            except Exception:
                continue

        style.configure("TFrame", background=PALETTE["bg"])
        style.configure("TLabel", background=PALETTE["bg"])
        style.configure("Toolbar.TFrame", background=PALETTE["bg"])
        style.configure("Status.TLabel", background=PALETTE["bg"], foreground=PALETTE["subtle"])
        style.configure("Busy.TLabel", background=PALETTE["bg"], foreground=PALETTE["diff_warn"])
        style.configure("TNotebook", background=PALETTE["bg"])
        style.configure("TNotebook.Tab", padding=(14, 6))
        style.configure("TButton", padding=(10, 4))
        style.configure("Accent.TButton", padding=(10, 4))

    # -- toolbar / notebook --------------------------------------------------

    def _build_toolbar(self) -> None:
        import tkinter as tk
        from tkinter import ttk

        top = ttk.Frame(self.root, style="Toolbar.TFrame")
        top.pack(fill="x", padx=12, pady=(10, 4))

        tk.Label(top, text="Search:", bg=PALETTE["bg"], fg=PALETTE["subtle"]).pack(side="left")
        search_entry = ttk.Entry(top, textvariable=self.search_var, width=42)
        search_entry.pack(side="left", padx=(6, 12))
        self.search_var.trace_add("write", lambda *_: self._schedule_refresh())

        ttk.Checkbutton(
            top,
            text="Show reviewed",
            variable=self.show_reviewed_var,
            command=self._refresh_all,
        ).pack(side="left", padx=(0, 12))

        ttk.Checkbutton(
            top,
            text="Show empty",
            variable=self.show_empty_var,
            command=self._on_show_empty_toggle,
        ).pack(side="left", padx=(0, 12))

        tk.Label(top, text="Sort:", bg=PALETTE["bg"], fg=PALETTE["subtle"]).pack(side="left")
        sort_combo = ttk.Combobox(
            top,
            values=[label for label, _ in SORT_OPTIONS],
            textvariable=self.sort_var,
            state="readonly",
            width=22,
        )
        sort_combo.pack(side="left", padx=(6, 12))
        sort_combo.bind("<<ComboboxSelected>>", lambda _e: self._refresh_all())

        ttk.Button(top, text="Reset reviewed", command=self._reset_reviewed).pack(side="right")

        status = ttk.Frame(self.root, style="Toolbar.TFrame")
        status.pack(fill="x", padx=12, pady=(0, 8))
        ttk.Label(status, textvariable=self.status_var, style="Status.TLabel").pack(side="left")
        ttk.Label(status, textvariable=self.busy_var, style="Busy.TLabel").pack(side="right")

    def _build_notebook(self) -> None:
        from tkinter import ttk

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.tabs: dict[ReviewBucket, tuple[ttk.Frame, ScrollableFrame]] = {}
        for bucket, label in BUCKET_TABS:
            tab = ttk.Frame(self.notebook)
            sf = ScrollableFrame(tab, bg=PALETTE["bg"])
            sf.pack(fill="both", expand=True)
            self.tabs[bucket] = (tab, sf)
            self.notebook.add(tab, text=label)
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
        self._apply_empty_visibility()

    # -- data manipulation ---------------------------------------------------

    def _sorted_items(self) -> list[ReviewItem]:
        key = dict(SORT_OPTIONS).get(self.sort_var.get(), "subreddit")
        if key == "post_id":
            return sorted(self.items, key=lambda i: i.post_id)
        if key == "score":
            return sorted(self.items, key=lambda i: (-(i.score or 0), i.post_id))
        if key == "title":
            return sorted(self.items, key=lambda i: (i.title or "").lower())
        return sorted(self.items, key=lambda i: ((i.subreddit or "").lower(), i.post_id))

    def _bucketize(self) -> dict[ReviewBucket, list[ReviewItem]]:
        buckets: dict[ReviewBucket, list[ReviewItem]] = {
            "needs_review": [],
            "matched": [],
            "empty": [],
        }
        for item in self._sorted_items():
            buckets[item.bucket].append(item)
        return buckets

    def _matches_search(self, item: ReviewItem, query: str) -> bool:
        if not query:
            return True
        query = query.lower()
        haystack_parts = [
            item.title or "",
            item.subreddit or "",
            item.post_id or "",
            " ".join(item.upvotes_codes),
            " ".join(item.comments_codes),
        ]
        return any(query in part.lower() for part in haystack_parts)

    # -- refresh -------------------------------------------------------------

    def _refresh_all(self) -> None:
        """Update every tab's count label; render widgets only for the visible tab."""
        buckets = self._bucketize()
        query = self.search_var.get().strip()
        show_reviewed = bool(self.show_reviewed_var.get())

        # Any tab that isn't rendered right now must be rebuilt on first view.
        self._dirty_buckets = {b for b, _ in BUCKET_TABS}
        self._update_tab_titles(buckets=buckets, query=query, show_reviewed=show_reviewed)

        self._render_bucket(
            self._current_bucket,
            buckets=buckets,
            query=query,
            show_reviewed=show_reviewed,
        )
        self._update_status()

    def _update_tab_titles(
        self,
        *,
        buckets: dict[ReviewBucket, list[ReviewItem]] | None = None,
        query: str | None = None,
        show_reviewed: bool | None = None,
    ) -> None:
        if buckets is None:
            buckets = self._bucketize()
        if query is None:
            query = self.search_var.get().strip()
        if show_reviewed is None:
            show_reviewed = bool(self.show_reviewed_var.get())
        for idx, (bucket, label) in enumerate(BUCKET_TABS):
            items_in_bucket = buckets[bucket]
            visible = sum(
                1
                for item in items_in_bucket
                if (show_reviewed or item.key not in self.reviewed)
                and self._matches_search(item, query)
            )
            reviewed_in_bucket = sum(1 for i in items_in_bucket if i.key in self.reviewed)
            total = len(items_in_bucket)
            title = f"{label} ({visible}/{total})"
            if reviewed_in_bucket:
                title += f"  ✓{reviewed_in_bucket}"
            try:
                self.notebook.tab(idx, text=title)
            except Exception:
                pass

    def _render_bucket(
        self,
        bucket: ReviewBucket,
        *,
        buckets: dict[ReviewBucket, list[ReviewItem]] | None = None,
        query: str | None = None,
        show_reviewed: bool | None = None,
    ) -> None:
        if buckets is None:
            buckets = self._bucketize()
        if query is None:
            query = self.search_var.get().strip()
        if show_reviewed is None:
            show_reviewed = bool(self.show_reviewed_var.get())
        _, sf = self.tabs[bucket]
        sf.clear()
        # sf.clear() destroyed every child widget, invalidating registered cards.
        self._page_footer[bucket] = None
        self._prune_card_widgets()

        matching = [
            item
            for item in buckets[bucket]
            if (show_reviewed or item.key not in self.reviewed)
            and self._matches_search(item, query)
        ]
        first_page = matching[:PAGE_SIZE]
        self._page_pending[bucket] = matching[PAGE_SIZE:]
        for item in first_page:
            self._render_card(sf, item, item.key in self.reviewed)
        self._render_show_more_footer(bucket)
        self._dirty_buckets.discard(bucket)

    def _render_show_more_footer(self, bucket: ReviewBucket) -> None:
        import tkinter as tk
        from tkinter import ttk

        old = self._page_footer.get(bucket)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass
            self._page_footer[bucket] = None

        remaining = len(self._page_pending.get(bucket) or [])
        if remaining <= 0:
            return

        _, sf = self.tabs[bucket]
        footer = tk.Frame(sf.inner, bg=PALETTE["bg"])
        footer.pack(fill="x", padx=6, pady=(4, 12))
        next_batch = min(PAGE_SIZE, remaining)
        ttk.Button(
            footer,
            text=f"Show {next_batch} more ({remaining} remaining)",
            command=lambda b=bucket: self._on_show_more(b),
        ).pack(side="left")
        ttk.Button(
            footer,
            text="Show all",
            command=lambda b=bucket: self._on_show_more(b, all_remaining=True),
        ).pack(side="left", padx=(8, 0))
        self._page_footer[bucket] = footer

    def _on_show_more(self, bucket: ReviewBucket, *, all_remaining: bool = False) -> None:
        pending = self._page_pending.get(bucket) or []
        if not pending:
            return
        take = len(pending) if all_remaining else min(PAGE_SIZE, len(pending))
        batch = pending[:take]
        self._page_pending[bucket] = pending[take:]
        _, sf = self.tabs[bucket]
        old_footer = self._page_footer.get(bucket)
        if all_remaining:
            self.busy_var.set(f"Loading {len(batch)} more cards…")
            self.root.update_idletasks()
        for item in batch:
            self._render_card(
                sf, item, item.key in self.reviewed, before=old_footer
            )
        self._render_show_more_footer(bucket)
        if all_remaining:
            self.busy_var.set("")

    def _prune_card_widgets(self) -> None:
        dead = [
            key
            for key, widget in self._card_widgets.items()
            if widget is None or not widget.winfo_exists()
        ]
        for key in dead:
            self._card_widgets.pop(key, None)

    def _on_show_empty_toggle(self) -> None:
        self._apply_empty_visibility()

    def _apply_empty_visibility(self) -> None:
        for idx, (bucket, _) in enumerate(BUCKET_TABS):
            if bucket != "empty":
                continue
            state = "normal" if self.show_empty_var.get() else "hidden"
            try:
                self.notebook.tab(idx, state=state)
            except Exception:
                pass
            break

    def _on_tab_changed(self, _event) -> None:
        try:
            idx = self.notebook.index("current")
        except Exception:
            return
        if idx < 0 or idx >= len(BUCKET_TABS):
            return
        bucket = BUCKET_TABS[idx][0]
        self._current_bucket = bucket
        if bucket in self._dirty_buckets:
            # Show a hint while Tk builds potentially thousands of widgets.
            self.busy_var.set(f"Loading {bucket.replace('_', ' ')}…")
            self.root.update_idletasks()
            self._render_bucket(bucket)
            self.busy_var.set("")

    def _schedule_refresh(self, delay_ms: int = 200) -> None:
        if self._pending_refresh_id is not None:
            try:
                self.root.after_cancel(self._pending_refresh_id)
            except Exception:
                pass
        self._pending_refresh_id = self.root.after(delay_ms, self._run_pending_refresh)

    def _run_pending_refresh(self) -> None:
        self._pending_refresh_id = None
        self._refresh_all()

    def _update_status(self) -> None:
        total = len(self.items)
        reviewed = sum(1 for item in self.items if item.key in self.reviewed)
        remaining = total - reviewed
        self.status_var.set(
            f"Remaining: {remaining}  ·  Reviewed: {reviewed}  ·  Total: {total}  ·  State: {self.state_path}"
        )

    # -- state ---------------------------------------------------------------

    def _reset_reviewed(self) -> None:
        from tkinter import messagebox

        if not self.reviewed:
            return
        if not messagebox.askyesno(
            "Reset reviewed", "Clear all reviewed items? Cards will stay visible but green tint will be removed."
        ):
            return
        self.reviewed = set()
        try:
            _save_review_state(self.state_path, self.reviewed)
        except Exception as error:
            messagebox.showerror("Error", f"Failed to write state file:\n{error}")
            return
        self._refresh_all()

    def _persist_review_state(self) -> None:
        from tkinter import messagebox

        try:
            _save_review_state(self.state_path, self.reviewed)
        except Exception as error:
            messagebox.showerror("Error", f"Failed to write state file:\n{error}")

    # -- rendering -----------------------------------------------------------

    def _render_list(
        self,
        sf: ScrollableFrame,
        items: list[ReviewItem],
        *,
        query: str,
        show_reviewed: bool,
    ) -> int:
        visible = 0
        for item in items:
            is_reviewed = item.key in self.reviewed
            if is_reviewed and not show_reviewed:
                continue
            if not self._matches_search(item, query):
                continue
            self._render_card(sf, item, is_reviewed)
            visible += 1
        return visible

    def _render_card(
        self,
        sf: ScrollableFrame,
        item: ReviewItem,
        is_reviewed: bool,
        *,
        before: Any | None = None,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        card_bg = PALETTE["reviewed_bg"] if is_reviewed else PALETTE["card_bg"]
        if is_reviewed:
            border = PALETTE["reviewed_border"]
        elif item.bucket == "matched":
            border = PALETTE["matched_border"]
        elif item.bucket == "needs_review":
            border = PALETTE["needs_border"]
        else:
            border = PALETTE["empty_border"]

        card = tk.Frame(
            sf.inner,
            bg=card_bg,
            highlightbackground=border,
            highlightthickness=2,
            padx=12,
            pady=10,
        )
        pack_kwargs: dict[str, Any] = {
            "fill": "x",
            "expand": True,
            "padx": 6,
            "pady": 6,
        }
        if before is not None:
            try:
                if before.winfo_exists():
                    pack_kwargs["before"] = before
            except Exception:
                pass
        card.pack(**pack_kwargs)
        self._card_widgets[item.key] = card

        header = tk.Frame(card, bg=card_bg)
        header.pack(fill="x")

        title_text = item.title.strip() or "(no title)"
        if len(title_text) > 200:
            title_text = title_text[:197] + "..."
        tk.Label(
            header,
            text=title_text,
            font=("TkDefaultFont", 11, "bold"),
            bg=card_bg,
            fg="#202124",
            wraplength=1000,
            justify="left",
            anchor="w",
        ).pack(side="left", fill="x", expand=True)

        pill_bg = PALETTE["reviewed_badge_bg"] if is_reviewed else "#f1f3f4"
        pill_fg = PALETTE["reviewed_badge_fg"] if is_reviewed else PALETTE["subtle"]
        pill_text = "✓ Reviewed" if is_reviewed else item.bucket.replace("_", " ").title()
        tk.Label(
            header,
            text=f"  {pill_text}  ",
            bg=pill_bg,
            fg=pill_fg,
            font=("TkDefaultFont", 9, "bold"),
            padx=6,
            pady=2,
        ).pack(side="right")

        meta_parts = [
            f"r/{item.subreddit}" if item.subreddit else None,
            f"score {item.score}" if item.score is not None else None,
            item.created_time,
            item.post_id,
        ]
        meta = " · ".join(p for p in meta_parts if p)
        if meta:
            tk.Label(card, text=meta, fg=PALETTE["subtle"], bg=card_bg, anchor="w").pack(fill="x", pady=(2, 0))

        actions = tk.Frame(card, bg=card_bg)
        actions.pack(fill="x", pady=(8, 0))
        if item.permalink:
            ttk.Button(
                actions,
                text="Open Reddit",
                command=lambda url=item.permalink: self._open_target(url, "url"),
            ).pack(side="left", padx=(0, 6))
        if item.redgif_url:
            ttk.Button(
                actions,
                text="Open Redgifs",
                command=lambda url=item.redgif_url: self._open_target(url, "url"),
            ).pack(side="left", padx=(0, 6))

        tk.Label(
            card,
            text=f"Upvotes codes: {self._join_codes(item.upvotes_codes)}",
            bg=card_bg,
            anchor="w",
            wraplength=1120,
            justify="left",
        ).pack(fill="x", pady=(8, 0))
        tk.Label(
            card,
            text=f"Comments codes: {self._join_codes(item.comments_codes)}",
            bg=card_bg,
            anchor="w",
            wraplength=1120,
            justify="left",
        ).pack(fill="x", pady=(2, 0))

        if item.upvotes_codes or item.comments_codes:
            up_set = set(item.upvotes_codes)
            cm_set = set(item.comments_codes)
            up_only = [c for c in item.upvotes_codes if c not in cm_set]
            cm_only = [c for c in item.comments_codes if c not in up_set]
            if up_only or cm_only:
                parts = []
                if up_only:
                    parts.append(f"Upvotes only: {', '.join(up_only)}")
                if cm_only:
                    parts.append(f"Comments only: {', '.join(cm_only)}")
                tk.Label(
                    card,
                    text="  ·  ".join(parts),
                    bg=card_bg,
                    fg=PALETTE["diff_warn"],
                    anchor="w",
                    wraplength=1120,
                    justify="left",
                ).pack(fill="x", pady=(4, 0))
            else:
                tk.Label(
                    card,
                    text="Match: upvotes and comments codes are the same.",
                    bg=card_bg,
                    fg=PALETTE["diff_ok"],
                    anchor="w",
                    wraplength=1120,
                    justify="left",
                ).pack(fill="x", pady=(4, 0))

        all_codes = list(dict.fromkeys(item.upvotes_codes + item.comments_codes))
        if all_codes:
            self._render_trailers(card, item, all_codes, card_bg)

        if item.comments_preview:
            self._render_comments(card, item, card_bg)

        footer = tk.Frame(card, bg=card_bg)
        footer.pack(fill="x", pady=(10, 0))

        checked_var = tk.BooleanVar(value=is_reviewed)
        ttk.Checkbutton(
            footer,
            text="Reviewed",
            variable=checked_var,
            command=lambda it=item, v=checked_var: self._on_check_toggle(it, v),
        ).pack(side="left")

        ttk.Button(
            footer,
            text="↻ Reprocess",
            command=lambda it=item: self._on_reprocess(it),
        ).pack(side="left", padx=(10, 0))

        ttk.Button(
            footer,
            text="Copy upvotes",
            command=lambda c=list(item.upvotes_codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(10, 0))
        ttk.Button(
            footer,
            text="Copy comments",
            command=lambda c=list(item.comments_codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(6, 0))
        ttk.Button(
            footer,
            text="Copy all",
            command=lambda c=list(all_codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(6, 0))

    def _render_trailers(self, parent, item: ReviewItem, all_codes: list[str], bg: str) -> None:
        import tkinter as tk
        from tkinter import ttk

        box = tk.LabelFrame(parent, text="Trailers", bg=bg, fg="#202124", padx=8, pady=4)
        box.pack(fill="x", pady=(8, 0))
        for code in all_codes:
            links = item.trailer_links.get(code)
            row = tk.Frame(box, bg=bg)
            row.pack(fill="x", pady=2)
            if links:
                tk.Label(row, text=f"{code}: {len(links)} link(s)", bg=bg).pack(side="left")
                ttk.Button(
                    row,
                    text="Open first",
                    command=lambda url=links[0]: self._open_target(url, "url"),
                ).pack(side="left", padx=(8, 0))
            elif code in item.codes_not_found:
                tk.Label(row, text=f"{code}: not found", bg=bg, fg="#c62828").pack(side="left")
            else:
                tk.Label(row, text=f"{code}: no trailer info", bg=bg, fg=PALETTE["subtle"]).pack(side="left")

    def _render_comments(self, parent, item: ReviewItem, bg: str) -> None:
        import tkinter as tk

        box = tk.LabelFrame(
            parent,
            text=f"Top comments (first {len(item.comments_preview)})",
            bg=bg,
            fg="#202124",
            padx=8,
            pady=4,
        )
        box.pack(fill="x", pady=(8, 0))
        for body in item.comments_preview:
            snippet = body if len(body) < 400 else body[:397] + "..."
            tk.Label(
                box,
                text=f"• {snippet}",
                bg=bg,
                anchor="w",
                wraplength=1100,
                justify="left",
            ).pack(fill="x", padx=2, pady=2)

    def _join_codes(self, codes: list[str]) -> str:
        return ", ".join(codes) if codes else "<none>"

    # -- event handlers ------------------------------------------------------

    def _on_check_toggle(self, item: ReviewItem, var) -> None:
        is_reviewed_now = bool(var.get())
        if is_reviewed_now:
            self.reviewed.add(item.key)
        else:
            self.reviewed.discard(item.key)
        self._persist_review_state()
        self._update_tab_titles()
        self._update_status()

        # If reviewed rows are hidden, the toggled card must disappear.
        if is_reviewed_now and not bool(self.show_reviewed_var.get()):
            self._render_bucket(self._current_bucket)
            return

        old = self._card_widgets.get(item.key)
        if old is None:
            return
        try:
            exists = bool(old.winfo_exists())
        except Exception:
            exists = False
        if not exists:
            self._card_widgets.pop(item.key, None)
            return

        sf_inner = old.master
        try:
            children = list(sf_inner.winfo_children())
            idx = children.index(old)
        except (ValueError, Exception):
            self._render_bucket(self._current_bucket)
            return
        next_sibling = children[idx + 1] if idx + 1 < len(children) else None
        old.destroy()
        self._card_widgets.pop(item.key, None)
        _, sf = self.tabs[self._current_bucket]
        self._render_card(sf, item, is_reviewed_now, before=next_sibling)

    def _on_reprocess(self, item: ReviewItem) -> None:
        from tkinter import messagebox

        self.busy_var.set(f"Reprocessing {item.post_id}...")
        self.root.update_idletasks()
        try:
            upvotes, comments = _reprocess_reddit_post(
                item,
                posts_raw_path=self.posts_raw_path,
                comments_raw_path=self.comments_raw_path,
                upvotes_codes_path=self.upvotes_codes_path,
                comments_codes_path=self.comments_codes_path,
                all_codes_path=self.all_codes_path,
            )
        except Exception as error:
            self.busy_var.set("")
            messagebox.showerror("Reprocess failed", str(error))
            return

        item.upvotes_codes = upvotes
        item.comments_codes = comments
        item.bucket = _bucket_for(upvotes, comments)

        self.busy_var.set(f"Reprocessed {item.post_id}: {len(upvotes)} upvotes, {len(comments)} comments codes.")
        self.root.after(2500, lambda: self.busy_var.set(""))
        self._refresh_all()

    def _copy_to_clipboard(self, text: str) -> None:
        from tkinter import messagebox

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update_idletasks()
        except Exception as error:
            messagebox.showerror("Error", f"Failed to copy to clipboard:\n{error}")

    def _open_target(self, target: str, kind: Literal["path", "url"]) -> None:
        from tkinter import messagebox

        try:
            if kind == "url":
                webbrowser.open(target)
                return
            path = Path(target)
            if not path.exists():
                messagebox.showerror("Missing", f"Not found:\n{path}")
                return
            _open_path(path)
        except Exception as error:
            messagebox.showerror("Error", str(error))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    root = _repo_root()
    parser = argparse.ArgumentParser(
        prog="python -m reddit_autom.ui.review_ui",
        description="UI to review Reddit upvote + comment codes and reprocess posts.",
    )
    parser.add_argument(
        "--posts-json",
        default=str(root / "reddit_comments" / "data" / "raw" / "all_upvoted_posts.json"),
        help="Path to all_upvoted_posts.json",
    )
    parser.add_argument(
        "--codes-json",
        default=str(root / "reddit_comments" / "data" / "derived" / "all_codes.json"),
        help="Path to the combined all_codes.json",
    )
    parser.add_argument(
        "--upvotes-codes-json",
        default=str(root / "reddit_comments" / "data" / "derived" / "extract_codes_upvotes.json"),
        help="Path to the upvotes codes map",
    )
    parser.add_argument(
        "--comments-codes-json",
        default=str(root / "reddit_comments" / "data" / "derived" / "extract_codes_comments.json"),
        help="Path to the comments codes map",
    )
    parser.add_argument(
        "--comments-json",
        default=str(root / "reddit_comments" / "data" / "raw" / "comments.json"),
        help="Path to comments.json (post_id -> list of comment objects)",
    )
    parser.add_argument(
        "--trailer-links-json",
        default=str(root / "trailer_codes" / "trailer_links.json"),
        help="Path to trailer_links.json (code -> list of URLs)",
    )
    parser.add_argument(
        "--not-found-json",
        default=str(root / "trailer_codes" / "not_found_codes.json"),
        help="Path to not_found_codes.json",
    )
    parser.add_argument(
        "--state",
        default=str(root / "reddit_review_state.json"),
        help="Path to review state JSON",
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Print item counts and exit (no UI)",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    posts_raw = _read_json(Path(args.posts_json), default=[])
    posts = posts_raw if isinstance(posts_raw, list) else []

    upvotes_by, comments_by = _load_codes_map(
        Path(args.codes_json), Path(args.upvotes_codes_json), Path(args.comments_codes_json)
    )
    comments_bodies = _load_comments_bodies(Path(args.comments_json))
    trailer_links = _load_trailer_links(Path(args.trailer_links_json))
    not_found_codes = _load_not_found(Path(args.not_found_json))

    items = _build_items(
        posts,
        upvotes_by=upvotes_by,
        comments_by=comments_by,
        comments_bodies=comments_bodies,
        trailer_links=trailer_links,
        not_found_codes=not_found_codes,
    )

    if not items:
        raise SystemExit(
            "No Reddit review items found. Check --posts-json / --codes-json paths."
        )

    if args.summary:
        counts = {bucket: 0 for bucket, _ in BUCKET_TABS}
        with_trailers = 0
        for item in items:
            counts[item.bucket] += 1
            if item.trailer_links:
                with_trailers += 1
        print(
            json.dumps(
                {
                    "total": len(items),
                    "by_bucket": counts,
                    "with_trailer_links": with_trailers,
                    "state_path": args.state,
                },
                indent=2,
            )
        )
        return 0

    ui = ReviewUI(
        items=items,
        state_path=Path(args.state),
        posts_raw_path=Path(args.posts_json),
        comments_raw_path=Path(args.comments_json),
        upvotes_codes_path=Path(args.upvotes_codes_json),
        comments_codes_path=Path(args.comments_codes_json),
        all_codes_path=Path(args.codes_json),
        title="Reddit codes review",
    )
    ui.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
