from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .ocr_tools import extract_codes_from_image
from .video_tools import download_file


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def ocr_image_post(
    post: dict[str, Any],
    *,
    downloads_dir: Path,
    pattern: str | None = None,
) -> dict[str, Any]:
    """
    For `post_type == "image_post"` (single post):
    - downloads the image
    - runs OCR and returns matching codes
    """
    if post.get("post_type") != "image_post":
        raise ValueError(f"Expected post_type=image_post, got {post.get('post_type')!r}")

    media = post.get("media")
    if not isinstance(media, list):
        raise ValueError("Post is missing `media` list")

    image_item = next(
        (
            item
            for item in media
            if isinstance(item, dict) and item.get("type") == "image" and item.get("url")
        ),
        None,
    )
    if not image_item:
        raise ValueError("No image media URL found for this post")

    post_key = str(post.get("shortcode") or post.get("post_id") or "post")
    downloads_dir.mkdir(parents=True, exist_ok=True)

    image_path = downloads_dir / f"{post_key}.jpg"
    if not image_path.exists():
        download_file(str(image_item["url"]), image_path)

    codes = extract_codes_from_image(image_path, pattern=pattern)
    return {
        "post_id": post.get("post_id"),
        "shortcode": post.get("shortcode"),
        "post_type": post.get("post_type"),
        "image_path": str(image_path),
        "codes": codes,
        "count": len(codes),
    }


def _load_posts(posts_path: Path) -> list[dict[str, Any]]:
    raw = json.loads(posts_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected posts JSON to be a list (like posts.json)")
    return [item for item in raw if isinstance(item, dict)]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m aaii.ocr_image_post",
        description="Download single image posts from posts.json and OCR them to extract codes.",
    )
    parser.add_argument("--posts", default="posts.json", help="Input posts.json (default: posts.json)")
    parser.add_argument(
        "--out",
        default="ocr_results_image_post.json",
        help="Output results JSON (default: ocr_results_image_post.json)",
    )
    parser.add_argument("--limit", type=int, default=None, help="Max image posts to OCR (default: all)")
    parser.add_argument("--pattern", default=None, help="Regex pattern override (optional)")
    parser.add_argument(
        "--downloads-dir",
        default=str(_repo_root() / "downloads" / "image_post"),
        help="Where to store downloaded images",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    posts_path = Path(args.posts)
    out_path = Path(args.out)
    downloads_dir = Path(args.downloads_dir)

    posts = _load_posts(posts_path)
    image_posts = [p for p in posts if p.get("post_type") == "image_post"]
    if args.limit is not None:
        if args.limit < 0:
            raise SystemExit("--limit must be >= 0")
        image_posts = image_posts[: args.limit]

    results: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    for post in image_posts:
        try:
            results.append(
                ocr_image_post(
                    post,
                    downloads_dir=downloads_dir,
                    pattern=args.pattern,
                )
            )
        except Exception as e:
            failures.append(
                {
                    "post_id": post.get("post_id"),
                    "shortcode": post.get("shortcode"),
                    "error": str(e),
                }
            )

    payload = {
        "post_type": "image_post",
        "total": len(image_posts),
        "processed": len(results),
        "failed": len(failures),
        "results": results,
        "failures": failures,
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(out_path), "processed": len(results), "failed": len(failures)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
