"""
Small helper package for the scripts in the repo root.

Use via: `python -m aaii ...`
"""

__all__ = ["__version__"]

__version__ = "0.1.0"

