# Full_video_fetch — Execution Steps

Ad-hoc scrapers that resolve a JAV code to a trailer / streaming URL by trying several mirror sites. Nothing here is wired into the main pipeline — each script is a standalone experiment. Edit the code list at the top of a script, then run it.

## Files

| File | Target site | Purpose |
|------|-------------|---------|
| `main.py` | `javx.cc` | Given a list of codes, scrape the video page and pull embed / trailer links. Writes `htmll.txt`, `resp.txt`, `points.txt`, `links.txt`, `codes.json`. |
| `test.py` | `javx.cc` | Single-code fetch of the HTML page into `htmll.txt`. |
| `test2.py` | — | Parses `htmll.txt` and prints anchor names + hrefs. |
| `j_english.py` | `javenglish.net` / `javflix.cc` | Fetch English-subtitle links. |
| `turbovid.py` | `emturbovid.com` | Uses Playwright + Brave to capture the `.m3u8` URL for a video. Windows-only path hardcoded. |
| `j_gg/javgg.py` | `javgg.net` | Cloudscraper-based result-list scrape for a single code. See [j_gg/Steps.md](j_gg/Steps.md). |
| `codes.json`, `links.txt`, `points.txt`, `htmll.txt`, `resp.txt`, `jurhtml.txt` | Cached artifacts. |

## Prerequisites

```bash
pip install requests beautifulsoup4 cloudscraper playwright
playwright install chromium
```

`turbovid.py` also needs the Brave browser installed. The hardcoded path is:
```
C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe
```
Edit it for macOS/Linux before running.

## Order

None — each script is independent. Typical workflow:

### 1. Edit the code list at the top of the script you want to run
```python
codes = ["JUR-567", "JUQ-663", ...]
```

### 2. Run
```bash
# javx.cc
python Insta_Autom/Full_video_fetch/main.py

# javenglish.net / javflix.cc
python Insta_Autom/Full_video_fetch/j_english.py

# emturbovid.com (Playwright)
python Insta_Autom/Full_video_fetch/turbovid.py

# javgg.net (via wrapper)
python Insta_Autom/Full_video_fetch/j_gg/javgg.py
```

### 3. Debug leftovers
- `test.py` — dump raw HTML for one code into `htmll.txt`.
- `test2.py` — parse `htmll.txt` and print `<a>` tags.

## Notes

- These scripts are fragile — target sites change layout regularly. Expect to edit selectors.
- Results are **not** merged back into `reddit_autom/trailer_codes/trailer_links.json` automatically; copy over manually if needed.
