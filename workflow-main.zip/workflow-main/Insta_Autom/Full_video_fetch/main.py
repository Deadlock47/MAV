import subprocess

result = subprocess.run(["python", "./j_gg/javgg.py"], shell=True)

print("Done!!!!")