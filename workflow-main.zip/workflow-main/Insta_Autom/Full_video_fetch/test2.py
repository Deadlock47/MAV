from bs4 import BeautifulSoup

# read HTML from text file
with open("htmll.txt", "r", encoding="utf-8") as f:
    html = f.read()

# parse HTML
soup = BeautifulSoup(html, "html.parser")

# find all <a> tags
ul = soup.select_one("#sourcetabs ul")

links = ul.find_all("a")
# list_of_strings = ["dood","mixdrop","emturbovid","streamtape","voe","playtube","strmup","hgcloud"]

for link in links:
    # if any(substring in link.get("href") for substring in list_of_strings):
        print("Name:", link.get("name"))
        print("Href:", link.get("href"))
        print()