######################################################
######################################################
######################################################
# 
# 1. Get video url html and store it in a file
# 2. Get all href from all links element
# 3. Check with other sites , and collate everything.
# 
######################################################
######################################################
######################################################
import requests
from bs4 import BeautifulSoup
codes = [
    "JUR-567",
  "JUQ-663",
  "JUQ-903",
  "SONE-274",
  "IPX-758",
  "MEYD-403",
  "STARS-298"
]
def get_embeds_for_code(code):
    full_data = {}
    code = code.lower()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36",
       
    }
    req = requests.get(f"https://javx.cc/video/{code}",headers=headers)
    print(req.url)
    with open("htmll.txt",'w',encoding="utf-8") as p:
        p.write(req.text)
    print("Fetching HTML>>")

    html = req.text

    # parse HTML
    soup = BeautifulSoup(html, "html.parser")

    # find all <a> tags
    ul = soup.select_one("#sourcetabs ul")

    links = ul.find_all("a")
    # list_of_strings = ["dood","mixdrop","emturbovid","streamtape","voe","playtube","strmup","hgcloud"]
    url_data = {}
    for link in links:
        # if any(substring in link.get("href") for substring in list_of_strings):
        # print("Name:", link.get("name"))
        # print("Href:", link.get("href"))
        arr = link.get("name").split('.')
        url_data[arr[0]] = link.get("href")

    print(url_data)
    full_data[code] = url_data
    return full_data

final_data = []

for code in codes:
    code_data = {code : {}}
    try:
        code_data = get_embeds_for_code(code)
    except Exception as e:
        print(f"Error extracting comments: {e}")
    final_data.append(code_data)

print(final_data)