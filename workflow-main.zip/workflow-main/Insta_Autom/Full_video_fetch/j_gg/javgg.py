import cloudscraper
from bs4 import BeautifulSoup

code = "JUR-567"
url = f"https://javgg.net/?s={code}"
def get_url_html(url):
    scraper = cloudscraper.create_scraper()


    res = scraper.get(url)

    print(res.status_code)

    soup = BeautifulSoup(res.text, "html.parser")
    print(soup.title)
    return soup

    # parse HTML
# soup = BeautifulSoup(html, "html.parser")

# find all <a> tags
soup = get_url_html(url)
links = soup.find_all("div", class_="result-item")

# links = .find_all("a")
# list_of_strings = ["dood","mixdrop","emturbovid","streamtape","voe","playtube","strmup","hgcloud"]
url_data = []
for link in links:
    # if any(substring in link.get("href") for substring in list_of_strings):
    # print("Name:", link.get("name"))
    # print("Href:", link.get("href"))
    lt = link.find_all('a')
    a_tag = (lt[1])
    text = a_tag.get_text(strip=True)
    url = a_tag["href"]
    print(text)
    print(url)
    url_data.append({text:url})

print(url_data)

eng_url = ""
mosaic_url = ""
final_url = ""
for item in url_data:
    for key, value in item.items():
        if ('English' in key) or ('eng' in key.lower()):
            eng_url = value
        elif ('Mosaic' in key) or ('Mos' in key.lower()):
            mosaic_url = value
        else :
            final_url = value
            
########################################################

print(eng_url,mosaic_url,final_url)

########################################################

eng_soup = get_url_html(eng_url)
list_players = eng_soup.find_all("div",class_="source-box")

print(len(list_players))
one_link = (list_players[1].find_all('iframe')[0].get('src'))

vid_player_html = get_url_html(one_link)
vid_player_html.

