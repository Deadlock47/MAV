# j_gg — Execution Steps

Cloudscraper-based scraper for `javgg.net`.

## Files

| File | Purpose |
|------|---------|
| `javgg.py` | Given a hardcoded code (edit line ~3), searches `https://javgg.net/?s=<code>` and prints the result-item titles + URLs. |

## Order

### 1. Edit the code
Open `javgg.py` and change:
```python
code = "JUR-567"
```

### 2. Run
```bash
python Insta_Autom/Full_video_fetch/j_gg/javgg.py
```

Or via the wrapper in the parent folder:
```bash
python Insta_Autom/Full_video_fetch/main.py    # invokes ./j_gg/javgg.py
```
Note: the wrapper uses `subprocess.run(["python", "./j_gg/javgg.py"], shell=True)`, so its cwd must be `Insta_Autom/Full_video_fetch/` for the relative path to resolve. Prefer running `javgg.py` directly.

## Prerequisites

```bash
pip install cloudscraper beautifulsoup4
```
