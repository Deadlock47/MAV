from playwright.sync_api import sync_playwright

brave_path = r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"

def capture_m3u8(response):
    if ".m3u8" in response.url:
        print("M3U8 URL:", response.url)
def get_turbovid_url():
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=brave_path,headless=False)  # visible browser

        context = browser.new_context()
        page = context.new_page()
        

        page.goto("https://emturbovid.com/t/69989b72475fb")
        page.wait_for_timeout(1000)
        page.on("response", capture_m3u8)
        
        
        page.wait_for_selector("#pop2")
        print("Page Clicked!!!",page.url)
        # page.locator("#pop2").click()
        print("Page Loading Done!!!!!")
        page.wait_for_timeout(5000)  # keep browser open for 10 sec
        browser.close()
        
get_turbovid_url()