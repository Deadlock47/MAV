import requests

req = requests.get("https://javx.cc/video/JUR-663")

print(req.text)

with open("htmll.txt",'w',encoding="utf-8") as p:
    p.write(req.text)
