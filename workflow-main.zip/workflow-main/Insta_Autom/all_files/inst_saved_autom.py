import requests
import json
from urllib.parse import quote


url = "https://www.instagram.com/api/v1/feed/collection/18025099568665354/posts/?max_id="
def get_url(param): 
    print(quote(param))
    return f'https://www.instagram.com/api/v1/feed/collection/18025099568665354/posts/?max_id={quote(param)}'

# YOUR_SESSION_ID = "59799985019:bsN9KijX1P5yRB:28:AYgsQ4xedjEFAr7ks01g7j-H9UcubPcEha-7B0bK-g"

# params = {
#     "query_hash": "2b0673e0dc4580674a88d426fe00ea90",
#     "variables": json.dumps({
#         "collection_id": "18025099568665354",
#         "first": 50
#     })
# }

headers = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "*/*",
    "X-IG-App-ID": "936619743392459",
    "Referer": "https://www.instagram.com/",
    "Cookie": 'csrftoken=Hq8lc67-WSITdkWBXZfE8A; datr=nQh6arI_DA3CBq42vkN1fATD; ig_did=62C2386E-29F9-4E2B-A140-B04F585D252E; mid=anoInQALAAHaPsicBithPOPX6mpY; dpr=1.25; ds_user_id=59799985019; sessionid=59799985019%3ASQiD2IbMl4fd8X%3A15%3AAYiXayN8OCzNCT-UxVMqqoj1T7tz1-ikzJeAG22HyQ; wd=770x702; rur=EAG%2C17841459790574998%2C1789282852%3A01ff1a41946c52e450b7eefc52d9f3e7a210227d68eeb08273f611321325ad0b908212ff'
}


r = requests.get(url,headers=headers, allow_redirects=False)
data = r.json()
print(len(data['items']))
with open("data.json", "w") as file:
    json.dump(data['items'], file)
next_max = data['next_max_id']
while len(next_max)>0:
    try : 
        print(next_max)
        print(get_url(next_max))
        r = requests.get(get_url(next_max),headers=headers, allow_redirects=False)
        new_data = r.json()
        # print(data)
        print(len(new_data['items']))
        # read existing file
        with open("data.json", "r") as f:
            json_data = json.load(f)

        # append new object
        json_data = json_data+new_data['items']

        # write back
        with open("data.json", "w") as f:
            json.dump(json_data, f, indent=2)

        next_max = new_data['next_max_id']
        if new_data['next_max_id'] == "":
            break
    
    except : 
        next_max = ""
        print("Completed!!!")
# print("fetched data.....")
# print(len(data['items']))