# all_files — Execution Steps

**Legacy** — pre-refactor Instagram scripts. Superseded by `../aaii/`. Kept only because the working data files (`data.json`, `posts.json`, `ocr_results_*.json`) live next to them.

Do **not** wire these into the current pipeline. Use `python -m Insta_Autom.aaii ...` instead.

## Files

| File | Legacy role | Modern replacement |
|------|-------------|--------------------|
| `inst_saved_autom.py` | Fetches saved-collection items into `data.json`. Hardcoded cookie. | `python -m Insta_Autom.aaii ig fetch` |
| `finalized_ocr.py` | `get_text_ocr(image_path)` using doctr. | `Insta_Autom.aaii.ocr_tools.extract_codes_from_image` |
| `test1.py` | Empty / scratch. | — |
| `test3.py` | Downloads a video and OCRs frames. | `python -m Insta_Autom.aaii video download` + `python -m Insta_Autom.aaii ocr video` |
| `data.json`, `posts.json`, `ocr_results_*.json`, `ocr_review_state.json` | Working artifacts (regenerable). | — |
| `f.txt`, `f (1).txt` | Scratch notes. | — |

## If you must run them (debug only)

From this folder (`Insta_Autom/all_files/`):

```bash
python inst_saved_autom.py     # writes data.json (uses hardcoded cookie — edit first)
python test3.py                # downloads + OCRs a video (edit URL at top)
```

## Recommendation

Migrate to `../aaii/` for anything new. See [../aaii/Steps.md](../aaii/Steps.md).
