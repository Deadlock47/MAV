# comments — Execution Steps

Fetch Instagram comments per post and extract JAV codes from them.

## Files

| File | Purpose |
|------|---------|
| `ig_comments.py` | Library: `build_headers`, `fetch_all_comments`, `child_comments_url`. Handles pagination + rate limiting. |
| `fetch_comments.py` | Script: reads `posts.json`, calls IG API for each post, writes one JSON per post (or a single combined file). |
| `extract_codes.py` | Script: reads a `comments.json` file, applies a regex, writes `codes_from_comments.json`. |
| `comments.json` | Cached output of `fetch_comments.py`. |
| `codes_from_comments.json` | Output of `extract_codes.py`. |

## Prerequisites

```bash
export IG_COOKIE='csrftoken=...; sessionid=...; ds_user_id=...'
```

Need `posts.json` first — produced by `python -m Insta_Autom.aaii ig parse`.

## Order (from workspace root)

### 1. Fetch comments for every post
```bash
python Insta_Autom/comments/fetch_comments.py \
  --posts Insta_Autom/posts.json \
  --out-dir Insta_Autom/comments/per_post
# or single file
python Insta_Autom/comments/fetch_comments.py \
  --posts Insta_Autom/posts.json \
  --out Insta_Autom/comments/comments.json
```

Check `fetch_comments.py --help` for the exact flags supported by your copy.

### 2. Extract codes from comments
```bash
python Insta_Autom/comments/extract_codes.py \
  --in Insta_Autom/comments/comments.json \
  --out Insta_Autom/comments/codes_from_comments.json \
  --pattern '[A-Za-z]{2,5}-?\d{3,5}'
```

## Notes

- `ig_comments.py` is a library — do not run it directly.
- IG rate-limits aggressively; leave the default sleeps in place.
- The review UI merges these codes with OCR codes: see [../ui/Steps.md](../ui/Steps.md).
