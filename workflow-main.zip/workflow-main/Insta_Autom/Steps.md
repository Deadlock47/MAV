# Insta_Autom — Execution Steps

Top-level index for the Instagram workflow. There are two generations of code:

- **New (recommended):** `aaii/` — a package with a CLI and a clean OCR module split.
- **Legacy (kept for reference):** `all_files/` — pre-refactor monoliths.

Separate helpers live in `comments/` (IG comment scrape + code extraction) and `Full_video_fetch/` (ad-hoc trailer URL scrapers).

## Sub-pipelines

| Order | Folder | Purpose |
|-------|--------|---------|
| 1 | [aaii/](aaii/Steps.md) | IG saved-collection fetch → post parse → OCR (image / carousel / video) |
| 2 | [comments/](comments/Steps.md) | Fetch comments per post and extract JAV codes from them |
| 3 | [Full_video_fetch/](Full_video_fetch/Steps.md) | Scrape trailer URLs from javx / javgg / turbovid / javenglish |
| 4 | [ui/](ui/Steps.md) | Tkinter UI to review OCR results |
| — | [all_files/](all_files/Steps.md) | Legacy scripts; kept only for reference |

## End-to-end (from workspace root)

```bash
# 1. install
pip install -r requirements.txt
pip install -r Insta_Autom/aaii/requirements.txt

# 2. IG cookie (used by aaii + comments)
export IG_COOKIE='csrftoken=...; sessionid=...; ds_user_id=...'

# 3. fetch saved collection + parse
python -m Insta_Autom.aaii ig fetch --collection-id <ID> --out Insta_Autom/data.json
python -m Insta_Autom.aaii ig parse  --in Insta_Autom/data.json --out Insta_Autom/posts.json

# 4. OCR every media type
python -m Insta_Autom.aaii.ocr_image_post    --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_image_post.json --pattern "[A-Z]{2,5}-?\d{3,5}"
python -m Insta_Autom.aaii.ocr_carousel      --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_carousel.json --pattern "[A-Z]{2,5}-?\d{3,5}"
python -m Insta_Autom.aaii.ocr_video_or_reel --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_video_or_reel.json --frame-interval 90 --pattern "[A-Z]{2,5}-?\d{3,5}"

# 5. comments (needs IG cookie)
python Insta_Autom/comments/fetch_comments.py --posts Insta_Autom/posts.json --out Insta_Autom/comments/comments.json
python Insta_Autom/comments/extract_codes.py  --in Insta_Autom/comments/comments.json --out Insta_Autom/comments/codes_from_comments.json

# 6. review UI
python -m Insta_Autom.ui.review_ui
```

## Standalone

- `test1.py` — currently empty.
- `data.json`, `posts.json`, `ocr_results_*.json`, `ocr_review_state.json` — pipeline artifacts (regenerable).
- `listofsites` — reference file, not a script.
