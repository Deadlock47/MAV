# Insta_Autom/ui — Execution Steps

Tkinter UI to review Instagram OCR results across image posts, carousels, and videos/reels. Supports search / sort / filter and per-post reprocess.

## Files

| File | Purpose |
|------|---------|
| `review_ui.py` | The UI. Reads posts + OCR results + optional comment codes; runnable as a module. |
| `__init__.py` | Empty package marker. |

## Prerequisites

Generate the OCR inputs first:
```bash
python -m Insta_Autom.aaii ig fetch --collection-id <ID> --out Insta_Autom/data.json
python -m Insta_Autom.aaii ig parse --in Insta_Autom/data.json --out Insta_Autom/posts.json
python -m Insta_Autom.aaii.ocr_image_post    --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_image_post.json
python -m Insta_Autom.aaii.ocr_carousel      --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_carousel.json
python -m Insta_Autom.aaii.ocr_video_or_reel --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_video_or_reel.json
```

Optional — comment codes (see [../comments/Steps.md](../comments/Steps.md)):
```bash
python Insta_Autom/comments/fetch_comments.py --posts Insta_Autom/posts.json --out Insta_Autom/comments/comments.json
python Insta_Autom/comments/extract_codes.py  --in Insta_Autom/comments/comments.json --out Insta_Autom/comments/codes_from_comments.json
```

## Order (from workspace root)

### 1. Launch the UI
```bash
python -m Insta_Autom.ui.review_ui
```

### 2. Custom paths (all optional)
```bash
python -m Insta_Autom.ui.review_ui \
  --posts   Insta_Autom/posts.json \
  --ocr-video    Insta_Autom/ocr_results_video_or_reel.json \
  --ocr-carousel Insta_Autom/ocr_results_carousel.json \
  --ocr-image    Insta_Autom/ocr_results_image_post.json \
  --comments-codes Insta_Autom/comments/codes_from_comments.json \
  --state   Insta_Autom/ocr_review_state.json \
  --downloads-root Insta_Autom/downloads \
  --frames-root    Insta_Autom/frames \
  --frame-interval 30
```

Use `--help` to see the exact flag names your copy accepts.

## UI notes

- Three tabs: **Video / Reel**, **Carousel**, **Single Post**.
- Each card shows a thumbnail preview (Pillow), OCR codes, comment codes, and diff badges.
- "↻ Reprocess" re-runs OCR for a single post in a background thread.
