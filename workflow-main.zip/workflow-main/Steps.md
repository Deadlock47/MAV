# Workspace — Execution Order

Top-level map of every pipeline in this repo. Each folder has its own `Steps.md` with the exact commands; this file is the index.

All commands assume the **workspace root** (`workflow-main/`) is the current directory unless a folder's own `Steps.md` says otherwise.

## 0. One-time setup

```bash
pip install -r requirements.txt
cp .env.example database/.env      # then edit DB + Reddit + Instagram creds
python database/create_tables.py   # bootstrap Postgres schema
```

## 1. Pipelines (run each independently)

| Order | Folder | What it does | Entry point |
|-------|--------|--------------|-------------|
| A | [database/](database/Steps.md) | Create Postgres tables used by every other pipeline | `python database/create_tables.py` |
| B | [DataFetch/](DataFetch/Steps.md) | Download r18.dev SQL dumps → load into Postgres → export tables to Parquet | `python DataFetch/my_download_file.py` |
| C | [reddit_autom/reddit_comments/](reddit_autom/reddit_comments/Steps.md) | Scrape upvoted Reddit posts + comments, extract JAV codes, verify on r18.dev | `python -m reddit_autom.reddit_comments` |
| D | [reddit_autom/trailer_codes/](reddit_autom/trailer_codes/Steps.md) | Fetch trailer links for codes and sync to JSONBin | `python reddit_autom/trailer_codes/main.py` |
| E | [reddit_autom/ui/](reddit_autom/ui/Steps.md) | Tkinter UI to review Reddit codes and reprocess posts | `python -m reddit_autom.ui.review_ui` |
| F | [Insta_Autom/aaii/](Insta_Autom/aaii/Steps.md) | Instagram saved-collection fetch → post parse → OCR (image / carousel / video) | `python -m Insta_Autom.aaii ...` |
| G | [Insta_Autom/comments/](Insta_Autom/comments/Steps.md) | Instagram comment scrape + JAV code extraction | `python Insta_Autom/comments/fetch_comments.py` |
| H | [Insta_Autom/Full_video_fetch/](Insta_Autom/Full_video_fetch/Steps.md) | Ad-hoc trailer URL scrapers (javx, javgg, turbovid, javenglish) | see folder |
| I | [Insta_Autom/ui/](Insta_Autom/ui/Steps.md) | Tkinter UI to review Instagram OCR results | `python -m Insta_Autom.ui.review_ui` |

## 2. Recommended end-to-end order

If you're bringing the whole system up from scratch:

```bash
# 1. base infra
pip install -r requirements.txt
cp .env.example database/.env
python database/create_tables.py

# 2. reddit side
python -m reddit_autom.reddit_comments                 # s01..s07
python reddit_autom/trailer_codes/main.py              # trailer links
python -m reddit_autom.ui.review_ui                    # review

# 3. instagram side (needs IG_COOKIE env)
python -m Insta_Autom.aaii ig fetch --collection-id <id> --out Insta_Autom/data.json
python -m Insta_Autom.aaii ig parse  --in Insta_Autom/data.json --out Insta_Autom/posts.json
python -m Insta_Autom.aaii.ocr_image_post   --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_image_post.json
python -m Insta_Autom.aaii.ocr_carousel     --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_carousel.json
python -m Insta_Autom.aaii.ocr_video_or_reel --posts Insta_Autom/posts.json --out Insta_Autom/ocr_results_video_or_reel.json
python -m Insta_Autom.ui.review_ui                     # review

# 4. optional: reference dump ingest
python DataFetch/my_download_file.py                   # r18.dev dumps -> ./downloads
python DataFetch/load_sql_to_postgres.py               # load into Postgres
python DataFetch/extract_tables_to_parquet.py          # export to ./jvify/db
```
