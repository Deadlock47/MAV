# insta_autom — Execution Steps

## Sub-pipelines

| Order | Folder | Purpose |
|-------|--------|---------|
| 1 | [insta_saved/](insta_saved/Steps.md) | IG saved-collection fetch → post parse → OCR (image / carousel / video) |
| 2 | [comments/](comments/Steps.md) | Fetch comments per post and extract  from them |
| 4 | [ui/](ui/Steps.md) | Tkinter UI to review OCR results |
| 5 | [../database/manual_load/](../database/manual_load/Steps.md) | Load the JSON artifacts into Postgres |

## End-to-end (from workspace root)

```bash
# 1. install
pip install -r requirements.txt
pip install -r insta_autom/insta_saved/requirements.txt

# 2. IG cookie (used by insta_saved + comments)
export IG_COOKIE='csrftoken=...; sessionid=...; ds_user_id=...'

# 3. fetch saved collection + parse
python -m insta_autom.insta_saved ig fetch --collection-id <ID> --out insta_autom/data.json
python -m insta_autom.insta_saved ig parse  --in insta_autom/data.json --out insta_autom/posts.json

# 4. OCR every media type
python -m insta_autom.insta_saved.ocr_image_post    --posts insta_autom/posts.json --out insta_autom/ocr_results_image_post.json --pattern "[A-Z]{2,5}-?\d{3,5}"
python -m insta_autom.insta_saved.ocr_carousel      --posts insta_autom/posts.json --out insta_autom/ocr_results_carousel.json --pattern "[A-Z]{2,5}-?\d{3,5}"
python -m insta_autom.insta_saved.ocr_video_or_reel --posts insta_autom/posts.json --out insta_autom/ocr_results_video_or_reel.json --frame-interval 90 --pattern "[A-Z]{2,5}-?\d{3,5}"

# 5. comments (needs IG cookie)
python insta_autom/comments/fetch_comments.py --posts insta_autom/posts.json --out insta_autom/comments/comments.json
python insta_autom/comments/extract_codes.py  --in insta_autom/comments/comments.json --out insta_autom/comments/codes_from_comments.json

# 6. review UI
python -m insta_autom.ui.review_ui

# 7. load everything into Postgres (needs POSTGRES_* in database/.env)
python database/create_tables.py
python -m database.manual_load.insta_load \
  --posts insta_autom/posts.json \
  --comments insta_autom/comments/comments.json \
  --ocr insta_autom/ocr_results_image_post.json \
  --ocr insta_autom/ocr_results_carousel.json \
  --ocr insta_autom/ocr_results_video_or_reel.json \
  --comment-codes insta_autom/comments/codes_from_comments.json
```

## Postgres persistence

`database.manual_load.insta_load` drives `InstaRepository` and upserts into these tables:

| JSON artifact | Table(s) | Notes |
|---------------|----------|-------|
| `posts.json` | `insta_posts`, `insta_media` | Upsert on `insta_post_id`; media rows are wiped and re-inserted per post. |
| `comments/comments.json` | `insta_comments` | Comment tree flattened; upsert on `insta_comment_id`; each row runs in its own `SAVEPOINT`. |
| `ocr_results_*.json` | `insta_ocr_results` | `results` and `failures` both upsert on `insta_post_id`; `is_failure` distinguishes them. |
| `codes_from_comments.json` + `ocr_results_*.json` | `insta_posts.jav_codes` | Final pass writes OCR ∪ comment-derived codes per post. Skip with `--skip-code-merge`. |

