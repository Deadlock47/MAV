import requests
import json
from urllib.parse import quote


url = "https://www.instagram.com/api/v1/feed/collection/18025099568665354/posts/?max_id="
def get_url(param): 
    print(quote(param))
    return f'https://www.instagram.com/api/v1/feed/collection/18025099568665354/posts/?max_id={quote(param)}'

# YOUR_SESSION_ID = "59799985019:bsN9KijX1P5yRB:28:AYgsQ4xedjEFAr7ks01g7j-H9UcubPcEha-7B0bK-g"

# params = {
#     "query_hash": "2b0673e0dc4580674a88d426fe00ea90",
#     "variables": json.dumps({
#         "collection_id": "18025099568665354",
#         "first": 50
#     })
# }

headers = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "*/*",
    "X-IG-App-ID": "936619743392459",
    "Referer": "https://www.instagram.com/",
    "Cookie": ''
}


r = requests.get(url,headers=headers, allow_redirects=False)
data = r.json()
print(len(data['items']))
with open("data.json", "w") as file:
    json.dump(data['items'], file)
next_max = data['next_max_id']
while len(next_max)>0:
    try : 
        print(next_max)
        print(get_url(next_max))
        r = requests.get(get_url(next_max),headers=headers, allow_redirects=False)
        new_data = r.json()
        # print(data)
        print(len(new_data['items']))
        # read existing file
        with open("data.json", "r") as f:
            json_data = json.load(f)

        # append new object
        json_data = json_data+new_data['items']

        # write back
        with open("data.json", "w") as f:
            json.dump(json_data, f, indent=2)

        next_max = new_data['next_max_id']
        if new_data['next_max_id'] == "":
            break
    
    except : 
        next_max = ""
        print("Completed!!!")
# print("fetched data.....")
# print(len(data['items']))