from doctr.io import DocumentFile
from doctr.models import ocr_predictor
import re
# Load OCR model
model = ocr_predictor(pretrained=True)
def get_text_ocr(image_path):

    pattern = r"[A-Z]{2,5}-?\d{3,5}"

    codes = []
    # Load image
    doc = DocumentFile.from_images(f"{image_path}")

    # Run OCR
    result = model(doc)

    # Export result
    output = result.export()
    # codes = []
    # Print detected text
    for page in output["pages"]:
        for block in page["blocks"]:
            for line in block["lines"]:
                text = " ".join([word["value"] for word in line["words"]])
                matches = re.findall(pattern, text)
                codes.extend(matches)
                
    print(codes)
    return codes

__all__ = ['get_text_ocr']