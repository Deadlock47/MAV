import cv2
import requests
from finalized_ocr import get_text_ocr
import os

video_path = 'https://scontent-del2-1.cdninstagram.com/o1/v/t2/f2/m367/AQPOHOtG0m822Hl4ry4L1Nl5CMuFOW0CejmNdkI-vX8iwU4siJ1UivUpk_5ZxzeuCpQiSRfHsjyPEUKZ3T4h6t3fpJVCyNwueqTkIZc.mp4?_nc_cat=111&_nc_sid=5e9851&_nc_ht=scontent-del2-1.cdninstagram.com&_nc_ohc=w_Bb4sefpAUQ7kNvwFgxtt7&efg=eyJ2ZW5jb2RlX3RhZyI6Inhwdl9wcm9ncmVzc2l2ZS5JTlNUQUdSQU0uQ0xJUFMuQzMuNzE4LmRhc2hfYmFzZWxpbmVfMV92MSIsInhwdl9hc3NldF9pZCI6NTQ4NjgxNjA0OTUyMTY2LCJhc3NldF9hZ2VfZGF5cyI6MzA3LCJ2aV91c2VjYXNlX2lkIjoxMDA5OSwiZHVyYXRpb25fcyI6MTEsInVybGdlbl9zb3VyY2UiOiJ3d3cifQ%3D%3D&ccb=17-1&_nc_gid=2NcKkVzQeGynCf0Q2CoKJg&_nc_ss=8&_nc_zt=28&vs=f0c0198000f6237c&_nc_vs=HBksFQIYQGlnX2VwaGVtZXJhbC9BMDQ4RDg3N0NBMjgxNzQ2QzAwQ0VCQTYwNjEwQjE5Ql92aWRlb19kYXNoaW5pdC5tcDQVAALIARIAFQIYRmlnX3hwdl9yZWVsc19wZXJtYW5lbnRfc3JfcHJvZC82NjQ3MzY2NzMwMzgwMjBfNzYyNzQwNDkwNjk2MjE1MjIxMy5tcDQVAgLIARIAKAAYABsCiAd1c2Vfb2lsATEScHJvZ3Jlc3NpdmVfcmVjaXBlATEVAAAmzMHDwrzB-QEVAigCQzMsF0AnzMzMzMzNGBJkYXNoX2Jhc2VsaW5lXzFfdjERAHX-B2XmnQEA&oh=00_AfyjfsDza554RiiAXf8b2Oxuexcj2qTNG7TOFdOF8_w-tQ&oe=69BA3904'
def download_video(url, filename="video.mp4"):
    r = requests.get(url, stream=True)

    with open(filename, "wb") as f:
        for chunk in r.iter_content(1024):
            f.write(chunk)

    return filename

download_video(video_path)

import cv2
frame_interval = 30
def extract_frames(video_path):

    cap = cv2.VideoCapture(video_path)

    frame_paths = []
    count = 0
    frame_id = 0

    os.makedirs("frames", exist_ok=True)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_id % frame_interval == 0:
            path = f"frames/frame_{count}.jpg"
            cv2.imwrite(path, frame)
            frame_paths.append(path)
            count += 1

        frame_id += 1

    cap.release()
    return frame_paths

# def preprocess(frame):

#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

#     gray = cv2.convertScaleAbs(gray, alpha=1.0, beta=0)

#     thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)[1]

#     return thresh

# import pytesseract

# def run_ocr(img):

#     text = pytesseract.image_to_string(
#         img,
#         config="--psm 6"
#     )

#     return text

# import re

# def extract_code(text):

#     pattern = r"[A-Z]{2,5}-?\d{3,4}"

#     codes = re.findall(pattern, text)

#     return codes
def ocr_video(video_path):

    frames = extract_frames(video_path)

    all_codes = []

    for frame in frames:
        codes = get_text_ocr(frame)
        all_codes.extend(codes)

    print("Detected Codes:", list(set(all_codes)))

    return list(set(all_codes))

codes = ocr_video("video.mp4")

print(codes)