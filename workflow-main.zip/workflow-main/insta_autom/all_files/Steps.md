# all_files — Execution Steps

**Legacy** — pre-refactor Instagram scripts. Superseded by `../insta_saved/`. Kept only because the working data files (`data.json`, `posts.json`, `ocr_results_*.json`) live next to them.

Do **not** wire these into the current pipeline. Use `python -m insta_autom.insta_saved ...` instead.

## Files

| File | Legacy role | Modern replacement |
|------|-------------|--------------------|
| `inst_saved_autom.py` | Fetches saved-collection items into `data.json`. Hardcoded cookie. | `python -m insta_autom.insta_saved ig fetch` |
| `finalized_ocr.py` | `get_text_ocr(image_path)` using doctr. | `insta_autom.insta_saved.ocr_tools.extract_codes_from_image` |
| `test1.py` | Empty / scratch. | — |
| `test3.py` | Downloads a video and OCRs frames. | `python -m insta_autom.insta_saved video download` + `python -m insta_autom.insta_saved ocr video` |
| `data.json`, `posts.json`, `ocr_results_*.json`, `ocr_review_state.json` | Working artifacts (regenerable). | — |
| `f.txt`, `f (1).txt` | Scratch notes. | — |

## If you must run them (debug only)

From this folder (`insta_autom/all_files/`):

```bash
python inst_saved_autom.py     # writes data.json (uses hardcoded cookie — edit first)
python test3.py                # downloads + OCRs a video (edit URL at top)
```

## Recommendation

Migrate to `../insta_saved/` for anything new. See [../insta_saved/Steps.md](../insta_saved/Steps.md).
