import json

def parse_post(post):

    media_type_map = {
        1: "image_post",
        2: "video_or_reel",
        8: "carousel"
    }

    post_data = {
        "post_id": post["id"],
        "shortcode": post.get("code"),  # used in instagram URL
        "post_type": media_type_map.get(post["media_type"], "unknown"),
        "comment_count": post.get("comment_count", 0),
        "like_count": post.get("like_count", 0),
        "media": []
    }

    # SINGLE IMAGE
    if post["media_type"] == 1:
        img = post["image_versions2"]["candidates"][0]["url"]
        post_data["media"].append({
            "type": "image",
            "url": img
        })

    # VIDEO / REEL
    elif post["media_type"] == 2:
        vid = post["video_versions"][0]["url"]
        post_data["media"].append({
            "type": "video",
            "url": vid
        })

    # CAROUSEL
    elif post["media_type"] == 8:
        for item in post["carousel_media"]:

            if item["media_type"] == 1:
                url = item["image_versions2"]["candidates"][0]["url"]
                mtype = "image"
            else:
                url = item["video_versions"][0]["url"]
                mtype = "video"

            post_data["media"].append({
                "type": mtype,
                "url": url
            })

    return post_data
with open('data.json','r') as f:
    data = json.load(f)

ar = []
# info = parse_post(data[0]['media'])
# print(info)
it = 1
for item in data:
    media_type_map = {
        1: "image_post",
        2: "video_or_reel",
        8: "carousel"
    }
    print("="*30)
    print(it)
    it = it + 1
    # if item['media']['media_type'] == 1:
    #     print("post")
    # elif item['media']['media_type'] == 8:
    #     print("carousel")
    # else :
    #     print("reel/video")
    print(parse_post(item['media'])['post_type'])
    print("-"*20)
    # print(parse_post(item['media']))
    # with open("posts.json",'r') as f:
    #     ar = json.load(f)
    #     # print(len(ar))
    # with open("posts.json",'w') as f:
    #     d1 = parse_post(item['media'])
    #     ### 
    #     new_ar = ar.append(d1)
    #     # print(len(new_ar))
    #     json.dump(new_ar, f, indent=2)
    ar.append(parse_post(item['media']))
  
with open("posts.json",'w') as f:
   
    json.dump(ar, f, indent=2)     

print(len(data))