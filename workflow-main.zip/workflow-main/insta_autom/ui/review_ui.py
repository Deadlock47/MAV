"""Tkinter UI to review Insta OCR results with per-post reprocess."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal


# ---------------------------------------------------------------------------
# path bootstrap so insta_autom.insta_saved.* is importable when running as a script
# ---------------------------------------------------------------------------

_INSTA_ROOT = Path(__file__).resolve().parents[1]
_WORKSPACE_ROOT = _INSTA_ROOT.parent
if str(_WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(_WORKSPACE_ROOT))


# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------


PostType = Literal["video_or_reel", "carousel", "image_post"]

POST_TYPE_TABS: list[tuple[PostType, str]] = [
    ("video_or_reel", "Video / Reel"),
    ("carousel", "Carousel"),
    ("image_post", "Single Post"),
]

PALETTE = {
    "bg": "#fafafa",
    "card_bg": "#ffffff",
    "reviewed_bg": "#e7f5ea",
    "reviewed_border": "#2e7d32",
    "normal_border": "#dadce0",
    "failure_border": "#c62828",
    "subtle": "#5f6368",
    "diff_ok": "#137333",
    "diff_warn": "#b06000",
    "reviewed_badge_bg": "#c8e6c9",
    "reviewed_badge_fg": "#1b5e20",
    "failure_badge_bg": "#ffebee",
    "failure_badge_fg": "#b71c1c",
}

SORT_OPTIONS: list[tuple[str, str]] = [
    ("Post type → shortcode", "type"),
    ("Shortcode", "shortcode"),
    ("Title", "title"),
    ("Code count (many → few)", "count"),
]


def _repo_root() -> Path:
    return _INSTA_ROOT


# ---------------------------------------------------------------------------
# data model
# ---------------------------------------------------------------------------


@dataclass
class ReviewItem:
    key: str
    post_type: PostType
    post_id: str | None
    shortcode: str | None
    codes: list[str]
    comment_codes: list[str]
    title: str
    actions: list[tuple[str, str, Literal["path", "url"]]] = field(default_factory=list)
    details: str | None = None
    is_failure: bool = False


# ---------------------------------------------------------------------------
# io helpers
# ---------------------------------------------------------------------------


def _read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any, *, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=indent, ensure_ascii=False), encoding="utf-8")


def _safe_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _safe_str_list(value: Any) -> list[str]:
    return [item for item in _safe_list(value) if isinstance(item, str)]


def _key_for(post_type: str, post_id: Any, shortcode: Any) -> str:
    ident = str(shortcode or post_id or "").strip()
    if not ident:
        ident = f"unknown_{datetime.now(timezone.utc).timestamp()}"
    return f"{post_type}:{ident}"


def _ig_url(shortcode: str | None) -> str | None:
    if not shortcode:
        return None
    return f"https://www.instagram.com/p/{shortcode}/"


# ---------------------------------------------------------------------------
# comments codes overlay
# ---------------------------------------------------------------------------


def _load_comments_codes(
    path: Path,
) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    raw = _read_json(path, default=None)
    if not isinstance(raw, list):
        return {}, {}

    by_shortcode: dict[str, list[str]] = {}
    by_post_id: dict[str, list[str]] = {}
    for item in raw:
        if not isinstance(item, dict):
            continue
        codes_val = item.get("code") if item.get("code") is not None else item.get("codes")
        codes = _safe_str_list(codes_val)
        shortcode = item.get("shortcode")
        if isinstance(shortcode, str) and shortcode.strip():
            by_shortcode[shortcode.strip()] = list(codes)
        post_id = item.get("post_id")
        if post_id is not None and str(post_id).strip():
            by_post_id[str(post_id).strip()] = list(codes)
    return by_shortcode, by_post_id


# ---------------------------------------------------------------------------
# item building from OCR result dicts
# ---------------------------------------------------------------------------


def _build_item_from_result(
    result: dict[str, Any],
    *,
    post_type: PostType,
    comment_codes_by_shortcode: dict[str, list[str]],
    comment_codes_by_post_id: dict[str, list[str]],
    is_failure: bool = False,
) -> ReviewItem:
    post_id = result.get("post_id")
    post_id_s = str(post_id) if post_id is not None else None
    shortcode = result.get("shortcode")
    shortcode_s = str(shortcode) if shortcode is not None else None

    codes = _safe_str_list(result.get("codes"))
    comment_codes: list[str] = []
    if shortcode_s and shortcode_s in comment_codes_by_shortcode:
        comment_codes = list(comment_codes_by_shortcode[shortcode_s])
    elif post_id_s and post_id_s in comment_codes_by_post_id:
        comment_codes = list(comment_codes_by_post_id[post_id_s])

    key = _key_for(post_type, post_id_s, shortcode_s)
    title_prefix = f"{post_type} (FAILED)" if is_failure else post_type
    title = f"{title_prefix} | {shortcode_s or ''} | {post_id_s or ''}".strip(" |")

    actions: list[tuple[str, str, Literal["path", "url"]]] = []
    details: str | None = None

    if not is_failure:
        if post_type == "image_post":
            image_path = result.get("image_path")
            if isinstance(image_path, str) and image_path:
                actions.append(("Open image", image_path, "path"))
        elif post_type == "carousel":
            image_results = _safe_list(result.get("image_results"))
            image_paths: list[str] = []
            detail_lines: list[str] = []
            for img in image_results:
                if not isinstance(img, dict):
                    continue
                img_path = img.get("image_path")
                if isinstance(img_path, str) and img_path:
                    image_paths.append(img_path)
                img_codes = _safe_str_list(img.get("codes"))
                label = Path(img_path).name if isinstance(img_path, str) and img_path else f"image_{img.get('index')}"
                detail_lines.append(f"{label}: {', '.join(img_codes) if img_codes else '<none>'}")
            if image_paths:
                actions.append(("Open folder", str(Path(image_paths[0]).parent), "path"))
                actions.append(("Open first image", image_paths[0], "path"))
            details = "\n".join(detail_lines) if detail_lines else None
        elif post_type == "video_or_reel":
            video_path = result.get("video_path")
            frames_dir = result.get("frames_dir")
            if isinstance(video_path, str) and video_path:
                actions.append(("Open video", video_path, "path"))
            if isinstance(frames_dir, str) and frames_dir:
                actions.append(("Open frames", frames_dir, "path"))
    else:
        error = result.get("error")
        details = f"Error: {error}" if error else "Error: <unknown>"

    ig = _ig_url(shortcode_s)
    if ig:
        actions.append(("Open IG", ig, "url"))

    return ReviewItem(
        key=key,
        post_type=post_type,
        post_id=post_id_s,
        shortcode=shortcode_s,
        codes=codes if not is_failure else [],
        comment_codes=comment_codes,
        title=title,
        actions=actions,
        details=details,
        is_failure=is_failure,
    )


def _build_items_from_payload(
    payload: dict[str, Any],
    *,
    post_type: PostType,
    comment_codes_by_shortcode: dict[str, list[str]] | None = None,
    comment_codes_by_post_id: dict[str, list[str]] | None = None,
) -> list[ReviewItem]:
    comment_codes_by_shortcode = comment_codes_by_shortcode or {}
    comment_codes_by_post_id = comment_codes_by_post_id or {}
    items: list[ReviewItem] = []
    for result in _safe_list(payload.get("results")):
        if not isinstance(result, dict):
            continue
        items.append(
            _build_item_from_result(
                result,
                post_type=post_type,
                comment_codes_by_shortcode=comment_codes_by_shortcode,
                comment_codes_by_post_id=comment_codes_by_post_id,
                is_failure=False,
            )
        )
    for failure in _safe_list(payload.get("failures")):
        if not isinstance(failure, dict):
            continue
        items.append(
            _build_item_from_result(
                failure,
                post_type=post_type,
                comment_codes_by_shortcode=comment_codes_by_shortcode,
                comment_codes_by_post_id=comment_codes_by_post_id,
                is_failure=True,
            )
        )
    return items


# ---------------------------------------------------------------------------
# review state
# ---------------------------------------------------------------------------


def _load_review_state(path: Path) -> set[str]:
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return set()
    keys = data.get("reviewed_keys")
    if not isinstance(keys, list):
        return set()
    return {key.strip() for key in keys if isinstance(key, str) and key.strip()}


def _save_review_state(path: Path, keys: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "reviewed_keys": sorted(keys),
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# reprocess: re-run OCR for one post and update the matching ocr_results_*.json
# ---------------------------------------------------------------------------


def _find_post_in_posts_json(posts: list[Any], item: ReviewItem) -> dict[str, Any] | None:
    for post in posts:
        if not isinstance(post, dict):
            continue
        if item.shortcode and str(post.get("shortcode") or "") == item.shortcode:
            return post
        if item.post_id and str(post.get("post_id") or "") == item.post_id:
            return post
    return None


def _reprocess_insta_post(
    item: ReviewItem,
    *,
    posts_path: Path,
    ocr_results_paths: dict[PostType, Path],
    downloads_root: Path,
    frames_root: Path,
    frame_interval: int,
    comment_codes_by_shortcode: dict[str, list[str]],
    comment_codes_by_post_id: dict[str, list[str]],
) -> ReviewItem:
    posts = _read_json(posts_path, default=None)
    if not isinstance(posts, list):
        raise RuntimeError(f"posts.json must be a JSON list at {posts_path}")
    match = _find_post_in_posts_json(posts, item)
    if match is None:
        raise RuntimeError(
            f"Post not found in posts.json: shortcode={item.shortcode} post_id={item.post_id}"
        )

    if item.post_type == "image_post":
        from insta_autom.insta_saved.ocr_image_post import ocr_image_post
        result = ocr_image_post(match, downloads_dir=downloads_root / "image_post")
    elif item.post_type == "carousel":
        from insta_autom.insta_saved.ocr_carousel import ocr_carousel_post_images
        result = ocr_carousel_post_images(match, downloads_dir=downloads_root / "carousel")
    elif item.post_type == "video_or_reel":
        from insta_autom.insta_saved.ocr_video_or_reel import ocr_video_or_reel_post
        result = ocr_video_or_reel_post(
            match,
            downloads_dir=downloads_root / "video_or_reel",
            frames_root_dir=frames_root / "video_or_reel",
            frame_interval=frame_interval,
        )
    else:
        raise RuntimeError(f"Unknown post_type: {item.post_type}")

    target = ocr_results_paths[item.post_type]
    payload = _read_json(target, default={}) or {}
    if not isinstance(payload, dict):
        payload = {}
    results = list(_safe_list(payload.get("results")))
    failures = list(_safe_list(payload.get("failures")))
    my_key = str(item.shortcode or item.post_id or "")

    def _entry_key(entry: Any) -> str:
        if not isinstance(entry, dict):
            return ""
        return str(entry.get("shortcode") or entry.get("post_id") or "")

    results = [r for r in results if _entry_key(r) != my_key]
    failures = [f for f in failures if _entry_key(f) != my_key]
    results.append(result)
    payload["post_type"] = item.post_type
    payload["results"] = results
    payload["failures"] = failures
    payload["total"] = len(results) + len(failures)
    payload["processed"] = len(results)
    payload["failed"] = len(failures)
    _write_json(target, payload)

    return _build_item_from_result(
        result,
        post_type=item.post_type,
        comment_codes_by_shortcode=comment_codes_by_shortcode,
        comment_codes_by_post_id=comment_codes_by_post_id,
        is_failure=False,
    )


# ---------------------------------------------------------------------------
# path opener (cross-platform)
# ---------------------------------------------------------------------------


def _open_path(path: Path) -> None:
    if sys.platform == "darwin":
        subprocess.run(["open", str(path)], check=False)
    elif sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    else:
        subprocess.run(["xdg-open", str(path)], check=False)


# ---------------------------------------------------------------------------
# scrollable frame
# ---------------------------------------------------------------------------


class ScrollableFrame:
    def __init__(self, parent, *, bg: str) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.container = ttk.Frame(parent)
        self.canvas = tk.Canvas(self.container, highlightthickness=0, bg=bg)
        self.v_scroll = ttk.Scrollbar(self.container, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)

        self.inner_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.v_scroll.set)

        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        for widget in (self.canvas, self.inner):
            widget.bind("<MouseWheel>", self._on_mousewheel)
            widget.bind("<Button-4>", self._on_mousewheel_linux)
            widget.bind("<Button-5>", self._on_mousewheel_linux)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.v_scroll.pack(side="right", fill="y")

    def _on_inner_configure(self, _event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self.inner_id, width=event.width)

    def _on_mousewheel(self, event):
        delta = event.delta
        if not delta:
            return
        step = -1 if delta > 0 else 1
        if abs(delta) >= 120:
            step = int(-1 * (delta / 120))
        self.canvas.yview_scroll(step, "units")

    def _on_mousewheel_linux(self, event):
        self.canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

    def pack(self, **kwargs):
        return self.container.pack(**kwargs)

    def clear(self) -> None:
        for child in list(self.inner.winfo_children()):
            child.destroy()


# ---------------------------------------------------------------------------
# review UI
# ---------------------------------------------------------------------------


class ReviewUI:
    def __init__(
        self,
        *,
        items: list[ReviewItem],
        state_path: Path,
        posts_path: Path,
        ocr_results_paths: dict[PostType, Path],
        downloads_root: Path,
        frames_root: Path,
        frame_interval: int,
        comment_codes_by_shortcode: dict[str, list[str]],
        comment_codes_by_post_id: dict[str, list[str]],
        title: str = "OCR + Comments review",
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry("1200x840")
        self.root.configure(bg=PALETTE["bg"])

        self.state_path = state_path
        self.posts_path = posts_path
        self.ocr_results_paths = ocr_results_paths
        self.downloads_root = downloads_root
        self.frames_root = frames_root
        self.frame_interval = frame_interval
        self.comment_codes_by_shortcode = comment_codes_by_shortcode
        self.comment_codes_by_post_id = comment_codes_by_post_id

        self.reviewed = _load_review_state(self.state_path)
        self.items: list[ReviewItem] = list(items)
        self._reprocessing: set[str] = set()

        self._apply_theme()

        self.search_var = tk.StringVar()
        self.show_reviewed_var = tk.BooleanVar(value=True)
        self.sort_var = tk.StringVar(value=SORT_OPTIONS[0][0])
        self.status_var = tk.StringVar()
        self.busy_var = tk.StringVar()

        self._build_toolbar()
        self._build_notebook()
        self._refresh_all()

    def run(self) -> None:
        self.root.mainloop()

    # -- theme + layout ------------------------------------------------------

    def _apply_theme(self) -> None:
        from tkinter import ttk

        style = ttk.Style()
        for theme in ("clam", "alt", "default"):
            try:
                style.theme_use(theme)
                break
            except Exception:
                continue
        style.configure("TFrame", background=PALETTE["bg"])
        style.configure("TLabel", background=PALETTE["bg"])
        style.configure("Toolbar.TFrame", background=PALETTE["bg"])
        style.configure("Status.TLabel", background=PALETTE["bg"], foreground=PALETTE["subtle"])
        style.configure("Busy.TLabel", background=PALETTE["bg"], foreground=PALETTE["diff_warn"])
        style.configure("TNotebook", background=PALETTE["bg"])
        style.configure("TNotebook.Tab", padding=(14, 6))
        style.configure("TButton", padding=(10, 4))

    def _build_toolbar(self) -> None:
        import tkinter as tk
        from tkinter import ttk

        top = ttk.Frame(self.root, style="Toolbar.TFrame")
        top.pack(fill="x", padx=12, pady=(10, 4))

        tk.Label(top, text="Search:", bg=PALETTE["bg"], fg=PALETTE["subtle"]).pack(side="left")
        entry = ttk.Entry(top, textvariable=self.search_var, width=42)
        entry.pack(side="left", padx=(6, 12))
        self.search_var.trace_add("write", lambda *_: self._refresh_all())

        ttk.Checkbutton(
            top,
            text="Show reviewed",
            variable=self.show_reviewed_var,
            command=self._refresh_all,
        ).pack(side="left", padx=(0, 12))

        tk.Label(top, text="Sort:", bg=PALETTE["bg"], fg=PALETTE["subtle"]).pack(side="left")
        sort_combo = ttk.Combobox(
            top,
            values=[label for label, _ in SORT_OPTIONS],
            textvariable=self.sort_var,
            state="readonly",
            width=24,
        )
        sort_combo.pack(side="left", padx=(6, 12))
        sort_combo.bind("<<ComboboxSelected>>", lambda _e: self._refresh_all())

        ttk.Button(top, text="Reset reviewed", command=self._reset_reviewed).pack(side="right")

        status = ttk.Frame(self.root, style="Toolbar.TFrame")
        status.pack(fill="x", padx=12, pady=(0, 8))
        ttk.Label(status, textvariable=self.status_var, style="Status.TLabel").pack(side="left")
        ttk.Label(status, textvariable=self.busy_var, style="Busy.TLabel").pack(side="right")

    def _build_notebook(self) -> None:
        from tkinter import ttk

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.tabs: dict[PostType, tuple[ttk.Frame, ScrollableFrame]] = {}
        for post_type, label in POST_TYPE_TABS:
            tab = ttk.Frame(self.notebook)
            sf = ScrollableFrame(tab, bg=PALETTE["bg"])
            sf.pack(fill="both", expand=True)
            self.tabs[post_type] = (tab, sf)
            self.notebook.add(tab, text=label)

    # -- sorting / grouping --------------------------------------------------

    def _sorted_items(self) -> list[ReviewItem]:
        key = dict(SORT_OPTIONS).get(self.sort_var.get(), "type")
        if key == "shortcode":
            return sorted(self.items, key=lambda i: (i.shortcode or ""))
        if key == "title":
            return sorted(self.items, key=lambda i: (i.title or "").lower())
        if key == "count":
            return sorted(self.items, key=lambda i: (-(len(i.codes) + len(i.comment_codes)), i.shortcode or ""))
        return sorted(self.items, key=lambda i: (i.post_type, i.shortcode or ""))

    def _group_by_type(self) -> dict[PostType, list[ReviewItem]]:
        groups: dict[PostType, list[ReviewItem]] = {pt: [] for pt, _ in POST_TYPE_TABS}
        for item in self._sorted_items():
            groups[item.post_type].append(item)
        return groups

    def _matches_search(self, item: ReviewItem, query: str) -> bool:
        if not query:
            return True
        query = query.lower()
        parts = [
            item.title or "",
            item.shortcode or "",
            item.post_id or "",
            " ".join(item.codes),
            " ".join(item.comment_codes),
        ]
        return any(query in part.lower() for part in parts)

    # -- refresh -------------------------------------------------------------

    def _refresh_all(self) -> None:
        groups = self._group_by_type()
        query = self.search_var.get().strip()
        show_reviewed = bool(self.show_reviewed_var.get())

        for idx, (post_type, label) in enumerate(POST_TYPE_TABS):
            tab, sf = self.tabs[post_type]
            sf.clear()
            items_in_tab = groups[post_type]
            visible = self._render_list(sf, items_in_tab, query=query, show_reviewed=show_reviewed)
            reviewed = sum(1 for i in items_in_tab if i.key in self.reviewed)
            total = len(items_in_tab)
            title = f"{label} ({visible}/{total})"
            if reviewed:
                title += f"  ✓{reviewed}"
            self.notebook.tab(idx, text=title)
            tab.update_idletasks()
        self._update_status()

    def _update_status(self) -> None:
        total = len(self.items)
        reviewed = sum(1 for item in self.items if item.key in self.reviewed)
        remaining = total - reviewed
        self.status_var.set(
            f"Remaining: {remaining}  ·  Reviewed: {reviewed}  ·  Total: {total}  ·  State: {self.state_path}"
        )

    # -- state ---------------------------------------------------------------

    def _reset_reviewed(self) -> None:
        from tkinter import messagebox

        if not self.reviewed:
            return
        if not messagebox.askyesno(
            "Reset reviewed", "Clear all reviewed items? Cards stay visible; green tint is removed."
        ):
            return
        self.reviewed = set()
        try:
            _save_review_state(self.state_path, self.reviewed)
        except Exception as error:
            messagebox.showerror("Error", f"Failed to write state file:\n{error}")
            return
        self._refresh_all()

    def _persist_review_state(self) -> None:
        from tkinter import messagebox

        try:
            _save_review_state(self.state_path, self.reviewed)
        except Exception as error:
            messagebox.showerror("Error", f"Failed to write state file:\n{error}")

    # -- rendering -----------------------------------------------------------

    def _render_list(
        self,
        sf: ScrollableFrame,
        items: list[ReviewItem],
        *,
        query: str,
        show_reviewed: bool,
    ) -> int:
        visible = 0
        for item in items:
            is_reviewed = item.key in self.reviewed
            if is_reviewed and not show_reviewed:
                continue
            if not self._matches_search(item, query):
                continue
            self._render_card(sf, item, is_reviewed)
            visible += 1
        return visible

    def _render_card(self, sf: ScrollableFrame, item: ReviewItem, is_reviewed: bool) -> None:
        import tkinter as tk
        from tkinter import ttk

        card_bg = PALETTE["reviewed_bg"] if is_reviewed else PALETTE["card_bg"]
        if is_reviewed:
            border = PALETTE["reviewed_border"]
        elif item.is_failure:
            border = PALETTE["failure_border"]
        else:
            border = PALETTE["normal_border"]

        card = tk.Frame(
            sf.inner,
            bg=card_bg,
            highlightbackground=border,
            highlightthickness=2,
            padx=12,
            pady=10,
        )
        card.pack(fill="x", expand=True, padx=6, pady=6)

        content = tk.Frame(card, bg=card_bg)
        content.pack(fill="x", expand=True)

        preview = tk.Label(content, bg=card_bg)
        preview.pack(side="left", padx=(0, 12), anchor="n")
        photo = self._build_preview_photo(item)
        if photo is not None:
            preview.configure(image=photo)
            preview.image = photo  # type: ignore[attr-defined]
        else:
            preview.configure(text="(no preview)", justify="center", fg=PALETTE["subtle"])

        right = tk.Frame(content, bg=card_bg)
        right.pack(side="left", fill="both", expand=True)

        header = tk.Frame(right, bg=card_bg)
        header.pack(fill="x", expand=True)
        tk.Label(
            header,
            text=item.title,
            font=("TkDefaultFont", 11, "bold"),
            bg=card_bg,
            fg="#202124",
            anchor="w",
            wraplength=880,
            justify="left",
        ).pack(side="left", fill="x", expand=True)

        if is_reviewed:
            pill_bg = PALETTE["reviewed_badge_bg"]
            pill_fg = PALETTE["reviewed_badge_fg"]
            pill_text = "✓ Reviewed"
        elif item.is_failure:
            pill_bg = PALETTE["failure_badge_bg"]
            pill_fg = PALETTE["failure_badge_fg"]
            pill_text = "Failure"
        else:
            pill_bg = "#f1f3f4"
            pill_fg = PALETTE["subtle"]
            pill_text = item.post_type.replace("_", " ").title()

        tk.Label(
            header,
            text=f"  {pill_text}  ",
            bg=pill_bg,
            fg=pill_fg,
            font=("TkDefaultFont", 9, "bold"),
            padx=6,
            pady=2,
        ).pack(side="right")

        actions = tk.Frame(right, bg=card_bg)
        actions.pack(fill="x", pady=(8, 0))
        for label, target, kind in item.actions:
            ttk.Button(
                actions,
                text=label,
                command=lambda t=target, k=kind: self._open_target(t, k),
            ).pack(side="left", padx=(0, 6))

        tk.Label(
            right,
            text=f"Codes: {self._join_codes(item.codes)}",
            bg=card_bg,
            anchor="w",
            wraplength=880,
            justify="left",
        ).pack(fill="x", pady=(8, 0))

        comments_box = tk.LabelFrame(right, text="Comments codes", bg=card_bg, fg="#202124", padx=8, pady=4)
        comments_box.pack(fill="x", pady=(6, 0))
        tk.Label(
            comments_box,
            text=self._join_codes(item.comment_codes),
            bg=card_bg,
            anchor="w",
            wraplength=860,
            justify="left",
        ).pack(fill="x", pady=(2, 0))

        if item.codes or item.comment_codes:
            ocr_set = set(item.codes)
            comment_set = set(item.comment_codes)
            ocr_only = [c for c in item.codes if c not in comment_set]
            comments_only = [c for c in item.comment_codes if c not in ocr_set]
            if ocr_only or comments_only:
                parts: list[str] = []
                if ocr_only:
                    parts.append(f"OCR only: {', '.join(ocr_only)}")
                if comments_only:
                    parts.append(f"Comments only: {', '.join(comments_only)}")
                tk.Label(
                    comments_box,
                    text="  ·  ".join(parts),
                    bg=card_bg,
                    fg=PALETTE["diff_warn"],
                    anchor="w",
                    wraplength=860,
                    justify="left",
                ).pack(fill="x", pady=(2, 0))
            else:
                tk.Label(
                    comments_box,
                    text="Match: OCR and comments codes are the same.",
                    bg=card_bg,
                    fg=PALETTE["diff_ok"],
                    anchor="w",
                    wraplength=860,
                    justify="left",
                ).pack(fill="x", pady=(2, 0))

        if item.details:
            tk.Label(
                right,
                text=item.details,
                bg=card_bg,
                anchor="w",
                wraplength=880,
                justify="left",
                fg=PALETTE["subtle"],
            ).pack(fill="x", pady=(8, 0))

        footer = tk.Frame(right, bg=card_bg)
        footer.pack(fill="x", pady=(10, 0))

        checked_var = tk.BooleanVar(value=is_reviewed)
        ttk.Checkbutton(
            footer,
            text="Reviewed",
            variable=checked_var,
            command=lambda it=item, v=checked_var: self._on_check_toggle(it, v),
        ).pack(side="left")

        is_busy = item.key in self._reprocessing
        reprocess_btn = ttk.Button(
            footer,
            text="⟳ Reprocessing…" if is_busy else "↻ Reprocess",
            command=lambda it=item: self._on_reprocess(it),
        )
        if is_busy:
            reprocess_btn.state(["disabled"])
        reprocess_btn.pack(side="left", padx=(10, 0))

        all_codes = list(dict.fromkeys(item.codes + item.comment_codes))
        ttk.Button(
            footer,
            text="Copy OCR",
            command=lambda c=list(item.codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(10, 0))
        ttk.Button(
            footer,
            text="Copy comments",
            command=lambda c=list(item.comment_codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(6, 0))
        ttk.Button(
            footer,
            text="Copy all",
            command=lambda c=list(all_codes): self._copy_to_clipboard("\n".join(c)),
        ).pack(side="left", padx=(6, 0))

    def _join_codes(self, codes: list[str]) -> str:
        return ", ".join(codes) if codes else "<none>"

    def _build_preview_photo(self, item: ReviewItem):
        path = self._preview_path_for(item)
        if path is None or not path.exists():
            return None
        try:
            from PIL import Image, ImageTk  # type: ignore
        except Exception:
            return None
        try:
            with Image.open(path) as img:
                img = img.convert("RGB")
                img.thumbnail((220, 220))
                return ImageTk.PhotoImage(img.copy())
        except Exception:
            return None

    def _preview_path_for(self, item: ReviewItem) -> Path | None:
        def first_path_action(label: str) -> Path | None:
            for action_label, target, kind in item.actions:
                if action_label == label and kind == "path" and target:
                    return Path(target)
            return None

        if item.post_type == "image_post":
            return first_path_action("Open image")
        if item.post_type == "carousel":
            return first_path_action("Open first image")
        if item.post_type == "video_or_reel":
            frames_dir = first_path_action("Open frames")
            if frames_dir and frames_dir.exists():
                frames = sorted(frames_dir.glob("*.jpg"))
                if frames:
                    return frames[0]
        return None

    # -- event handlers ------------------------------------------------------

    def _on_check_toggle(self, item: ReviewItem, var) -> None:
        if bool(var.get()):
            self.reviewed.add(item.key)
        else:
            self.reviewed.discard(item.key)
        self._persist_review_state()
        self._refresh_all()

    def _on_reprocess(self, item: ReviewItem) -> None:
        if item.key in self._reprocessing:
            return
        self._reprocessing.add(item.key)
        self.busy_var.set(f"Reprocessing {item.shortcode or item.post_id}… (downloads + OCR)")
        self._refresh_all()

        def worker() -> None:
            try:
                new_item = _reprocess_insta_post(
                    item,
                    posts_path=self.posts_path,
                    ocr_results_paths=self.ocr_results_paths,
                    downloads_root=self.downloads_root,
                    frames_root=self.frames_root,
                    frame_interval=self.frame_interval,
                    comment_codes_by_shortcode=self.comment_codes_by_shortcode,
                    comment_codes_by_post_id=self.comment_codes_by_post_id,
                )
            except Exception as error:
                self.root.after(0, lambda err=error: self._on_reprocess_failed(item, err))
                return
            self.root.after(0, lambda ni=new_item: self._on_reprocess_done(item, ni))

        threading.Thread(target=worker, daemon=True).start()

    def _on_reprocess_done(self, old: ReviewItem, new_item: ReviewItem) -> None:
        self._reprocessing.discard(old.key)
        for idx, existing in enumerate(self.items):
            if existing.key == old.key:
                self.items[idx] = new_item
                break
        else:
            self.items.append(new_item)
        if old.key != new_item.key and old.key in self.reviewed:
            self.reviewed.discard(old.key)
            self.reviewed.add(new_item.key)
            self._persist_review_state()
        self.busy_var.set(
            f"Reprocessed {new_item.shortcode or new_item.post_id}: {len(new_item.codes)} codes."
        )
        self.root.after(2500, lambda: self.busy_var.set(""))
        self._refresh_all()

    def _on_reprocess_failed(self, item: ReviewItem, error: Exception) -> None:
        from tkinter import messagebox

        self._reprocessing.discard(item.key)
        self.busy_var.set("")
        self._refresh_all()
        messagebox.showerror("Reprocess failed", f"{item.shortcode or item.post_id}: {error}")

    def _copy_to_clipboard(self, text: str) -> None:
        from tkinter import messagebox

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update_idletasks()
        except Exception as error:
            messagebox.showerror("Error", f"Failed to copy to clipboard:\n{error}")

    def _open_target(self, target: str, kind: Literal["path", "url"]) -> None:
        from tkinter import messagebox

        try:
            if kind == "url":
                webbrowser.open(target)
                return
            path = Path(target)
            if not path.exists():
                messagebox.showerror("Missing", f"Not found:\n{path}")
                return
            _open_path(path)
        except Exception as error:
            messagebox.showerror("Error", str(error))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    root = _repo_root()
    parser = argparse.ArgumentParser(
        prog="python ui/review_ui.py",
        description="Review OCR results + comment codes and reprocess posts on demand.",
    )
    parser.add_argument("--video-json", default=str(root / "ocr_results_video_or_reel.json"),
                        help="Path to ocr_results_video_or_reel.json")
    parser.add_argument("--carousel-json", default=str(root / "ocr_results_carousel.json"),
                        help="Path to ocr_results_carousel.json")
    parser.add_argument("--image-json", default=str(root / "ocr_results_image_post.json"),
                        help="Path to ocr_results_image_post.json")
    parser.add_argument("--posts", default=str(root / "posts.json"),
                        help="Path to posts.json (needed for reprocess to look up the original post)")
    parser.add_argument("--comments-codes", default=str(root / "comments" / "codes_from_comments.json"),
                        help="Path to comments codes JSON")
    parser.add_argument("--state", default=str(root / "ocr_review_state.json"),
                        help="Path to review state JSON")
    parser.add_argument("--downloads-root", default=str(root / "downloads"),
                        help="Where reprocess should store downloads")
    parser.add_argument("--frames-root", default=str(root / "frames"),
                        help="Where reprocess should store extracted video frames")
    parser.add_argument("--frame-interval", type=int, default=30,
                        help="Frame interval passed to reprocess of video posts")
    parser.add_argument("--summary", action="store_true", help="Print counts and exit")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    comment_codes_by_shortcode, comment_codes_by_post_id = _load_comments_codes(Path(args.comments_codes))

    items: list[ReviewItem] = []
    ocr_results_paths: dict[PostType, Path] = {
        "video_or_reel": Path(args.video_json),
        "carousel": Path(args.carousel_json),
        "image_post": Path(args.image_json),
    }

    for post_type, path in ocr_results_paths.items():
        if not path.exists():
            continue
        payload = _read_json(path, default={}) or {}
        if not isinstance(payload, dict):
            continue
        items.extend(
            _build_items_from_payload(
                payload,
                post_type=post_type,
                comment_codes_by_shortcode=comment_codes_by_shortcode,
                comment_codes_by_post_id=comment_codes_by_post_id,
            )
        )

    if not items:
        raise SystemExit("No OCR result JSON files found. Run the OCR scripts first.")

    if args.summary:
        counts: dict[str, int] = {"video_or_reel": 0, "carousel": 0, "image_post": 0}
        failures = 0
        with_comment_codes = 0
        for item in items:
            counts[item.post_type] += 1
            if item.is_failure:
                failures += 1
            if item.comment_codes:
                with_comment_codes += 1
        print(
            json.dumps(
                {
                    "total": len(items),
                    "counts": counts,
                    "failures": failures,
                    "with_comment_codes": with_comment_codes,
                },
                indent=2,
            )
        )
        return 0

    ui = ReviewUI(
        items=items,
        state_path=Path(args.state),
        posts_path=Path(args.posts),
        ocr_results_paths=ocr_results_paths,
        downloads_root=Path(args.downloads_root),
        frames_root=Path(args.frames_root),
        frame_interval=args.frame_interval,
        comment_codes_by_shortcode=comment_codes_by_shortcode,
        comment_codes_by_post_id=comment_codes_by_post_id,
        title="OCR + Comments review",
    )
    ui.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
