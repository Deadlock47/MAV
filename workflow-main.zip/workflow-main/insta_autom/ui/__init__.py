"""UI helpers for reviewing extracted codes."""

