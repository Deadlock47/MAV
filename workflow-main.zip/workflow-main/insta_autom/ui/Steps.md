# insta_autom/ui — Execution Steps

Tkinter UI to review Instagram OCR results across image posts, carousels, and videos/reels. Supports search / sort / filter and per-post reprocess.

## Files

| File | Purpose |
|------|---------|
| `review_ui.py` | The UI. Reads posts + OCR results + optional comment codes; runnable as a module. |
| `__init__.py` | Empty package marker. |

## Prerequisites

Generate the OCR inputs first:
```bash
python -m insta_autom.insta_saved ig fetch --collection-id <ID> --out insta_autom/data.json
python -m insta_autom.insta_saved ig parse --in insta_autom/data.json --out insta_autom/posts.json
python -m insta_autom.insta_saved.ocr_image_post    --posts insta_autom/posts.json --out insta_autom/ocr_results_image_post.json
python -m insta_autom.insta_saved.ocr_carousel      --posts insta_autom/posts.json --out insta_autom/ocr_results_carousel.json
python -m insta_autom.insta_saved.ocr_video_or_reel --posts insta_autom/posts.json --out insta_autom/ocr_results_video_or_reel.json
```

Optional — comment codes (see [../comments/Steps.md](../comments/Steps.md)):
```bash
python insta_autom/comments/fetch_comments.py --posts insta_autom/posts.json --out insta_autom/comments/comments.json
python insta_autom/comments/extract_codes.py  --in insta_autom/comments/comments.json --out insta_autom/comments/codes_from_comments.json
```

## Order (from workspace root)

### 1. Launch the UI
```bash
python -m insta_autom.ui.review_ui
```

### 2. Custom paths (all optional)
```bash
python -m insta_autom.ui.review_ui \
  --posts   insta_autom/posts.json \
  --ocr-video    insta_autom/ocr_results_video_or_reel.json \
  --ocr-carousel insta_autom/ocr_results_carousel.json \
  --ocr-image    insta_autom/ocr_results_image_post.json \
  --comments-codes insta_autom/comments/codes_from_comments.json \
  --state   insta_autom/ocr_review_state.json \
  --downloads-root insta_autom/downloads \
  --frames-root    insta_autom/frames \
  --frame-interval 30
```

Use `--help` to see the exact flag names your copy accepts.

## UI notes

- Three tabs: **Video / Reel**, **Carousel**, **Single Post**.
- Each card shows a thumbnail preview (Pillow), OCR codes, comment codes, and diff badges.
- "↻ Reprocess" re-runs OCR for a single post in a background thread.
