# insta_saved — Execution Steps

Refactored Instagram toolkit. Exposes a CLI (`python -m insta_autom.insta_saved ...`) plus per-media-type OCR runners.

## Files

| File | Purpose |
|------|---------|
| `cli.py` / `__main__.py` | CLI entry: `map`, `ig fetch/parse`, `video download/frames`, `ocr image/video`. |
| `ig_saved.py` | Fetches items from an IG saved collection (paginates). |
| `post_parser.py` | Parses raw IG feed items into flat `posts.json`. |
| `video_tools.py` | Video download + frame extraction. |
| `ocr_tools.py` | Doctr-based OCR helper (`extract_codes_from_image`, `extract_codes_from_video`). |
| `ocr_image_post.py` | Runs OCR over every `image_post` in `posts.json`. |
| `ocr_carousel.py` | Runs OCR over every `carousel` in `posts.json`. |
| `ocr_video_or_reel.py` | Extracts frames + OCR over every `video_or_reel` in `posts.json`. |
| `repo_map.py` | Import-graph reporter used by `python -m insta_autom.insta_saved map`. |
| `requirements.txt` | Deps: `requests`, `doctr`, `opencv-python`, `Pillow`, `python-doctr`, ... |
| `README.md`, `PROJECT_MAP.md` | Docs. |

## Prerequisites

```bash
pip install -r insta_autom/insta_saved/requirements.txt
export IG_COOKIE='csrftoken=...; sessionid=...; ds_user_id=...'   # needed for ig fetch
```

## Order (from workspace root)

### 1. Fetch a saved collection into `data.json`
```bash
python -m insta_autom.insta_saved ig fetch \
  --collection-id 18025099568665354 \
  --out insta_autom/data.json
```

### 2. Parse into a cleaner `posts.json`
```bash
python -m insta_autom.insta_saved ig parse \
  --in insta_autom/data.json \
  --out insta_autom/posts.json
```

### 3. Run OCR per media type (any order, all independent)
```bash
python -m insta_autom.insta_saved.ocr_image_post \
  --posts insta_autom/posts.json \
  --out insta_autom/ocr_results_image_post.json \
  --pattern "[A-Z]{2,5}-?\d{3,5}"

python -m insta_autom.insta_saved.ocr_carousel \
  --posts insta_autom/posts.json \
  --out insta_autom/ocr_results_carousel.json \
  --pattern "[A-Z]{2,5}-?\d{3,5}"

python -m insta_autom.insta_saved.ocr_video_or_reel \
  --posts insta_autom/posts.json \
  --out insta_autom/ocr_results_video_or_reel.json \
  --frame-interval 90 \
  --pattern "[A-Z]{2,5}-?\d{3,5}"
```

### 4. Ad-hoc single-file helpers
```bash
python -m insta_autom.insta_saved video download --url "<video_url>" --out video.mp4
python -m insta_autom.insta_saved video frames   --video video.mp4 --interval 30
python -m insta_autom.insta_saved ocr image      --image path/to/img.jpg
python -m insta_autom.insta_saved ocr video      --video video.mp4 --interval 30
```

### 5. Regenerate the project map
```bash
python -m insta_autom.insta_saved map --out insta_autom/insta_saved/PROJECT_MAP.md
```

## Notes

- Never hardcode the cookie in scripts — use `IG_COOKIE`.
- Instagram sometimes changes response shapes; if `ig fetch` returns no items, refresh the cookie and retry.
- OCR needs `python-doctr` and `opencv-python`; the CLI will tell you what's missing.
