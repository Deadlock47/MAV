from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def parse_post_media(media: dict[str, Any]) -> dict[str, Any]:
    """
    Converts an Instagram "media" object into a smaller, easier-to-use structure.

    This is based on the logic in `test1.py`.
    """
    media_type_map = {1: "image_post", 2: "video_or_reel", 8: "carousel"}
    media_type = media.get("media_type")

    post_data: dict[str, Any] = {
        "post_id": media.get("id"),
        "shortcode": media.get("code"),
        "post_type": media_type_map.get(media_type, "unknown"),
        "caption": media.get("caption", {}).get("text", "") if media.get("caption") else "",
        "comment_count": media.get("comment_count", 0),
        "like_count": media.get("like_count", 0),
        "media": [],
    }

    if media_type == 1:
        candidates = (((media.get("image_versions2") or {}).get("candidates")) or [])
        if candidates:
            post_data["media"].append({"type": "image", "url": candidates[0].get("url")})

    elif media_type == 2:
        versions = (media.get("video_versions") or [])
        if versions:
            post_data["media"].append({"type": "video", "url": versions[0].get("url")})

    elif media_type == 8:
        for item in media.get("carousel_media") or []:
            item_type = item.get("media_type")
            if item_type == 1:
                candidates = (((item.get("image_versions2") or {}).get("candidates")) or [])
                if candidates:
                    post_data["media"].append({"type": "image", "url": candidates[0].get("url")})
            else:
                versions = (item.get("video_versions") or [])
                if versions:
                    post_data["media"].append({"type": "video", "url": versions[0].get("url")})

    return post_data


def parse_saved_items(items: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, int]]:
    posts: list[dict[str, Any]] = []
    counts: dict[str, int] = {"image_post": 0, "video_or_reel": 0, "carousel": 0, "unknown": 0}

    for item in items:
        media = item.get("media")
        if not isinstance(media, dict):
            continue
        post = parse_post_media(media)
        posts.append(post)
        counts[post.get("post_type", "unknown")] = counts.get(post.get("post_type", "unknown"), 0) + 1

    return posts, counts


def parse_saved_items_file(in_path: Path, out_path: Path) -> tuple[list[dict[str, Any]], dict[str, int]]:
    raw = json.loads(in_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected input JSON to be a list of items (like data.json)")

    posts, summary = parse_saved_items(raw)
    out_path.write_text(json.dumps(posts, indent=2), encoding="utf-8")
    return posts, summary

