from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Iterable


@dataclass(frozen=True)
class FileImports:
    path: str
    stdlib: list[str]
    third_party: list[str]
    local: list[str]


@dataclass(frozen=True)
class PythonMap:
    root: str
    files: list[FileImports]


def _iter_python_files(root: Path, *, exclude_dirs: set[str]) -> Iterable[Path]:
    for path in root.rglob("*.py"):
        if any(part in exclude_dirs for part in path.parts):
            continue
        yield path


def _stdlib_names() -> set[str]:
    names: set[str] = set(sys.builtin_module_names)
    stdlib = getattr(sys, "stdlib_module_names", None)
    if stdlib:
        names |= set(stdlib)
    return names


def _top_module(name: str | None) -> str | None:
    if not name:
        return None
    return name.split(".", 1)[0]


def _imports_for_file(path: Path) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        # If a file isn't UTF-8, skip import parsing (rare for .py files).
        return set()

    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                mod = _top_module(alias.name)
                if mod:
                    imports.add(mod)
        elif isinstance(node, ast.ImportFrom):
            mod = _top_module(node.module)
            if mod:
                imports.add(mod)
    return imports


def build_python_map(*, root: Path, exclude_dirs: set[str] | None = None) -> PythonMap:
    exclude_dirs = exclude_dirs or set()
    stdlib = _stdlib_names()

    # Local module detection: any <name>.py under the repo root.
    local_modules = {p.stem for p in root.glob("*.py")}

    files: list[FileImports] = []
    for py_file in sorted(_iter_python_files(root, exclude_dirs=exclude_dirs), key=lambda p: str(p)):
        imports = _imports_for_file(py_file)
        stdlib_imports = sorted([m for m in imports if m in stdlib])
        local_imports = sorted([m for m in imports if m in local_modules])
        third_party_imports = sorted(
            [m for m in imports if m not in stdlib and m not in local_modules]
        )
        files.append(
            FileImports(
                path=str(py_file.relative_to(root)),
                stdlib=stdlib_imports,
                third_party=third_party_imports,
                local=local_imports,
            )
        )

    return PythonMap(root=str(root), files=files)


def render_markdown(py_map: PythonMap, *, title: str = "Python Map") -> str:
    lines: list[str] = [f"# {title}", ""]
    lines.append(f"Root: `{py_map.root}`")
    lines.append("")

    if not py_map.files:
        lines.append("(No python files found)")
        lines.append("")
        return "\n".join(lines)

    for f in py_map.files:
        lines.append(f"## `{f.path}`")
        if f.stdlib:
            lines.append(f"- stdlib: {', '.join(f.stdlib)}")
        if f.third_party:
            lines.append(f"- third-party: {', '.join(f.third_party)}")
        if f.local:
            lines.append(f"- local: {', '.join(f.local)}")
        if not (f.stdlib or f.third_party or f.local):
            lines.append("- (no imports detected)")
        lines.append("")

    return "\n".join(lines)

