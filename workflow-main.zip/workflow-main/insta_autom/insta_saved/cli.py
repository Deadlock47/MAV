from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .ig_saved import fetch_collection_items
from .post_parser import parse_saved_items_file
from .repo_map import build_python_map, render_markdown
from .video_tools import download_file, extract_frames
from .ocr_tools import extract_codes_from_image, extract_codes_from_video


def _repo_root() -> Path:
    # insta_saved/ lives directly under the repo root.
    return Path(__file__).resolve().parents[1]


def _default_frames_dir(video_path: Path) -> Path:
    stem = video_path.stem or "video"
    return _repo_root() / "frames" / stem


def _cmd_map(args: argparse.Namespace) -> int:
    root = _repo_root()
    py_map = build_python_map(
        root=root,
        exclude_dirs={"insta_saved", "__pycache__", ".git"},
    )
    md = render_markdown(py_map, title=f"Python Map for {root.name}")

    if args.out:
        out_path = Path(args.out)
        out_path.write_text(md, encoding="utf-8")
    else:
        print(md)
    return 0


def _cmd_ig_fetch(args: argparse.Namespace) -> int:
    cookie = args.cookie or os.environ.get("IG_COOKIE")
    if not cookie:
        raise SystemExit(
            "Missing Instagram cookie. Pass `--cookie` or set env var `IG_COOKIE`."
        )

    items = fetch_collection_items(
        collection_id=args.collection_id,
        cookie=cookie,
        ig_app_id=args.ig_app_id or os.environ.get("IG_APP_ID"),
        user_agent=args.user_agent or os.environ.get("IG_USER_AGENT"),
        max_pages=args.max_pages,
    )

    out_path = Path(args.out)
    out_path.write_text(json.dumps(items, indent=2), encoding="utf-8")
    print(f"Wrote {len(items)} items -> {out_path}")
    return 0


def _cmd_ig_parse(args: argparse.Namespace) -> int:
    in_path = Path(args.input)
    out_path = Path(args.out)
    posts, summary = parse_saved_items_file(in_path, out_path)
    print(f"Wrote {len(posts)} posts -> {out_path}")
    if args.summary:
        print(json.dumps(summary, indent=2))
    return 0


def _cmd_video_download(args: argparse.Namespace) -> int:
    out_path = Path(args.out)
    download_file(args.url, out_path)
    print(f"Downloaded -> {out_path}")
    return 0


def _cmd_video_frames(args: argparse.Namespace) -> int:
    video_path = Path(args.video)
    out_dir = Path(args.out_dir) if args.out_dir else _default_frames_dir(video_path)
    frame_paths = extract_frames(video_path, out_dir, frame_interval=args.interval)
    print(f"Extracted {len(frame_paths)} frames -> {out_dir}")
    return 0


def _cmd_ocr_image(args: argparse.Namespace) -> int:
    codes = extract_codes_from_image(Path(args.image), pattern=args.pattern)
    print(json.dumps({"codes": codes, "count": len(codes)}, indent=2))
    return 0


def _cmd_ocr_video(args: argparse.Namespace) -> int:
    video_path = Path(args.video)
    frames_dir = Path(args.frames_dir) if args.frames_dir else _default_frames_dir(video_path)
    codes = extract_codes_from_video(
        video_path,
        frames_dir=frames_dir,
        frame_interval=args.interval,
        pattern=args.pattern,
    )
    print(json.dumps({"codes": codes, "count": len(codes)}, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="insta_saved", description="Helper CLI for this repo")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_map = sub.add_parser("map", help="Generate a simple Python/imports map")
    p_map.add_argument("--out", help="Write markdown output to a file")
    p_map.set_defaults(func=_cmd_map)

    p_ig = sub.add_parser("ig", help="Instagram saved items helpers")
    ig_sub = p_ig.add_subparsers(dest="ig_cmd", required=True)

    p_fetch = ig_sub.add_parser("fetch", help="Fetch saved items JSON into a file")
    p_fetch.add_argument("--collection-id", required=True, help="Instagram saved collection ID")
    p_fetch.add_argument("--out", default="data.json", help="Output json file (default: data.json)")
    p_fetch.add_argument("--cookie", help="Full Cookie header value (or set IG_COOKIE)")
    p_fetch.add_argument("--ig-app-id", help="X-IG-App-ID header value (optional)")
    p_fetch.add_argument("--user-agent", help="User-Agent header value (optional)")
    p_fetch.add_argument("--max-pages", type=int, help="Stop after N pages (optional)")
    p_fetch.set_defaults(func=_cmd_ig_fetch)

    p_parse = ig_sub.add_parser("parse", help="Parse data.json into a cleaner posts.json")
    p_parse.add_argument("--in", dest="input", default="data.json", help="Input json file (default: data.json)")
    p_parse.add_argument("--out", default="posts.json", help="Output json file (default: posts.json)")
    p_parse.add_argument("--summary", action="store_true", help="Print a small type summary")
    p_parse.set_defaults(func=_cmd_ig_parse)

    p_video = sub.add_parser("video", help="Video helpers")
    video_sub = p_video.add_subparsers(dest="video_cmd", required=True)

    p_vd = video_sub.add_parser("download", help="Download a video url to a file")
    p_vd.add_argument("--url", required=True, help="Video URL")
    p_vd.add_argument("--out", default="video.mp4", help="Output path (default: video.mp4)")
    p_vd.set_defaults(func=_cmd_video_download)

    p_vf = video_sub.add_parser("frames", help="Extract frames from a local video")
    p_vf.add_argument("--video", required=True, help="Path to local video file")
    p_vf.add_argument("--out-dir", help="Frames output dir (default: frames/<video_stem>/)")
    p_vf.add_argument("--interval", type=int, default=30, help="Save every Nth frame (default: 30)")
    p_vf.set_defaults(func=_cmd_video_frames)

    p_ocr = sub.add_parser("ocr", help="OCR helpers (uses doctr)")
    ocr_sub = p_ocr.add_subparsers(dest="ocr_cmd", required=True)

    p_oi = ocr_sub.add_parser("image", help="Run OCR on one image and extract codes")
    p_oi.add_argument("--image", required=True, help="Path to image file")
    p_oi.add_argument("--pattern", default=None, help="Regex pattern override (optional)")
    p_oi.set_defaults(func=_cmd_ocr_image)

    p_ov = ocr_sub.add_parser("video", help="Extract frames + run OCR over a video")
    p_ov.add_argument("--video", required=True, help="Path to local video file")
    p_ov.add_argument("--frames-dir", help="Frames output dir (default: frames/<video_stem>/)")
    p_ov.add_argument("--interval", type=int, default=30, help="Save every Nth frame (default: 30)")
    p_ov.add_argument("--pattern", default=None, help="Regex pattern override (optional)")
    p_ov.set_defaults(func=_cmd_ocr_video)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))

