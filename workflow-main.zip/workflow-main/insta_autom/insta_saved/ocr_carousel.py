from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .ocr_tools import extract_codes_from_image
from .video_tools import download_file


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def ocr_carousel_post_images(
    post: dict[str, Any],
    *,
    downloads_dir: Path,
    pattern: str | None = None,
) -> dict[str, Any]:
    """
    For `post_type == "carousel"`:
    - downloads every image in the carousel
    - runs OCR on each image and returns matching codes

    Notes:
    - If a carousel contains videos, they are ignored by this function.
    """
    if post.get("post_type") != "carousel":
        raise ValueError(f"Expected post_type=carousel, got {post.get('post_type')!r}")

    media = post.get("media")
    if not isinstance(media, list):
        raise ValueError("Post is missing `media` list")

    post_key = str(post.get("shortcode") or post.get("post_id") or "post")
    post_dir = downloads_dir / post_key
    post_dir.mkdir(parents=True, exist_ok=True)

    image_results: list[dict[str, Any]] = []
    found: set[str] = set()

    for idx, item in enumerate(media):
        if not isinstance(item, dict):
            continue
        if item.get("type") != "image":
            continue
        url = item.get("url")
        if not url:
            continue

        img_path = post_dir / f"image_{idx:02d}.jpg"
        if not img_path.exists():
            download_file(str(url), img_path)

        codes = extract_codes_from_image(img_path, pattern=pattern)
        for code in codes:
            found.add(code)
        image_results.append(
            {
                "index": idx,
                "image_path": str(img_path),
                "codes": codes,
                "count": len(codes),
            }
        )

    return {
        "post_id": post.get("post_id"),
        "shortcode": post.get("shortcode"),
        "post_type": post.get("post_type"),
        "images_processed": len(image_results),
        "codes": sorted(found),
        "count": len(found),
        "image_results": image_results,
    }


def _load_posts(posts_path: Path) -> list[dict[str, Any]]:
    raw = json.loads(posts_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected posts JSON to be a list (like posts.json)")
    return [item for item in raw if isinstance(item, dict)]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m insta_saved.ocr_carousel",
        description="Download carousel images from posts.json and OCR them to extract codes.",
    )
    parser.add_argument("--posts", default="posts.json", help="Input posts.json (default: posts.json)")
    parser.add_argument(
        "--out",
        default="ocr_results_carousel.json",
        help="Output results JSON (default: ocr_results_carousel.json)",
    )
    parser.add_argument("--limit", type=int, default=None, help="Max carousel posts to OCR (default: all)")
    parser.add_argument("--pattern", default=None, help="Regex pattern override (optional)")
    parser.add_argument(
        "--downloads-dir",
        default=str(_repo_root() / "downloads" / "carousel"),
        help="Where to store downloaded images",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    posts_path = Path(args.posts)
    out_path = Path(args.out)
    downloads_dir = Path(args.downloads_dir)

    posts = _load_posts(posts_path)
    carousel_posts = [p for p in posts if p.get("post_type") == "carousel"]
    if args.limit is not None:
        if args.limit < 0:
            raise SystemExit("--limit must be >= 0")
        carousel_posts = carousel_posts[: args.limit]

    results: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    for post in carousel_posts:
        try:
            results.append(
                ocr_carousel_post_images(
                    post,
                    downloads_dir=downloads_dir,
                    pattern=args.pattern,
                )
            )
        except Exception as e:
            failures.append(
                {
                    "post_id": post.get("post_id"),
                    "shortcode": post.get("shortcode"),
                    "error": str(e),
                }
            )

    payload = {
        "post_type": "carousel",
        "total": len(carousel_posts),
        "processed": len(results),
        "failed": len(failures),
        "results": results,
        "failures": failures,
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(out_path), "processed": len(results), "failed": len(failures)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
