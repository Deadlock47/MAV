from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any
from urllib.parse import quote


@dataclass(frozen=True)
class InstagramHeaders:
    cookie: str
    user_agent: str = "Mozilla/5.0"
    ig_app_id: str | None = "936619743392459"
    referer: str = "https://www.instagram.com/"

    def to_dict(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "User-Agent": self.user_agent,
            "Accept": "*/*",
            "Referer": self.referer,
            "Cookie": self.cookie,
        }
        if self.ig_app_id:
            headers["X-IG-App-ID"] = self.ig_app_id
        return headers


def fetch_collection_items(
    *,
    collection_id: str,
    cookie: str,
    ig_app_id: str | None = None,
    user_agent: str | None = None,
    max_pages: int | None = None,
) -> list[dict[str, Any]]:
    """
    Fetch saved items from an Instagram collection using the private web API.

    This mirrors your `inst_saved_autom.py` logic but avoids hardcoding credentials.
    """
    try:
        import requests  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise SystemExit("Missing dependency: `requests` (pip install requests)") from e

    headers = InstagramHeaders(
        cookie=cookie,
        user_agent=user_agent or "Mozilla/5.0",
        ig_app_id=ig_app_id or "936619743392459",
    ).to_dict()

    base = f"https://www.instagram.com/api/v1/feed/collection/{collection_id}/posts/"

    def build_url(max_id: str | None) -> str:
        return f"{base}?max_id={quote(max_id or '')}"

    items: list[dict[str, Any]] = []
    page = 0
    next_max_id: str | None = ""

    while True:
        if max_pages is not None and page >= max_pages:
            break
        page += 1

        url = build_url(next_max_id)
        resp = requests.get(url, headers=headers, allow_redirects=False, timeout=30)
        if resp.status_code != 200:
            # Avoid printing cookie/header values.
            raise SystemExit(
                f"Instagram request failed: HTTP {resp.status_code}. "
                "Your cookie may be expired, or Instagram blocked the request."
            )

        data = resp.json()
        page_items = data.get("items") or []
        if not isinstance(page_items, list):
            raise SystemExit("Unexpected response shape: `items` is not a list")

        items.extend(page_items)
        next_max_id = data.get("next_max_id") or ""
        if not next_max_id:
            break

    return items

