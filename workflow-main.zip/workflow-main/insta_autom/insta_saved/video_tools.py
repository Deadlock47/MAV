from __future__ import annotations

from pathlib import Path


def download_file(url: str, out_path: Path, *, chunk_size: int = 1024 * 1024) -> Path:
    try:
        import requests  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise SystemExit("Missing dependency: `requests` (pip install requests)") from e

    out_path.parent.mkdir(parents=True, exist_ok=True)

    with requests.get(url, stream=True, timeout=60) as resp:
        resp.raise_for_status()
        with out_path.open("wb") as f:
            for chunk in resp.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)

    return out_path


def extract_frames(video_path: Path, out_dir: Path, *, frame_interval: int = 30) -> list[Path]:
    """
    Extract every Nth frame from a local video file.
    """
    try:
        import cv2  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise SystemExit("Missing dependency: `opencv-python` (pip install opencv-python)") from e

    out_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise SystemExit(f"Could not open video: {video_path}")

    frame_paths: list[Path] = []
    frame_id = 0
    saved = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_interval <= 1 or frame_id % frame_interval == 0:
            out_path = out_dir / f"frame_{saved:06d}.jpg"
            cv2.imwrite(str(out_path), frame)
            frame_paths.append(out_path)
            saved += 1
        frame_id += 1

    cap.release()
    return frame_paths

