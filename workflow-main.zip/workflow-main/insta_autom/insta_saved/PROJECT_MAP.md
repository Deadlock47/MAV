# Python Map for inst

Root: `D:\inst`

## `finalized_ocr.py`
- stdlib: re
- third-party: doctr

## `inst_saved_autom.py`
- stdlib: json, urllib
- third-party: requests

## `instagram-saved-scraper\insta-scrape.py`
- (no imports detected)

## `test1.py`
- stdlib: json

## `test3.py`
- stdlib: os
- third-party: cv2, requests
- local: finalized_ocr
