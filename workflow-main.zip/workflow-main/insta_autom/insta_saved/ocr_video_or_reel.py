from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .ocr_tools import extract_codes_from_video
from .video_tools import download_file


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def ocr_video_or_reel_post(
    post: dict[str, Any],
    *,
    downloads_dir: Path,
    frames_root_dir: Path,
    frame_interval: int = 30,
    pattern: str | None = None,
) -> dict[str, Any]:
    """
    For `post_type == "video_or_reel"`:
    - downloads the video
    - extracts frames
    - runs OCR on the frames and returns matching codes
    """
    if post.get("post_type") != "video_or_reel":
        raise ValueError(f"Expected post_type=video_or_reel, got {post.get('post_type')!r}")

    media = post.get("media")
    if not isinstance(media, list):
        raise ValueError("Post is missing `media` list")

    video_item = next(
        (
            item
            for item in media
            if isinstance(item, dict) and item.get("type") == "video" and item.get("url")
        ),
        None,
    )
    if not video_item:
        raise ValueError("No video media URL found for this post")

    post_key = str(post.get("shortcode") or post.get("post_id") or "post")
    downloads_dir.mkdir(parents=True, exist_ok=True)

    video_path = downloads_dir / f"{post_key}.mp4"
    if not video_path.exists():
        download_file(str(video_item["url"]), video_path)

    frames_dir = frames_root_dir / post_key
    codes = extract_codes_from_video(
        video_path,
        frames_dir=frames_dir,
        frame_interval=frame_interval,
        pattern=pattern,
    )

    return {
        "post_id": post.get("post_id"),
        "shortcode": post.get("shortcode"),
        "post_type": post.get("post_type"),
        "video_path": str(video_path),
        "frames_dir": str(frames_dir),
        "codes": codes,
        "count": len(codes),
    }


def _load_posts(posts_path: Path) -> list[dict[str, Any]]:
    raw = json.loads(posts_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected posts JSON to be a list (like posts.json)")
    return [item for item in raw if isinstance(item, dict)]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m insta_saved.ocr_video_or_reel",
        description="Download reels/videos from posts.json and OCR their frames to extract codes.",
    )
    parser.add_argument("--posts", default="posts.json", help="Input posts.json (default: posts.json)")
    parser.add_argument(
        "--out",
        default="ocr_results_video_or_reel.json",
        help="Output results JSON (default: ocr_results_video_or_reel.json)",
    )
    parser.add_argument("--limit", type=int, default=None, help="Max posts to OCR (default: all)")
    parser.add_argument("--frame-interval", type=int, default=30, help="Save every Nth frame (default: 30)")
    parser.add_argument("--pattern", default=None, help="Regex pattern override (optional)")
    parser.add_argument(
        "--downloads-dir",
        default=str(_repo_root() / "downloads" / "video_or_reel"),
        help="Where to store downloaded videos",
    )
    parser.add_argument(
        "--frames-dir",
        default=str(_repo_root() / "frames" / "video_or_reel"),
        help="Where to store extracted frames",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    posts_path = Path(args.posts)
    out_path = Path(args.out)
    downloads_dir = Path(args.downloads_dir)
    frames_root_dir = Path(args.frames_dir)

    posts = _load_posts(posts_path)
    video_posts = [p for p in posts if p.get("post_type") == "video_or_reel"]
    if args.limit is not None:
        if args.limit < 0:
            raise SystemExit("--limit must be >= 0")
        video_posts = video_posts[: args.limit]

    results: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    for post in video_posts:
        try:
            results.append(
                ocr_video_or_reel_post(
                    post,
                    downloads_dir=downloads_dir,
                    frames_root_dir=frames_root_dir,
                    frame_interval=args.frame_interval,
                    pattern=args.pattern,
                )
            )
        except Exception as e:
            failures.append(
                {
                    "post_id": post.get("post_id"),
                    "shortcode": post.get("shortcode"),
                    "error": str(e),
                }
            )

    payload = {
        "post_type": "video_or_reel",
        "total": len(video_posts),
        "processed": len(results),
        "failed": len(failures),
        "results": results,
        "failures": failures,
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(out_path), "processed": len(results), "failed": len(failures)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
