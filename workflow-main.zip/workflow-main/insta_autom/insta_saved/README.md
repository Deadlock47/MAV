# insta_saved

This folder is an "add-on toolbox" for the scripts in the repo root (`inst_saved_autom.py`, `test1.py`, `test3.py`, `finalized_ocr.py`).
It does not change or break your existing scripts; it just gives you a cleaner way to run the same workflows.

## Quick Start

From `d:\inst`:

```powershell
python -m insta_saved map
```

## Commands

Project map (imports/deps):

```powershell
python -m insta_saved map --out insta_saved\\PROJECT_MAP.md
```

Fetch saved items from an Instagram collection (writes `data.json`):

```powershell
$env:IG_COOKIE = 'csrftoken=Hq8lc67-WSITdkWBXZfE8A; datr=nQh6arI_DA3CBq42vkN1fATD; ig_did=62C2386E-29F9-4E2B-A140-B04F585D252E; mid=anoInQALAAHaPsicBithPOPX6mpY; dpr=1.25; ds_user_id=59799985019; sessionid=59799985019%3ASQiD2IbMl4fd8X%3A15%3AAYiXayN8OCzNCT-UxVMqqoj1T7tz1-ikzJeAG22HyQ; wd=770x702; rur=EAG%2C17841459790574998%2C1789282852%3A01ff1a41946c52e450b7eefc52d9f3e7a210227d68eeb08273f611321325ad0b908212ff'
python -m insta_saved ig fetch --collection-id 18025099568665354 --out data.json
```

Parse `data.json` into a cleaner `posts.json`:

```powershell
python -m insta_saved ig parse --in data.json --out posts.json
```

Download a video and OCR it (extract codes like `AB-1234`):

```powershell
python -m insta_saved video download --url "<video_url>" --out video.mp4
python -m insta_saved ocr video --video video.mp4 --interval 30
```

Notes:
- Keep secrets out of files. Prefer env vars like `IG_COOKIE` over hardcoding cookies in code.
- `ocr` uses `python-doctr` and `opencv-python`. If those aren't installed, the command will tell you what to install.

```python -m insta_saved.ocr_video_or_reel --posts posts.json --out ocr_results_video_or_reel.json --frame-interval 90 --pattern "[A-Z]{2,5}-?\d{3,5}" ```

-- 
```python -m insta_saved.ocr_carousel --posts posts.json --out ocr_results_carousel.json --pattern "[A-Z]{2,5}-?\d{3,5}"```

-- 
```python -m insta_saved.ocr_image_post --posts posts.json --out ocr_results_image_post.json --pattern "[A-Z]{2,5}-?\d{3,5}"```