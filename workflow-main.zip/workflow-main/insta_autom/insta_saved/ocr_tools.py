from __future__ import annotations

import re
from pathlib import Path

from .video_tools import extract_frames

DEFAULT_PATTERN = r"[A-Z]{2,5}-?\d{3,5}"

_PREDICTOR = None


def _get_doctr_predictor():
    global _PREDICTOR
    if _PREDICTOR is not None:
        return _PREDICTOR

    try:
        from doctr.models import ocr_predictor  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise SystemExit(
            "Missing dependency: `python-doctr` (pip install python-doctr[torch])"
        ) from e

    _PREDICTOR = ocr_predictor(pretrained=True)
    return _PREDICTOR


def extract_codes_from_image(image_path: Path, *, pattern: str | None = None) -> list[str]:
    """
    Runs doctr OCR on a single image and returns all matching codes.
    """
    try:
        from doctr.io import DocumentFile  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise SystemExit(
            "Missing dependency: `python-doctr` (pip install python-doctr[torch])"
        ) from e

    regex = re.compile(pattern or DEFAULT_PATTERN)
    predictor = _get_doctr_predictor()

    doc = DocumentFile.from_images(str(image_path))
    result = predictor(doc)
    output = result.export()

    codes: list[str] = []
    for page in output.get("pages", []):
        for block in page.get("blocks", []):
            for line in block.get("lines", []):
                words = line.get("words", [])
                text = " ".join([w.get("value", "") for w in words if isinstance(w, dict)])
                codes.extend(regex.findall(text))

    return codes


def extract_codes_from_video(
    video_path: Path,
    *,
    frames_dir: Path,
    frame_interval: int = 30,
    pattern: str | None = None,
) -> list[str]:
    frame_paths = extract_frames(video_path, frames_dir, frame_interval=frame_interval)

    found: set[str] = set()
    for frame_path in frame_paths:
        for code in extract_codes_from_image(frame_path, pattern=pattern):
            found.add(code)

    return sorted(found)

