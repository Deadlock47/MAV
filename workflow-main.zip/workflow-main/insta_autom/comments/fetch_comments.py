from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

import requests

if __package__:
    from .ig_comments import build_headers, fetch_all_comments
else:
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from comments.ig_comments import build_headers, fetch_all_comments


def load_posts(posts_path: Path) -> list[dict[str, Any]]:
    """Load posts from a posts.json file."""
    raw = json.loads(posts_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected posts.json to be a list of posts")
    return [p for p in raw if isinstance(p, dict)]


def media_id_from_post(post: dict[str, Any]) -> str:
    """Derive the numeric media_id from posts.json post_id (split before underscore)."""
    post_id = post.get("post_id")
    if not isinstance(post_id, str) or not post_id:
        raise ValueError("Missing post_id")
    return post_id.split("_", 1)[0]


def output_path_for_post(out_dir: Path, post: dict[str, Any], media_id: str) -> Path:
    """Build an output JSON path for one post's comments."""
    shortcode = post.get("shortcode")
    safe = shortcode if isinstance(shortcode, str) and shortcode else media_id
    return out_dir / f"{safe}.comments.json"


def normalize_user(user: Any) -> dict[str, Any] | None:
    """Normalize an Instagram user object for storage."""
    if not isinstance(user, dict):
        return None
    pk = user.get("pk") or user.get("id")
    return {
        "id": str(pk) if pk is not None else None,
        "username": user.get("username"),
        "full_name": user.get("full_name"),
        "is_verified": user.get("is_verified"),
    }


def normalize_comment(comment: Any) -> dict[str, Any] | None:
    """Normalize a single comment (or reply) object for storage."""
    if not isinstance(comment, dict):
        return None
    pk = comment.get("pk") or comment.get("id")
    created_at = comment.get("created_at") or comment.get("created_at_utc")
    like_count = (
        comment.get("comment_like_count")
        if comment.get("comment_like_count") is not None
        else comment.get("like_count")
    )

    replies_raw = comment.get("replies")
    replies: list[dict[str, Any]] = []
    if isinstance(replies_raw, list):
        for r in replies_raw:
            nr = normalize_comment(r)
            if nr is not None:
                replies.append(nr)

    return {
        "id": str(pk) if pk is not None else None,
        "text": comment.get("text"),
        "created_at": created_at,
        "like_count": like_count,
        "user": normalize_user(comment.get("user")),
        "child_comment_count": comment.get("child_comment_count"),
        "replies": replies,
    }


def normalize_comments_tree(comments: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Normalize a list of comments including attached replies."""
    out: list[dict[str, Any]] = []
    for c in comments:
        nc = normalize_comment(c)
        if nc is not None:
            out.append(nc)
    return out


def build_parser() -> argparse.ArgumentParser:
    """Build CLI args for fetching comments for every post in posts.json."""
    parser = argparse.ArgumentParser(
        prog="python comments\\fetch_comments.py",
        description="Fetch Instagram comments (and replies) for every post in posts.json.",
    )
    parser.add_argument("--posts", default="posts.json", help="Input posts.json (default: posts.json)")
    parser.add_argument(
        "--out",
        default="comments\\comments.json",
        help="Single collated output file (default: comments\\comments.json)",
    )
    parser.add_argument(
        "--split",
        action="store_true",
        help="Also write one JSON file per post under --out-dir",
    )
    parser.add_argument("--out-dir", default="comments\\out", help="Per-post output folder (default: comments\\out)")
    parser.add_argument("--limit", type=int, default=None, help="Only process first N posts (default: all)")
    parser.add_argument("--cookie", help="Instagram Cookie header value (or set IG_COOKIE)")
    parser.add_argument("--ig-app-id", help="X-IG-App-ID header value (optional; or set IG_APP_ID)")
    parser.add_argument("--user-agent", help="User-Agent header value (optional; or set IG_USER_AGENT)")
    parser.add_argument("--no-replies", action="store_true", help="Skip fetching replies (child comments)")
    parser.add_argument("--max-comment-pages", type=int, help="Stop after N comment pages (optional)")
    parser.add_argument("--max-reply-pages", type=int, help="Stop after N reply pages per comment (optional)")
    parser.add_argument("--sleep", type=float, default=0.0, help="Sleep seconds between pages (default: 0)")
    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point for the comments fetch CLI."""
    args = build_parser().parse_args(argv)

    cookie = args.cookie or os.environ.get("IG_COOKIE")
    if not cookie:
        raise SystemExit("Missing Instagram cookie. Pass --cookie or set env var IG_COOKIE.")

    headers = build_headers(
        cookie=cookie,
        user_agent=args.user_agent or os.environ.get("IG_USER_AGENT") or "Mozilla/5.0",
        ig_app_id=args.ig_app_id or os.environ.get("IG_APP_ID") or "936619743392459",
    )

    posts = load_posts(Path(args.posts))
    if args.limit is not None:
        if args.limit < 0:
            raise SystemExit("--limit must be >= 0")
        posts = posts[: args.limit]

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    out_dir = Path(args.out_dir)
    if args.split:
        out_dir.mkdir(parents=True, exist_ok=True)

    session = requests.Session()

    failures: list[dict[str, Any]] = []
    collated: list[dict[str, Any]] = []
    for idx, post in enumerate(posts, start=1):
        try:
            media_id = media_id_from_post(post)
            result = fetch_all_comments(
                session,
                media_id,
                headers=headers,
                include_replies=not args.no_replies,
                max_comment_pages=args.max_comment_pages,
                max_reply_pages=args.max_reply_pages,
                sleep_s=float(args.sleep or 0.0),
            )

            post_payload: dict[str, Any] = dict(post)
            post_payload["media_id"] = media_id
            post_payload["top_level_comment_count"] = result.top_level_count
            post_payload["reply_count"] = result.reply_count
            post_payload["comments"] = normalize_comments_tree(result.comments)
            collated.append(post_payload)

            if args.split:
                per_path = output_path_for_post(out_dir, post, media_id)
                per_path.write_text(
                    json.dumps(post_payload, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )

            print(
                f"[{idx}/{len(posts)}] {post.get('shortcode') or media_id}: "
                f"{result.top_level_count} comments, {result.reply_count} replies"
            )
        except Exception as e:
            failures.append(
                {
                    "post_id": post.get("post_id"),
                    "shortcode": post.get("shortcode"),
                    "error": str(e),
                }
            )
            print(f"[{idx}/{len(posts)}] FAILED {post.get('shortcode') or post.get('post_id')}: {e}")

    out_path.write_text(
        json.dumps(collated, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"Wrote {len(collated)} posts -> {out_path}")

    if failures:
        fail_path = (out_dir if args.split else out_path.parent) / "_failures.json"
        fail_path.write_text(
            json.dumps({"failures": failures}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"Wrote failures -> {fail_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
