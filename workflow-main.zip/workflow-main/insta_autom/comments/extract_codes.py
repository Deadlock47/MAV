from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Iterable

DEFAULT_PATTERN = r'[A-Za-z]{2,5}-?\d{3,5}'


def load_posts_with_comments(path: Path) -> list[dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected comments.json to be a list of posts")
    return [item for item in raw if isinstance(item, dict)]


def iter_comment_texts(comment: dict[str, Any]) -> Iterable[str]:
    text = comment.get("text")
    if isinstance(text, str) and text:
        yield text

    replies = comment.get("replies")
    if isinstance(replies, list) and replies:
        for reply in replies:
            if isinstance(reply, dict):
                yield from iter_comment_texts(reply)


def extract_codes_from_post(post: dict[str, Any], regex: re.Pattern[str]) -> list[str]:
    codes: list[str] = []
    seen: set[str] = set()

    comments = post.get("comments")
    if not isinstance(comments, list) or not comments:
        return codes

    for comment in comments:
        if not isinstance(comment, dict):
            continue
        for text in iter_comment_texts(comment):
            for match in regex.findall(text):
                if match in seen:
                    continue
                seen.add(match)
                codes.append(match)

    return codes


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python comments\\extract_codes.py",
        description="Extract code strings from comments/comments.json (includes replies).",
    )
    parser.add_argument(
        "--in",
        dest="input",
        default="comments\\comments.json",
        help="Input comments.json (default: comments\\comments.json)",
    )
    parser.add_argument(
        "--out",
        default="comments\\codes_from_comments.json",
        help="Output json file (default: comments\\codes_from_comments.json)",
    )
    parser.add_argument(
        "--pattern",
        default=DEFAULT_PATTERN,
        help='Regex pattern (default: "[A-Za-z]{2,5}-?\\d{3,5}")',
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    in_path = Path(args.input)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    regex = re.compile(str(args.pattern))
    posts = load_posts_with_comments(in_path)

    results: list[dict[str, Any]] = []
    for post in posts:
        codes = extract_codes_from_post(post, regex)
        results.append(
            {
                "post_id": post.get("post_id"),
                "shortcode": post.get("shortcode"),
                "post_type": post.get("post_type"),
                "code": codes,
                "count": len(codes),
            }
        )

    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {len(results)} posts -> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

