from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Any, Iterable


def build_headers(
    cookie: str,
    *,
    user_agent: str = "Mozilla/5.0",
    ig_app_id: str | None = "936619743392459",
    referer: str = "https://www.instagram.com/",
) -> dict[str, str]:
    """Build request headers for Instagram private web API calls."""
    headers: dict[str, str] = {
        "User-Agent": user_agent,
        "Accept": "*/*",
        "Referer": referer,
        "Cookie": cookie,
    }
    if ig_app_id:
        headers["X-IG-App-ID"] = ig_app_id
    return headers


def comments_url(media_id: str) -> str:
    """Return the URL for fetching top-level comments for a media item."""
    return f"https://www.instagram.com/api/v1/media/{media_id}/comments/"


def child_comments_url(media_id: str, comment_id: str) -> str:
    """Return the URL for fetching replies (child comments) for one comment."""
    return f"https://www.instagram.com/api/v1/media/{media_id}/comments/{comment_id}/child_comments/"


def request_json(
    session,
    url: str,
    *,
    headers: dict[str, str],
    params: dict[str, Any] | None = None,
    timeout_s: int = 30,
) -> dict[str, Any]:
    """GET a URL and return parsed JSON or raise a clear error."""
    resp = session.get(url, headers=headers, params=params or {}, timeout=timeout_s)
    if resp.status_code != 200:
        raise RuntimeError(f"Instagram request failed: HTTP {resp.status_code} for {url}")
    data = resp.json()
    if not isinstance(data, dict):
        raise RuntimeError("Unexpected response: JSON root is not an object")
    return data


def has_more(data: dict[str, Any]) -> bool:
    """Return True if the response indicates more pages are available."""
    return bool(data.get("has_more_comments") or data.get("has_more_headload_comments"))


def next_cursor(data: dict[str, Any]) -> tuple[str | None, str | None]:
    """Extract the next pagination cursor param name and value from a response."""
    next_max = data.get("next_max_id")
    if next_max is not None and str(next_max).strip():
        return "max_id", str(next_max)
    next_min = data.get("next_min_id")
    if next_min is not None and str(next_min).strip():
        return "min_id", str(next_min)
    next_id = data.get("next_id")
    if next_id is not None and str(next_id).strip():
        return "max_id", str(next_id)
    return None, None


def pick_items(data: dict[str, Any], keys: Iterable[str]) -> list[dict[str, Any]]:
    """Pick the first list-of-dicts field from the response using candidate keys."""
    for key in keys:
        value = data.get(key)
        if isinstance(value, list):
            out: list[dict[str, Any]] = []
            for item in value:
                if isinstance(item, dict):
                    out.append(item)
            return out
    return []


def fetch_all_pages(
    session,
    url: str,
    *,
    headers: dict[str, str],
    base_params: dict[str, Any] | None = None,
    items_keys: Iterable[str] = ("comments", "child_comments"),
    max_pages: int | None = None,
    sleep_s: float = 0.0,
) -> list[dict[str, Any]]:
    """Fetch all pages from a cursor-paginated Instagram endpoint."""
    params: dict[str, Any] = dict(base_params or {})
    cursor_param: str | None = None
    cursor_value: str | None = None

    out: list[dict[str, Any]] = []
    page = 0
    while True:
        if max_pages is not None and page >= max_pages:
            break
        page += 1

        if cursor_param and cursor_value:
            params[cursor_param] = cursor_value
        elif cursor_param:
            params.pop(cursor_param, None)

        data = request_json(session, url, headers=headers, params=params)
        out.extend(pick_items(data, items_keys))

        if not has_more(data):
            break
        cursor_param, cursor_value = next_cursor(data)
        if not cursor_param or not cursor_value:
            break
        if sleep_s > 0:
            time.sleep(sleep_s)

    return out


def fetch_top_level_comments(
    session,
    media_id: str,
    *,
    headers: dict[str, str],
    max_pages: int | None = None,
    sleep_s: float = 0.0,
) -> list[dict[str, Any]]:
    """Fetch all top-level comments for a media_id."""
    url = comments_url(media_id)
    return fetch_all_pages(
        session,
        url,
        headers=headers,
        base_params={"can_support_threading": "true"},
        items_keys=("comments",),
        max_pages=max_pages,
        sleep_s=sleep_s,
    )


def fetch_comment_replies(
    session,
    media_id: str,
    comment_id: str,
    *,
    headers: dict[str, str],
    max_pages: int | None = None,
    sleep_s: float = 0.0,
) -> list[dict[str, Any]]:
    """Fetch all replies (child comments) for a given comment_id."""
    url = child_comments_url(media_id, comment_id)
    return fetch_all_pages(
        session,
        url,
        headers=headers,
        base_params={"can_support_threading": "true"},
        items_keys=("child_comments", "comments"),
        max_pages=max_pages,
        sleep_s=sleep_s,
    )


def attach_replies(
    session,
    media_id: str,
    comments: list[dict[str, Any]],
    *,
    headers: dict[str, str],
    max_reply_pages: int | None = None,
    sleep_s: float = 0.0,
) -> tuple[list[dict[str, Any]], int]:
    """Fetch replies for each comment that has children and attach them under `replies`."""
    total_replies = 0
    for comment in comments:
        child_count = comment.get("child_comment_count")
        try:
            has_children = int(child_count or 0) > 0
        except Exception:
            has_children = False
        if not has_children:
            continue

        comment_pk = comment.get("pk")
        if comment_pk is None:
            continue
        replies = fetch_comment_replies(
            session,
            media_id,
            str(comment_pk),
            headers=headers,
            max_pages=max_reply_pages,
            sleep_s=sleep_s,
        )
        comment["replies"] = replies
        total_replies += len(replies)
    return comments, total_replies


@dataclass(frozen=True)
class CommentsFetchResult:
    """Structured result for one media_id comments fetch."""

    media_id: str
    top_level_count: int
    reply_count: int
    comments: list[dict[str, Any]]


def fetch_all_comments(
    session,
    media_id: str,
    *,
    headers: dict[str, str],
    include_replies: bool = True,
    max_comment_pages: int | None = None,
    max_reply_pages: int | None = None,
    sleep_s: float = 0.0,
) -> CommentsFetchResult:
    """Fetch all comments for a media_id, optionally including replies."""
    comments = fetch_top_level_comments(
        session,
        media_id,
        headers=headers,
        max_pages=max_comment_pages,
        sleep_s=sleep_s,
    )
    reply_count = 0
    if include_replies and comments:
        comments, reply_count = attach_replies(
            session,
            media_id,
            comments,
            headers=headers,
            max_reply_pages=max_reply_pages,
            sleep_s=sleep_s,
        )
    return CommentsFetchResult(
        media_id=media_id,
        top_level_count=len(comments),
        reply_count=reply_count,
        comments=comments,
    )
