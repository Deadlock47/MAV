# DataFetch — Execution Steps

Downloads r18.dev SQL dumps, loads them into a local Postgres, then exports every table to Parquet.

## Files

| File | Purpose |
|------|---------|
| `my_download_file.py` | Uses Playwright to scrape download links from `https://r18.dev/dumps`, then downloads the first file into `./downloads/`. |
| `load_sql_to_postgres.py` | Drops + recreates `public` schema, then runs every `.sql` file in `./downloads/` through `psql`. |
| `extract_tables_to_parquet.py` | Reads every table in schema `public` and writes `./jvify/db/<table>.parquet`. |
| `dumps` | Reference/leftover file (not a script). |

## Prerequisites

1. Postgres running locally (defaults: `localhost:5432`, db `freff`, user `postgres`, password `1234`). Override via `PG_HOST`, `PG_PORT`, `PG_USER`, `PG_PASSWORD`, `PG_DATABASE`.
2. Playwright browsers installed:
   ```bash
   pip install -r requirements.txt
   playwright install chromium
   ```
3. `psql` on PATH. `load_sql_to_postgres.py` currently hardcodes `C:\Program Files\PostgreSQL\18\bin\psql.exe` — edit that path for macOS/Linux (`psql` or `/opt/homebrew/opt/postgresql@16/bin/psql`).

## Order (from workspace root)

### 1. Download the dumps
```bash
python DataFetch/my_download_file.py
```
Output: `./downloads/<file>` (SQL / archives from r18.dev).

### 2. Load into Postgres
```bash
python DataFetch/load_sql_to_postgres.py
```
This **drops** and recreates schema `public` in database `freff`, then executes every `.sql` file in `./downloads/`.

### 3. Export tables to Parquet
```bash
python DataFetch/extract_tables_to_parquet.py
```
Output: `./jvify/db/<table>.parquet` for every table in schema `public`.

## Notes

- These scripts target a **separate** database (`freff`) from the Reddit pipeline's `redinst`. Adjust `PG_DATABASE` if you want a single DB.
- Re-running step 2 will wipe schema `public` — don't run against a DB you care about.
